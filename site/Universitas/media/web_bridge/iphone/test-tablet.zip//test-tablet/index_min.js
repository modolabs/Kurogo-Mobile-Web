
/* common.js */

/* 1   */ var currentTab;
/* 2   */ 
/* 3   */ String.prototype.strip = function() {
/* 4   */     return this.replace(/^\s+/, '').replace(/\s+$/, '');
/* 5   */ }
/* 6   */ 
/* 7   */ function showTab(strID, objTrigger) {
/* 8   */ // Displays the tab with ID strID
/* 9   */ 	var objTab = document.getElementById(strID);
/* 10  */ 	if(objTab) {
/* 11  */ 		show(strID);
/* 12  */ 		if(currentTab && (currentTab != objTab)) {
/* 13  */ 			hide(currentTab.id);
/* 14  */ 			//currentTab.style.display = "none";
/* 15  */ 		}
/* 16  */ 	}
/* 17  */ 	currentTab = objTab; // Remember which is the currently displayed tab
/* 18  */ 	
/* 19  */ 	// Set the clicked tab to look current
/* 20  */ 	var objTabs = document.getElementById("tabs");
/* 21  */   if (objTabs) {
/* 22  */     var arrTabs = objTabs.getElementsByTagName("li");
/* 23  */     if(objTrigger) {
/* 24  */       for(var i=0; i<arrTabs.length; i++) {
/* 25  */         arrTabs[i].className="";
/* 26  */       }
/* 27  */       var objTriggerTab = objTrigger.parentNode;
/* 28  */       if(objTriggerTab) {
/* 29  */         objTriggerTab.className="active";
/* 30  */       }
/* 31  */     }
/* 32  */ 
/* 33  */     // fake resize event in case tab body was resized while hidden 
/* 34  */     if (document.createEvent) {
/* 35  */       var e = document.createEvent('HTMLEvents');
/* 36  */       e.initEvent('resize', true, true);
/* 37  */       window.dispatchEvent(e);
/* 38  */     
/* 39  */     } else if( document.createEventObject ) {
/* 40  */       var e = document.createEventObject();
/* 41  */       document.documentElement.fireEvent('onresize', e);
/* 42  */     }
/* 43  */   }
/* 44  */ 	
/* 45  */ 	onDOMChange();
/* 46  */ }
/* 47  */ 
/* 48  */ function rotateScreen() {
/* 49  */   setOrientation(getOrientation());
/* 50  */   setTimeout(scrollToTop, 500);

/* common.js */

/* 51  */ }
/* 52  */ 
/* 53  */ function getOrientation() {
/* 54  */     if (typeof getOrientation.orientationIsFlipped == 'undefined') {
/* 55  */         // detect how we are detecting orientation
/* 56  */         getOrientation.orientationIsFlipped = false;
/* 57  */         
/* 58  */         if (!('orientation' in window)) {
/* 59  */             getOrientation.orientationMethod = 'size';
/* 60  */         } else {
/* 61  */             getOrientation.orientationMethod = 'orientation';
/* 62  */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 63  */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 64  */             
/* 65  */             /* at this point the method of orientation detection is not perfect */
/* 66  */             if (navigator.userAgent.match(/(PlayBook.+RIM Tablet|Android 3\.\d)/)) {
/* 67  */                 getOrientation.orientationIsFlipped = true;
/* 68  */             }
/* 69  */         }
/* 70  */     }
/* 71  */ 
/* 72  */     switch (getOrientation.orientationMethod) {
/* 73  */         case 'size':
/* 74  */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 75  */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 76  */ 
/* 77  */             return (width > height) ? 'landscape' : 'portrait';
/* 78  */             break;
/* 79  */ 
/* 80  */         case 'orientation':
/* 81  */             switch (window.orientation) {
/* 82  */                 case 0:
/* 83  */                 case 180:
/* 84  */                     return getOrientation.orientationIsFlipped ? 'landscape' : 'portrait';
/* 85  */                     break;
/* 86  */                 
/* 87  */                 case 90:
/* 88  */                 case -90:
/* 89  */                     return getOrientation.orientationIsFlipped ? 'portrait': 'landscape';
/* 90  */                     break;
/* 91  */             }
/* 92  */     }
/* 93  */ }
/* 94  */ 
/* 95  */ function setOrientation(orientation) {
/* 96  */     var body = document.getElementsByTagName("body")[0];
/* 97  */  
/* 98  */  //remove existing portrait/landscape class if there
/* 99  */     removeClass(body, 'portrait');
/* 100 */     removeClass(body, 'landscape');

/* common.js */

/* 101 */     addClass(body, orientation);
/* 102 */ }
/* 103 */ 
/* 104 */ 
/* 105 */ function showLoadingMsg(strID) {
/* 106 */ // Show a temporary loading message in the element with ID strID
/* 107 */ 	var objToStuff = document.getElementById(strID);
/* 108 */ 	if(objToStuff) {
/* 109 */ 		objToStuff.innerHTML = "<div class=\"loading\"><img src=\"../common/images/loading.gif\" width=\"27\" height=\"21\" alt=\"\" align=\"absmiddle\" />Loading data...</div >";
/* 110 */ 	}
/* 111 */ 	onDOMChange();
/* 112 */ }
/* 113 */ 
/* 114 */ function hide(strID) {
/* 115 */ // Hides the object with ID strID 
/* 116 */ 	var objToHide = document.getElementById(strID);
/* 117 */ 	if(objToHide) {
/* 118 */ 		objToHide.style.display = "none";
/* 119 */ 	}
/* 120 */ 	
/* 121 */ 	onDOMChange();
/* 122 */ }
/* 123 */ 
/* 124 */ function show(strID) {
/* 125 */ // Displays the object with ID strID 
/* 126 */ 	var objToHide = document.getElementById(strID);
/* 127 */ 	if(objToHide) {
/* 128 */ 		objToHide.style.display = "block";
/* 129 */ 	}
/* 130 */ 	
/* 131 */ 	onDOMChange();
/* 132 */ }
/* 133 */ 
/* 134 */ function showHideFull(objContainer) {
/* 135 */ 	var strClass = objContainer.className;
/* 136 */ 	if(strClass.indexOf("collapsed") > -1) {
/* 137 */ 		strClass = strClass.replace("collapsed","expanded");
/* 138 */ 	} else {
/* 139 */ 		strClass = strClass.replace("expanded","collapsed");
/* 140 */ 	}
/* 141 */ 	objContainer.className = strClass;
/* 142 */ 	objContainer.blur();
/* 143 */ 	
/* 144 */ 	onDOMChange();
/* 145 */ }
/* 146 */ 
/* 147 */ function clearField(objField,strDefault) {
/* 148 */ // Clears the placeholder text in an input field if it matches the default string - fixes a bug in Android
/* 149 */ 	if((objField.value==strDefault) || (objField.value=="")) {
/* 150 */ 		objField.value="";

/* common.js */

/* 151 */ 	}
/* 152 */ }
/* 153 */ 
/* 154 */ // Android doesn't respond to onfocus="clearField(...)" until the 
/* 155 */ // input field loses focus
/* 156 */ function androidPlaceholderFix(searchbox) {
/* 157 */     // this forces the search box to display the empty string
/* 158 */     // instead of the place holder when the search box takes focus
/* 159 */     if (searchbox.value == "") {
/* 160 */         searchbox.value = "";
/* 161 */     }
/* 162 */ }
/* 163 */ 
/* 164 */ function getCookie(name) {
/* 165 */   var cookie = document.cookie;
/* 166 */   var result = "";
/* 167 */   var start = cookie.indexOf(name + "=");
/* 168 */   if (start > -1) {
/* 169 */     start += name.length + 1;
/* 170 */     var end = cookie.indexOf(";", start);
/* 171 */     if (end < 0) {
/* 172 */       end = cookie.length;
/* 173 */     }
/* 174 */     result = unescape(cookie.substring(start, end));
/* 175 */   }
/* 176 */   return result;
/* 177 */ }
/* 178 */ 
/* 179 */ function setCookie(name, value, expireseconds, path) {
/* 180 */   var exdate = new Date();
/* 181 */   exdate.setTime(exdate.getTime() + (expireseconds * 1000));
/* 182 */   var exdateclause = (expireseconds == 0) ? "" : "; expires=" + exdate.toGMTString();
/* 183 */   var pathclause = (path == null) ? "" : "; path=" + path;
/* 184 */   document.cookie = name + "=" + escape(value) + exdateclause + pathclause;
/* 185 */ }
/* 186 */ 
/* 187 */ function getCookieArrayValue(name) {
/* 188 */   var value = getCookie(name);
/* 189 */   if (value && value.length) {
/* 190 */     return value.split('@@');
/* 191 */   } else {
/* 192 */     return new Array();
/* 193 */   }
/* 194 */ }
/* 195 */ 
/* 196 */ function setCookieArrayValue(name, values, expireseconds, path) {
/* 197 */   var value = '';
/* 198 */   if (values && values.length) {
/* 199 */     value = values.join('@@');
/* 200 */   }

/* common.js */

/* 201 */   setCookie(name, value, expireseconds, path);
/* 202 */ }
/* 203 */ 
/* 204 */ function hasClass(ele,cls) {
/* 205 */     return ele.className.match(new RegExp('(\\s|^)'+cls+'(\\s|$)'));
/* 206 */ }
/* 207 */         
/* 208 */ function addClass(ele,cls) {
/* 209 */     if (!this.hasClass(ele,cls)) ele.className += " "+cls;
/* 210 */ }
/* 211 */ 
/* 212 */ function removeClass(ele,cls) {
/* 213 */     if (hasClass(ele,cls)) {
/* 214 */         var reg = new RegExp('(\\s|^)'+cls+'(\\s|$)');
/* 215 */         ele.className=ele.className.replace(reg,' ').strip();
/* 216 */     }
/* 217 */ }
/* 218 */         
/* 219 */ function toggleClass(ele, cls) {
/* 220 */     if (hasClass(ele, cls)) {
/* 221 */         removeClass(ele, cls);
/* 222 */     } else {
/* 223 */         addClass(ele, cls);
/* 224 */     }
/* 225 */ }
/* 226 */ 
/* 227 */ // Share-related functions
/* 228 */ function showShare() {
/* 229 */     if (!document.getElementById("sharesheet")) {
/* 230 */         return;
/* 231 */     }
/* 232 */ 	document.getElementById("sharesheet").style.display="block";
/* 233 */ 	var iframes = document.getElementsByTagName('iframe');
/* 234 */ 	for (var i=0; i<iframes.length; i++) {
/* 235 */ 	    iframes[i].style.visibility = 'hidden';
/* 236 */ 	}
/* 237 */ 	window.scrollTo(0,0);
/* 238 */ }
/* 239 */ function hideShare() {
/* 240 */     if (!document.getElementById("sharesheet")) {
/* 241 */         return;
/* 242 */     }
/* 243 */ 	document.getElementById("sharesheet").style.display="none";
/* 244 */ 	var iframes = document.getElementsByTagName('iframe');
/* 245 */ 	for (var i=0; i<iframes.length; i++) {
/* 246 */ 	    iframes[i].style.visibility = 'visible';
/* 247 */ 	}
/* 248 */ }
/* 249 */ 
/* 250 */ // Bookmarks

/* common.js */

/* 251 */ function toggleBookmark(name, item, expireseconds, path) {
/* 252 */   // facility for module to respond to bookmark state change
/* 253 */   if (typeof moduleBookmarkWillToggle != 'undefined') {
/* 254 */     $result = moduleBookmarkWillToggle(name, item, expireseconds, path);
/* 255 */     if ($result === false) { return; }
/* 256 */   }
/* 257 */ 
/* 258 */   var bookmark = document.getElementById("bookmark");
/* 259 */   toggleClass(bookmark, "on");
/* 260 */   var items = getCookieArrayValue(name);
/* 261 */   var newItems = new Array();
/* 262 */   if (items.length == 0) {
/* 263 */     newItems[0] = item;
/* 264 */   } else {
/* 265 */     var found = false;
/* 266 */     for (var i = 0; i < items.length; i++) {
/* 267 */       if (items[i] == item) {
/* 268 */         found = true;
/* 269 */       } else {
/* 270 */         newItems.push(items[i]);
/* 271 */       }
/* 272 */     }
/* 273 */     if (!found) {
/* 274 */       newItems.push(item);
/* 275 */     }
/* 276 */   }
/* 277 */   setCookieArrayValue(name, newItems, expireseconds, path);
/* 278 */   
/* 279 */   // facility for module to respond to bookmark state change
/* 280 */   if (typeof moduleBookmarkToggled != 'undefined') {
/* 281 */     moduleBookmarkToggled(name, item, expireseconds, path);
/* 282 */   }
/* 283 */ }
/* 284 */ 
/* 285 */ // TODO this needs to handle encoded strings and parameter separators (&amp;)
/* 286 */ function apiRequest(baseURL, params, successCallback, errorCallback) {
/* 287 */   var urlParts = [];
/* 288 */   for (var paramName in params) {
/* 289 */     urlParts.push(paramName + "=" + params[paramName]);
/* 290 */   }
/* 291 */   var url = baseURL + "?" + urlParts.join("&");
/* 292 */   var httpRequest = new XMLHttpRequest();
/* 293 */ 
/* 294 */   httpRequest.open("GET", url, true);
/* 295 */   httpRequest.onreadystatechange = function() {
/* 296 */     // TODO better definition of error conditions below
/* 297 */     if (httpRequest.readyState == 4 && httpRequest.status == 200) {
/* 298 */       var obj;
/* 299 */       if (window.JSON) {
/* 300 */           obj = JSON.parse(httpRequest.responseText);

/* common.js */

/* 301 */           // TODO: catch SyntaxError
/* 302 */       } else {
/* 303 */           obj = eval('(' + httpRequest.responseText + ')');
/* 304 */       }
/* 305 */       if (obj !== undefined) {
/* 306 */         if ("error" in obj && obj["error"] !== null) {
/* 307 */           errorCallback(0, obj["error"]);
/* 308 */         } else if ("response" in obj) {
/* 309 */           successCallback(obj["response"]);
/* 310 */         } else {
/* 311 */           errorCallback(1, "response not found");
/* 312 */         }
/* 313 */       } else {
/* 314 */         errorCallback(2, "failed to parse response");
/* 315 */       }
/* 316 */     }
/* 317 */   }
/* 318 */   httpRequest.send(null);
/* 319 */ }
/* 320 */ 
/* 321 */ 
/* 322 */ 
/* 323 */ 
/* 324 */ 
/* 325 */ 
/* 326 */ 
/* 327 */ 
/* 328 */ 
/* 329 */ 

;
/* tablet.js */

/* 1   */ var containerScroller = null;
/* 2   */ var navScroller = null;
/* 3   */ 
/* 4   */ function onDOMChange() {
/* 5   */   if (containerScroller) {
/* 6   */     setContainerWrapperHeight();
/* 7   */     containerScroller.refresh();
/* 8   */   }
/* 9   */ }
/* 10  */ 
/* 11  */ // Update the nav slide indicators
/* 12  */ function updateNavSlider() {
/* 13  */     if (navScroller) {
/* 14  */         var current = Math.abs(navScroller.x);
/* 15  */         var max = Math.abs(navScroller.maxScrollX);
/* 16  */       
/* 17  */         var canScrollLeft = (current > 0);
/* 18  */         var canScrollRight = (current < max-1);
/* 19  */         
/* 20  */         document.getElementById('slideleft').style.display  = canScrollLeft  ? 'block' : 'none';
/* 21  */         document.getElementById('slideright').style.display = canScrollRight ? 'block' : 'none';
/* 22  */     }
/* 23  */ }
/* 24  */ 
/* 25  */ function navSliderScrollLeft() {
/* 26  */   if (navScroller) {
/* 27  */     navScroller.scrollTo(0, navScroller.y, 500);
/* 28  */   }
/* 29  */ }
/* 30  */ 
/* 31  */ function navSliderScrollRight() {
/* 32  */   if (navScroller) {
/* 33  */     navScroller.scrollTo(navScroller.maxScrollX, navScroller.y, 500);
/* 34  */   }
/* 35  */ }
/* 36  */ 
/* 37  */ // Change wrapper height based on device orientation.
/* 38  */ function setContainerWrapperHeight() {
/* 39  */   document.getElementById('container').style.height = 'auto';
/* 40  */ 
/* 41  */ 	var navbarHeight = document.getElementById('navbar').offsetHeight;
/* 42  */   var footerNavHeight = document.getElementById('footernav').offsetHeight;
/* 43  */ 	var wrapperHeight = window.innerHeight - navbarHeight - footerNavHeight;
/* 44  */ 	var containerHeight = document.getElementById('container').offsetHeight;
/* 45  */ 	
/* 46  */ 	document.getElementById('wrapper').style.height = wrapperHeight + 'px';
/* 47  */ 	
/* 48  */ 	if (containerHeight < wrapperHeight) {
/* 49  */ 	  document.getElementById('container').style.height = wrapperHeight + 'px';
/* 50  */ 	}

/* tablet.js */

/* 51  */ 	
/* 52  */ 	// when this exists, make it fill the screen
/* 53  */ 	var fillscreen = document.getElementById('fillscreen');
/* 54  */ 	if (fillscreen) {
/* 55  */ 	  fillscreen.style.height = wrapperHeight + 'px';
/* 56  */ 	}
/* 57  */ }
/* 58  */ 
/* 59  */ function handleWindowResize(e) {
/* 60  */     if (!('orientation' in window)) {
/* 61  */         rotateScreen();
/* 62  */     }
/* 63  */     setContainerWrapperHeight();
/* 64  */   
/* 65  */     setTimeout(updateNavSlider, 0);
/* 66  */     
/* 67  */     if (typeof moduleHandleWindowResize != 'undefined') {
/* 68  */         moduleHandleWindowResize(e);
/* 69  */     }
/* 70  */     if (navigator.userAgent.match(/(Android 3\.\d)/)) {
/* 71  */         // Android 3 browsers don't reliably set client and offset heights
/* 72  */         // before calling orientationchange or resize handlers.
/* 73  */         var self = this;
/* 74  */         setTimeout(function() {
/* 75  */             setContainerWrapperHeight();
/* 76  */             setTimeout(updateNavSlider, 0);
/* 77  */             if (typeof moduleHandleWindowResize != 'undefined') {
/* 78  */                 moduleHandleWindowResize(e);
/* 79  */             }
/* 80  */         }, 600); // approx. how long after the event before the offsetHeights are correct
/* 81  */     }
/* 82  */ } 
/* 83  */ 
/* 84  */ function tabletInit() {
/* 85  */    setOrientation(getOrientation());
/* 86  */     if(!document.getElementById('navbar')) {
/* 87  */         // page has no footer so do not attempt
/* 88  */         // to use fancy tablet container
/* 89  */         return;
/* 90  */     }
/* 91  */ 
/* 92  */   setContainerWrapperHeight();
/* 93  */   
/* 94  */   // Adjust wrapper height on orientation change or resize
/* 95  */   var resizeEvent = 'onorientationchange' in window ? 'orientationchange' : 'resize';
/* 96  */   window.addEventListener(resizeEvent, function() {setTimeout(handleWindowResize,0)}, false);
/* 97  */ 
/* 98  */   document.addEventListener('touchmove', function(e) { e.preventDefault(); }, false);
/* 99  */   
/* 100 */   containerScroller = new iScroll('wrapper', { 

/* tablet.js */

/* 101 */     checkDOMChanges: false, 
/* 102 */     hScrollbar: false,
/* 103 */     desktopCompatibility: true,
/* 104 */     bounce: false,
/* 105 */     bounceLock: true
/* 106 */   });
/* 107 */ 
/* 108 */ 
/* 109 */   navScroller = new iScroll('navsliderwrapper', { 
/* 110 */     checkDOMChanges: false, 
/* 111 */     hScrollbar: false,
/* 112 */     vScrollbar: false,
/* 113 */     desktopCompatibility: true,
/* 114 */     bounce: false,
/* 115 */     bounceLock: true,
/* 116 */     onScrollStart: updateNavSlider,
/* 117 */     onScrollEnd: updateNavSlider
/* 118 */   });
/* 119 */ 
/* 120 */     handleWindowResize();
/* 121 */     updateNavSlider();
/* 122 */ 
/* 123 */   //run module init if present
/* 124 */   if (typeof moduleInit != 'undefined') {
/* 125 */     moduleInit();
/* 126 */   }
/* 127 */ }
/* 128 */ 
/* 129 */ function scrollToTop() {
/* 130 */   if (containerScroller) {
/* 131 */   	containerScroller.scrollTo(0,0,0); 
/* 132 */   }
/* 133 */ }
/* 134 */ 
/* 135 */ (function(window) {
/* 136 */ 
/* 137 */     function splitView (options) {
/* 138 */       // set caller options
/* 139 */         if (typeof options == 'object') {
/* 140 */             for (var i in options) {
/* 141 */                 switch (i) {
/* 142 */                     case 'linkSelect':
/* 143 */                     case 'actionForLink':
/* 144 */                         this[i] = options[i];
/* 145 */                         break;
/* 146 */                     default:
/* 147 */                         this.options[i] = options[i];
/* 148 */                         break;
/* 149 */                 }
/* 150 */             }

/* tablet.js */

/* 151 */         }
/* 152 */       
/* 153 */         if (window.addEventListener) {
/* 154 */           window.addEventListener(RESIZE_EVENT, this, false);
/* 155 */         } else if (window.attachEvent) {
/* 156 */           window.attachEvent(RESIZE_EVENT, this);
/* 157 */         }
/* 158 */         
/* 159 */         if (!document.getElementById(this.options.list) || !document.getElementById(this.options.detail)) {
/* 160 */             return;
/* 161 */         }
/* 162 */ 
/* 163 */         this.orientation = getOrientation();
/* 164 */         this.list = document.getElementById(this.options.list);
/* 165 */         this.detail = document.getElementById(this.options.detail);
/* 166 */         this.detailScroller = new iScroll(this.options.detail, {checkDOMChange: true});
/* 167 */         
/* 168 */         if ('content' in this.options) {
/* 169 */             this.content = document.getElementById(this.options.content);
/* 170 */         } else {
/* 171 */             this.options.content = this.options.detail;
/* 172 */             this.content = this.detail;
/* 173 */         }
/* 174 */         
/* 175 */         var self = this;
/* 176 */         
/* 177 */         var links = this.list.getElementsByTagName('a');
/* 178 */ 
/* 179 */         var linkInAnchor = null;
/* 180 */         var anchor = location.hash;
/* 181 */         if (anchor.length > 1) {
/* 182 */             var possibleLinkHref = removeBreadcrumbParameter(decodeURIComponent(anchor.slice(1)));
/* 183 */             if (possibleLinkHref) {
/* 184 */               for (var i=0;i<links.length;i++) {
/* 185 */                   if (possibleLinkHref == removeBreadcrumbParameter(links[i].href)) {
/* 186 */                      linkInAnchor = links[i];
/* 187 */                      break;
/* 188 */                   }
/* 189 */               }
/* 190 */             }
/* 191 */         }
/* 192 */         
/* 193 */         var first = true;
/* 194 */         for (var i=0;i<links.length;i++) {
/* 195 */             links[i].onclick = function(e) {
/* 196 */                 var action = self.actionForLink(this);
/* 197 */                 self[action](e, this);
/* 198 */             }
/* 199 */ 
/* 200 */             if (!linkInAnchor && first && this.options.selectFirst && this.actionForLink(links[i])=='linkSelect') {

/* tablet.js */

/* 201 */                 links[i].onclick();
/* 202 */                 first = false;
/* 203 */             }
/* 204 */         }
/* 205 */         if (linkInAnchor) {
/* 206 */             linkInAnchor.onclick();
/* 207 */         }
/* 208 */ 
/* 209 */         this.updateListScroller();
/* 210 */     }
/* 211 */ 
/* 212 */     splitView.prototype = {
/* 213 */         orientation: '',
/* 214 */         options: {
/* 215 */             selectFirst: true,
/* 216 */             selectID: null
/* 217 */         },
/* 218 */         baseActionForLink: function(link) {
/* 219 */             if (link.parentNode.className.match(/pagerlink/)) {
/* 220 */                 return 'linkFollow';
/* 221 */             }
/* 222 */             
/* 223 */             return 'linkSelect';
/* 224 */         },
/* 225 */         actionForLink: function(link) {
/* 226 */             return this.baseActionForLink(link);
/* 227 */         },
/* 228 */         linkFollow: function(e, link) {
/* 229 */             //just follow the link
/* 230 */         },
/* 231 */         linkSelect: function(e, link) {
/* 232 */             //ajax fun
/* 233 */             hideShare();
/* 234 */             var self = this;
/* 235 */             var selected = this.list.getElementsByTagName('a');
/* 236 */             for (var j=0;j<selected.length;j++) {
/* 237 */                 removeClass(selected[j],'listSelected');
/* 238 */             }
/* 239 */             addClass(link,'listSelected');
/* 240 */             this.detailScroller.scrollTo(0,0);
/* 241 */             var httpRequest = new XMLHttpRequest();
/* 242 */             httpRequest.open("GET", link.href+'&ajax=1', true);
/* 243 */             httpRequest.onreadystatechange = function() {
/* 244 */                 if (httpRequest.readyState == 4 && httpRequest.status == 200) {
/* 245 */                     self.content.innerHTML = httpRequest.responseText;
/* 246 */                     
/* 247 */                     var hash = '#'+encodeURIComponent(removeBreadcrumbParameter(link.href));
/* 248 */                     if (window.history && window.history.pushState && window.history.replaceState && // Regexs from history js plugin
/* 249 */                       !((/ Mobile\/([1-7][a-z]|(8([abcde]|f(1[0-8]))))/i).test(navigator.userAgent) || // disable for versions of iOS < 4.3 (8F190)
/* 250 */                          (/AppleWebKit\/5([0-2]|3[0-2])/i).test(navigator.userAgent))) { // disable for the mercury iOS browser and older webkit

/* tablet.js */

/* 251 */                       history.pushState({}, document.title, hash);
/* 252 */                     } else {
/* 253 */                       location.hash = hash;
/* 254 */                     }
/* 255 */                     
/* 256 */                     self.detailScroller.refresh();
/* 257 */                     if (typeof moduleHandleWindowResize != 'undefined') {
/* 258 */                         moduleHandleWindowResize(e);
/* 259 */                     }
/* 260 */                 }
/* 261 */             }
/* 262 */             showLoadingMsg(this.options.content);
/* 263 */             httpRequest.send(null);
/* 264 */             e && e.preventDefault();
/* 265 */             return false;
/* 266 */         },
/* 267 */         listScroller: null,
/* 268 */         detailScroller: null,
/* 269 */         handleEvent: function (e) {
/* 270 */             switch (e.type) {
/* 271 */                 case 'orientationchange':
/* 272 */                 case 'resize':
/* 273 */                     if (this.orientation != getOrientation()) {
/* 274 */                         this.orientation = getOrientation();
/* 275 */                         this.updateListScroller();
/* 276 */                         if (typeof moduleHandleWindowResize != 'undefined') {
/* 277 */                             moduleHandleWindowResize(e);
/* 278 */                         }
/* 279 */                     }
/* 280 */                     break;
/* 281 */             }
/* 282 */         },
/* 283 */         updateListScroller: function() {
/* 284 */             var self = this, options={};
/* 285 */             switch (getOrientation()) {
/* 286 */                 case 'portrait':
/* 287 */                     options.vScrollbar = false;
/* 288 */                     options.hScrollbar = true;
/* 289 */                     options.vScroll = false;
/* 290 */                     options.hScroll = true;
/* 291 */                     break;
/* 292 */                 case 'landscape':
/* 293 */                     options.vScrollbar = true;
/* 294 */                     options.hScrollbar = false;
/* 295 */                     options.hScroll = false;
/* 296 */                     options.vScroll = true;
/* 297 */                     break;
/* 298 */             }
/* 299 */ 
/* 300 */             if (this.listScroller) {

/* tablet.js */

/* 301 */                 for (var i in options) {
/* 302 */                     this.listScroller.options[i] = options[i];
/* 303 */                 }
/* 304 */                 
/* 305 */                 setTimeout(function() {
/* 306 */                     self.listScroller.refresh();
/* 307 */                     var items = self.list.getElementsByTagName('a');
/* 308 */                     for (var i=0;i<items.length; i++) {
/* 309 */                         if (hasClass(items[i],'listSelected')) {
/* 310 */                             self.listScroller.scrollToElement(items[i].parentNode,0);
/* 311 */                         }
/* 312 */                     }
/* 313 */                 },0);
/* 314 */                 return;
/* 315 */             } else {
/* 316 */               this.listScroller = new iScroll(this.options.list, options);
/* 317 */             }
/* 318 */         },
/* 319 */         refreshScrollers: function () {
/* 320 */             if (self.detailScroller) {
/* 321 */                 self.detailScroller.refresh();
/* 322 */             }
/* 323 */             if (self.listScroller) {
/* 324 */                 self.listScroller.refresh();
/* 325 */             }
/* 326 */         },
/* 327 */     }
/* 328 */     
/* 329 */     function removeBreadcrumbParameter(url) {
/* 330 */         return url.replace(/[?&]_b=[^&]*/, '');
/* 331 */     }
/* 332 */ 
/* 333 */     var RESIZE_EVENT = window.addEventListener ? 
/* 334 */     ('onorientationchange' in window ? 
/* 335 */     'orientationchange' :  // touch device
/* 336 */     'resize')              // desktop browser
/* 337 */     : ('onresize');          // IE
/* 338 */     
/* 339 */     window.splitView = splitView;
/* 340 */ 
/* 341 */ })(window)
/* 342 */ 
/* 343 */ // Used by news and video modules for news article listings
/* 344 */ function setupSplitViewForListAndDetail(headerId, listWrapperId, detailWrapperId, detailId, options) {
/* 345 */     var aSplitView = null;
/* 346 */ 
/* 347 */     moduleHandleWindowResize = function () {
/* 348 */         var listWrapper = document.getElementById(listWrapperId);
/* 349 */         var detailWrapper = document.getElementById(detailWrapperId);
/* 350 */         if (!detailWrapper) {

/* tablet.js */

/* 351 */           return;  // can happen for searches with no results or when feed is down
/* 352 */         }
/* 353 */         detailWrapper.style.height = 'auto';
/* 354 */         
/* 355 */         var wrapperHeight = document.getElementById('wrapper').offsetHeight;
/* 356 */         var headerHeight = document.getElementById(headerId).offsetHeight;
/* 357 */         var contentHeight = wrapperHeight - headerHeight;
/* 358 */         
/* 359 */         switch (getOrientation()) {
/* 360 */             case 'landscape':
/* 361 */                 listWrapper.style.height = contentHeight + 'px';
/* 362 */                 detailWrapper.style.height = contentHeight + 'px';
/* 363 */                 var list = listWrapper.getElementsByTagName('li')[0].parentNode;
/* 364 */                 list.style.width = '';
/* 365 */                 break;
/* 366 */             
/* 367 */             case 'portrait':
/* 368 */                 listWrapper.style.height = '';
/* 369 */                 // this is a hack because for some reason the width isn't being properly set
/* 370 */                 var width = 0;
/* 371 */                 var listItems = listWrapper.getElementsByTagName('li');
/* 372 */                 var list;
/* 373 */                 for (var i = 0; i < listItems.length; i++) {
/* 374 */                     list = listItems[i].parentNode;
/* 375 */                     width+=listItems[i].offsetWidth;
/* 376 */                 }
/* 377 */                 list.style.width = width+'px';
/* 378 */                 
/* 379 */                 var listWrapperHeight = listWrapper.offsetHeight;
/* 380 */                 detailWrapper.style.height = (contentHeight - listWrapperHeight) + 'px';
/* 381 */                 break;
/* 382 */         }
/* 383 */         
/* 384 */         if (aSplitView) {
/* 385 */             aSplitView.refreshScrollers();
/* 386 */         }
/* 387 */     }
/* 388 */     
/* 389 */     if (containerScroller != null) {
/* 390 */         containerScroller.destroy();
/* 391 */         containerScroller = null;
/* 392 */     }
/* 393 */     
/* 394 */     moduleHandleWindowResize();
/* 395 */ 
/* 396 */     options = options || {};
/* 397 */     options["list"] = listWrapperId;
/* 398 */     options["detail"] = detailWrapperId;
/* 399 */     options["content"] = detailId;
/* 400 */     

/* tablet.js */

/* 401 */     aSplitView = new splitView(options);
/* 402 */ }
/* 403 */ 

;
/* tablet-common-native.js */

/* 1  */ function tabletInit() {
/* 2  */     window.splitView.prototype.oldLinkSelect = window.splitView.prototype.linkSelect;
/* 3  */     window.splitView.prototype.linkSelect = function(e, link) {
/* 4  */         link.href = webBridgeLinkToAjaxLink(link.href);
/* 5  */         this.oldLinkSelect(e, link);
/* 6  */     };
/* 7  */ 
/* 8  */     setOrientation(getOrientation());
/* 9  */ 
/* 10 */     setContainerWrapperHeight();
/* 11 */     
/* 12 */     // Adjust wrapper height on orientation change or resize
/* 13 */     var resizeEvent = 'onorientationchange' in window ? 'orientationchange' : 'resize';
/* 14 */     window.addEventListener(resizeEvent, function() {setTimeout(handleWindowResize,0)}, false);
/* 15 */   
/* 16 */     document.addEventListener('touchmove', function(e) { e.preventDefault(); }, false);
/* 17 */     
/* 18 */     handleWindowResize();
/* 19 */   
/* 20 */     //run module init if present
/* 21 */     if (typeof moduleInit != 'undefined') {
/* 22 */         moduleInit();
/* 23 */     }
/* 24 */ }
/* 25 */ 
/* 26 */ 

;
/* common.js */

/* 1  */ // Initalize the ellipsis event handlers
/* 2  */ var newsEllipsizer;
/* 3  */ function setupNewsListing() {
/* 4  */     newsEllipsizer = new ellipsizer();
/* 5  */     
/* 6  */     // cap at 100 divs to avoid overloading phone
/* 7  */     for (var i = 0; i < 100; i++) {
/* 8  */         var elem = document.getElementById('ellipsis_'+i);
/* 9  */         if (!elem) { break; }
/* 10 */         newsEllipsizer.addElement(elem);
/* 11 */     }
/* 12 */ }
/* 13 */ 

;
/* index-common.js */

/* 1  */ function loadSection(select) {
/* 2  */     window.location = "kgobridge://link/test/index?section=" + select.value;
/* 3  */ }
/* 4  */ 
/* 5  */ function toggleSearch() {
/* 6  */     var categorySwitcher = document.getElementById("category-switcher");
/* 7  */     
/* 8  */     if (categorySwitcher.className == "search-mode") {
/* 9  */         categorySwitcher.className = "category-mode";
/* 10 */     } else {
/* 11 */         categorySwitcher.className = "search-mode";
/* 12 */         document.getElementById("search_terms").focus();
/* 13 */     }
/* 14 */     return false;
/* 15 */ }
/* 16 */ 
/* 17 */ function submitenter(myfield, e) {
/* 18 */     var keycode;
/* 19 */     if (window.event) {
/* 20 */         keycode = window.event.keyCode;
/* 21 */         
/* 22 */     } else if (e) {
/* 23 */         keycode = e.keyCode;        
/* 24 */         
/* 25 */     } else {
/* 26 */         return true;
/* 27 */     }
/* 28 */ 
/* 29 */     if (keycode == 13) {
/* 30 */        myfield.form.submit();
/* 31 */        return false;
/* 32 */        
/* 33 */     } else {
/* 34 */         return true;        
/* 35 */     }
/* 36 */ }
/* 37 */ 

;
/* index-tablet.js */

/* 1 */ function moduleInit() {
/* 2 */     setupSplitViewForListAndDetail('newsHeader', 'stories', 'storyDetailWrapper', 'storyDetail');
/* 3 */ }
/* 4 */ 
