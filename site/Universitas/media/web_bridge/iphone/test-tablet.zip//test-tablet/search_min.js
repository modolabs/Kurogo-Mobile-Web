
/* common.js */

/* 1   */ var currentTab;
/* 2   */ 
/* 3   */ String.prototype.strip = function() {
/* 4   */     return this.replace(/^\s+/, '').replace(/\s+$/, '');
/* 5   */ }
/* 6   */ 
/* 7   */ function showTab(strID, objTrigger) {
/* 8   */ // Displays the tab with ID strID
/* 9   */ 	var objTab = document.getElementById(strID);
/* 10  */ 	if(objTab) {
/* 11  */ 		show(strID);
/* 12  */ 		if(currentTab && (currentTab != objTab)) {
/* 13  */ 			hide(currentTab.id);
/* 14  */ 			//currentTab.style.display = "none";
/* 15  */ 		}
/* 16  */ 	}
/* 17  */ 	currentTab = objTab; // Remember which is the currently displayed tab
/* 18  */ 	
/* 19  */ 	// Set the clicked tab to look current
/* 20  */ 	var objTabs = document.getElementById("tabs");
/* 21  */   if (objTabs) {
/* 22  */     var arrTabs = objTabs.getElementsByTagName("li");
/* 23  */     if(objTrigger) {
/* 24  */       for(var i=0; i<arrTabs.length; i++) {
/* 25  */         arrTabs[i].className="";
/* 26  */       }
/* 27  */       var objTriggerTab = objTrigger.parentNode;
/* 28  */       if(objTriggerTab) {
/* 29  */         objTriggerTab.className="active";
/* 30  */       }
/* 31  */     }
/* 32  */ 
/* 33  */     // fake resize event in case tab body was resized while hidden 
/* 34  */     if (document.createEvent) {
/* 35  */       var e = document.createEvent('HTMLEvents');
/* 36  */       e.initEvent('resize', true, true);
/* 37  */       window.dispatchEvent(e);
/* 38  */     
/* 39  */     } else if( document.createEventObject ) {
/* 40  */       var e = document.createEventObject();
/* 41  */       document.documentElement.fireEvent('onresize', e);
/* 42  */     }
/* 43  */   }
/* 44  */ 	
/* 45  */ 	onDOMChange();
/* 46  */ }
/* 47  */ 
/* 48  */ function rotateScreen() {
/* 49  */   setOrientation(getOrientation());
/* 50  */   setTimeout(scrollToTop, 500);

/* common.js */

/* 51  */ }
/* 52  */ 
/* 53  */ function getOrientation() {
/* 54  */     if (typeof getOrientation.orientationIsFlipped == 'undefined') {
/* 55  */         // detect how we are detecting orientation
/* 56  */         getOrientation.orientationIsFlipped = false;
/* 57  */         
/* 58  */         if (!('orientation' in window)) {
/* 59  */             getOrientation.orientationMethod = 'size';
/* 60  */         } else {
/* 61  */             getOrientation.orientationMethod = 'orientation';
/* 62  */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 63  */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 64  */             
/* 65  */             /* at this point the method of orientation detection is not perfect */
/* 66  */             if (navigator.userAgent.match(/(PlayBook.+RIM Tablet|Android 3\.\d)/)) {
/* 67  */                 getOrientation.orientationIsFlipped = true;
/* 68  */             }
/* 69  */         }
/* 70  */     }
/* 71  */ 
/* 72  */     switch (getOrientation.orientationMethod) {
/* 73  */         case 'size':
/* 74  */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 75  */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 76  */ 
/* 77  */             return (width > height) ? 'landscape' : 'portrait';
/* 78  */             break;
/* 79  */ 
/* 80  */         case 'orientation':
/* 81  */             switch (window.orientation) {
/* 82  */                 case 0:
/* 83  */                 case 180:
/* 84  */                     return getOrientation.orientationIsFlipped ? 'landscape' : 'portrait';
/* 85  */                     break;
/* 86  */                 
/* 87  */                 case 90:
/* 88  */                 case -90:
/* 89  */                     return getOrientation.orientationIsFlipped ? 'portrait': 'landscape';
/* 90  */                     break;
/* 91  */             }
/* 92  */     }
/* 93  */ }
/* 94  */ 
/* 95  */ function setOrientation(orientation) {
/* 96  */     var body = document.getElementsByTagName("body")[0];
/* 97  */  
/* 98  */  //remove existing portrait/landscape class if there
/* 99  */     removeClass(body, 'portrait');
/* 100 */     removeClass(body, 'landscape');

/* common.js */

/* 101 */     addClass(body, orientation);
/* 102 */ }
/* 103 */ 
/* 104 */ 
/* 105 */ function showLoadingMsg(strID) {
/* 106 */ // Show a temporary loading message in the element with ID strID
/* 107 */ 	var objToStuff = document.getElementById(strID);
/* 108 */ 	if(objToStuff) {
/* 109 */ 		objToStuff.innerHTML = "<div class=\"loading\"><img src=\"../common/images/loading.gif\" width=\"27\" height=\"21\" alt=\"\" align=\"absmiddle\" />Loading data...</div >";
/* 110 */ 	}
/* 111 */ 	onDOMChange();
/* 112 */ }
/* 113 */ 
/* 114 */ function hide(strID) {
/* 115 */ // Hides the object with ID strID 
/* 116 */ 	var objToHide = document.getElementById(strID);
/* 117 */ 	if(objToHide) {
/* 118 */ 		objToHide.style.display = "none";
/* 119 */ 	}
/* 120 */ 	
/* 121 */ 	onDOMChange();
/* 122 */ }
/* 123 */ 
/* 124 */ function show(strID) {
/* 125 */ // Displays the object with ID strID 
/* 126 */ 	var objToHide = document.getElementById(strID);
/* 127 */ 	if(objToHide) {
/* 128 */ 		objToHide.style.display = "block";
/* 129 */ 	}
/* 130 */ 	
/* 131 */ 	onDOMChange();
/* 132 */ }
/* 133 */ 
/* 134 */ function showHideFull(objContainer) {
/* 135 */ 	var strClass = objContainer.className;
/* 136 */ 	if(strClass.indexOf("collapsed") > -1) {
/* 137 */ 		strClass = strClass.replace("collapsed","expanded");
/* 138 */ 	} else {
/* 139 */ 		strClass = strClass.replace("expanded","collapsed");
/* 140 */ 	}
/* 141 */ 	objContainer.className = strClass;
/* 142 */ 	objContainer.blur();
/* 143 */ 	
/* 144 */ 	onDOMChange();
/* 145 */ }
/* 146 */ 
/* 147 */ function clearField(objField,strDefault) {
/* 148 */ // Clears the placeholder text in an input field if it matches the default string - fixes a bug in Android
/* 149 */ 	if((objField.value==strDefault) || (objField.value=="")) {
/* 150 */ 		objField.value="";

/* common.js */

/* 151 */ 	}
/* 152 */ }
/* 153 */ 
/* 154 */ // Android doesn't respond to onfocus="clearField(...)" until the 
/* 155 */ // input field loses focus
/* 156 */ function androidPlaceholderFix(searchbox) {
/* 157 */     // this forces the search box to display the empty string
/* 158 */     // instead of the place holder when the search box takes focus
/* 159 */     if (searchbox.value == "") {
/* 160 */         searchbox.value = "";
/* 161 */     }
/* 162 */ }
/* 163 */ 
/* 164 */ function getCookie(name) {
/* 165 */   var cookie = document.cookie;
/* 166 */   var result = "";
/* 167 */   var start = cookie.indexOf(name + "=");
/* 168 */   if (start > -1) {
/* 169 */     start += name.length + 1;
/* 170 */     var end = cookie.indexOf(";", start);
/* 171 */     if (end < 0) {
/* 172 */       end = cookie.length;
/* 173 */     }
/* 174 */     result = unescape(cookie.substring(start, end));
/* 175 */   }
/* 176 */   return result;
/* 177 */ }
/* 178 */ 
/* 179 */ function setCookie(name, value, expireseconds, path) {
/* 180 */   var exdate = new Date();
/* 181 */   exdate.setTime(exdate.getTime() + (expireseconds * 1000));
/* 182 */   var exdateclause = (expireseconds == 0) ? "" : "; expires=" + exdate.toGMTString();
/* 183 */   var pathclause = (path == null) ? "" : "; path=" + path;
/* 184 */   document.cookie = name + "=" + escape(value) + exdateclause + pathclause;
/* 185 */ }
/* 186 */ 
/* 187 */ function getCookieArrayValue(name) {
/* 188 */   var value = getCookie(name);
/* 189 */   if (value && value.length) {
/* 190 */     return value.split('@@');
/* 191 */   } else {
/* 192 */     return new Array();
/* 193 */   }
/* 194 */ }
/* 195 */ 
/* 196 */ function setCookieArrayValue(name, values, expireseconds, path) {
/* 197 */   var value = '';
/* 198 */   if (values && values.length) {
/* 199 */     value = values.join('@@');
/* 200 */   }

/* common.js */

/* 201 */   setCookie(name, value, expireseconds, path);
/* 202 */ }
/* 203 */ 
/* 204 */ function hasClass(ele,cls) {
/* 205 */     return ele.className.match(new RegExp('(\\s|^)'+cls+'(\\s|$)'));
/* 206 */ }
/* 207 */         
/* 208 */ function addClass(ele,cls) {
/* 209 */     if (!this.hasClass(ele,cls)) ele.className += " "+cls;
/* 210 */ }
/* 211 */ 
/* 212 */ function removeClass(ele,cls) {
/* 213 */     if (hasClass(ele,cls)) {
/* 214 */         var reg = new RegExp('(\\s|^)'+cls+'(\\s|$)');
/* 215 */         ele.className=ele.className.replace(reg,' ').strip();
/* 216 */     }
/* 217 */ }
/* 218 */         
/* 219 */ function toggleClass(ele, cls) {
/* 220 */     if (hasClass(ele, cls)) {
/* 221 */         removeClass(ele, cls);
/* 222 */     } else {
/* 223 */         addClass(ele, cls);
/* 224 */     }
/* 225 */ }
/* 226 */ 
/* 227 */ // Share-related functions
/* 228 */ function showShare() {
/* 229 */     if (!document.getElementById("sharesheet")) {
/* 230 */         return;
/* 231 */     }
/* 232 */ 	document.getElementById("sharesheet").style.display="block";
/* 233 */ 	var iframes = document.getElementsByTagName('iframe');
/* 234 */ 	for (var i=0; i<iframes.length; i++) {
/* 235 */ 	    iframes[i].style.visibility = 'hidden';
/* 236 */ 	}
/* 237 */ 	window.scrollTo(0,0);
/* 238 */ }
/* 239 */ function hideShare() {
/* 240 */     if (!document.getElementById("sharesheet")) {
/* 241 */         return;
/* 242 */     }
/* 243 */ 	document.getElementById("sharesheet").style.display="none";
/* 244 */ 	var iframes = document.getElementsByTagName('iframe');
/* 245 */ 	for (var i=0; i<iframes.length; i++) {
/* 246 */ 	    iframes[i].style.visibility = 'visible';
/* 247 */ 	}
/* 248 */ }
/* 249 */ 
/* 250 */ // Bookmarks

/* common.js */

/* 251 */ function toggleBookmark(name, item, expireseconds, path) {
/* 252 */   // facility for module to respond to bookmark state change
/* 253 */   if (typeof moduleBookmarkWillToggle != 'undefined') {
/* 254 */     $result = moduleBookmarkWillToggle(name, item, expireseconds, path);
/* 255 */     if ($result === false) { return; }
/* 256 */   }
/* 257 */ 
/* 258 */   var bookmark = document.getElementById("bookmark");
/* 259 */   toggleClass(bookmark, "on");
/* 260 */   var items = getCookieArrayValue(name);
/* 261 */   var newItems = new Array();
/* 262 */   if (items.length == 0) {
/* 263 */     newItems[0] = item;
/* 264 */   } else {
/* 265 */     var found = false;
/* 266 */     for (var i = 0; i < items.length; i++) {
/* 267 */       if (items[i] == item) {
/* 268 */         found = true;
/* 269 */       } else {
/* 270 */         newItems.push(items[i]);
/* 271 */       }
/* 272 */     }
/* 273 */     if (!found) {
/* 274 */       newItems.push(item);
/* 275 */     }
/* 276 */   }
/* 277 */   setCookieArrayValue(name, newItems, expireseconds, path);
/* 278 */   
/* 279 */   // facility for module to respond to bookmark state change
/* 280 */   if (typeof moduleBookmarkToggled != 'undefined') {
/* 281 */     moduleBookmarkToggled(name, item, expireseconds, path);
/* 282 */   }
/* 283 */ }
/* 284 */ 
/* 285 */ // TODO this needs to handle encoded strings and parameter separators (&amp;)
/* 286 */ function apiRequest(baseURL, params, successCallback, errorCallback) {
/* 287 */   var urlParts = [];
/* 288 */   for (var paramName in params) {
/* 289 */     urlParts.push(paramName + "=" + params[paramName]);
/* 290 */   }
/* 291 */   var url = baseURL + "?" + urlParts.join("&");
/* 292 */   var httpRequest = new XMLHttpRequest();
/* 293 */ 
/* 294 */   httpRequest.open("GET", url, true);
/* 295 */   httpRequest.onreadystatechange = function() {
/* 296 */     // TODO better definition of error conditions below
/* 297 */     if (httpRequest.readyState == 4 && httpRequest.status == 200) {
/* 298 */       var obj;
/* 299 */       if (window.JSON) {
/* 300 */           obj = JSON.parse(httpRequest.responseText);

/* common.js */

/* 301 */           // TODO: catch SyntaxError
/* 302 */       } else {
/* 303 */           obj = eval('(' + httpRequest.responseText + ')');
/* 304 */       }
/* 305 */       if (obj !== undefined) {
/* 306 */         if ("error" in obj && obj["error"] !== null) {
/* 307 */           errorCallback(0, obj["error"]);
/* 308 */         } else if ("response" in obj) {
/* 309 */           successCallback(obj["response"]);
/* 310 */         } else {
/* 311 */           errorCallback(1, "response not found");
/* 312 */         }
/* 313 */       } else {
/* 314 */         errorCallback(2, "failed to parse response");
/* 315 */       }
/* 316 */     }
/* 317 */   }
/* 318 */   httpRequest.send(null);
/* 319 */ }
/* 320 */ 
/* 321 */ 
/* 322 */ 
/* 323 */ 
/* 324 */ 
/* 325 */ 
/* 326 */ 
/* 327 */ 
/* 328 */ 
/* 329 */ 

;
/* native_tablet.js */

/* 1   */ var containerScroller = null;
/* 2   */ var navScroller = null;
/* 3   */ 
/* 4   */ function onDOMChange() {
/* 5   */   if (containerScroller) {
/* 6   */     setContainerWrapperHeight();
/* 7   */     containerScroller.refresh();
/* 8   */   }
/* 9   */ }
/* 10  */ 
/* 11  */ // Update the nav slide indicators
/* 12  */ function updateNavSlider() {
/* 13  */   var current = Math.abs(navScroller.x);
/* 14  */   var max = Math.abs(navScroller.maxScrollX);
/* 15  */ 
/* 16  */   var canScrollLeft = (current > 0);
/* 17  */   var canScrollRight = (current < max-1);
/* 18  */   
/* 19  */   document.getElementById('slideleft').style.display  = canScrollLeft  ? 'block' : 'none';
/* 20  */   document.getElementById('slideright').style.display = canScrollRight ? 'block' : 'none';
/* 21  */ }
/* 22  */ 
/* 23  */ function navSliderScrollLeft() {
/* 24  */   if (navScroller) {
/* 25  */     navScroller.scrollTo(0, navScroller.y, 500);
/* 26  */   }
/* 27  */ }
/* 28  */ 
/* 29  */ function navSliderScrollRight() {
/* 30  */   if (navScroller) {
/* 31  */     navScroller.scrollTo(navScroller.maxScrollX, navScroller.y, 500);
/* 32  */   }
/* 33  */ }
/* 34  */ 
/* 35  */ // Change wrapper height based on device orientation.
/* 36  */ function setContainerWrapperHeight() {
/* 37  */   document.getElementById('container').style.height = 'auto';
/* 38  */ 
/* 39  */ 	var navbarHeight = document.getElementById('navbar').offsetHeight;
/* 40  */   var footerNavHeight = document.getElementById('footernav').offsetHeight;
/* 41  */ 	var wrapperHeight = window.innerHeight - navbarHeight - footerNavHeight;
/* 42  */ 	var containerHeight = document.getElementById('container').offsetHeight;
/* 43  */ 	
/* 44  */ 	document.getElementById('wrapper').style.height = wrapperHeight + 'px';
/* 45  */ 	
/* 46  */ 	if (containerHeight < wrapperHeight) {
/* 47  */ 	  document.getElementById('container').style.height = wrapperHeight + 'px';
/* 48  */ 	}
/* 49  */ 	
/* 50  */ 	// when this exists, make it fill the screen

/* native_tablet.js */

/* 51  */ 	var fillscreen = document.getElementById('fillscreen');
/* 52  */ 	if (fillscreen) {
/* 53  */ 	  fillscreen.style.height = wrapperHeight + 'px';
/* 54  */ 	}
/* 55  */ }
/* 56  */ 
/* 57  */ function handleWindowResize(e) {
/* 58  */     if (!('orientation' in window)) {
/* 59  */         rotateScreen();
/* 60  */     }
/* 61  */     setContainerWrapperHeight();
/* 62  */   
/* 63  */     setTimeout(updateNavSlider, 0);
/* 64  */     
/* 65  */     if (typeof moduleHandleWindowResize != 'undefined') {
/* 66  */         moduleHandleWindowResize(e);
/* 67  */     }
/* 68  */     if (navigator.userAgent.match(/(Android 3\.\d)/)) {
/* 69  */         // Android 3 browsers don't reliably set client and offset heights
/* 70  */         // before calling orientationchange or resize handlers.
/* 71  */         var self = this;
/* 72  */         setTimeout(function() {
/* 73  */             setContainerWrapperHeight();
/* 74  */             setTimeout(updateNavSlider, 0);
/* 75  */             if (typeof moduleHandleWindowResize != 'undefined') {
/* 76  */                 moduleHandleWindowResize(e);
/* 77  */             }
/* 78  */         }, 600); // approx. how long after the event before the offsetHeights are correct
/* 79  */     }
/* 80  */ } 
/* 81  */ 
/* 82  */ function tabletInit() {
/* 83  */    setOrientation(getOrientation());
/* 84  */     if(!document.getElementById('navbar')) {
/* 85  */         // page has no footer so do not attempt
/* 86  */         // to use fancy tablet container
/* 87  */         return;
/* 88  */     }
/* 89  */ 
/* 90  */   setContainerWrapperHeight();
/* 91  */   
/* 92  */   // Adjust wrapper height on orientation change or resize
/* 93  */   var resizeEvent = 'onorientationchange' in window ? 'orientationchange' : 'resize';
/* 94  */   window.addEventListener(resizeEvent, function() {setTimeout(handleWindowResize,0)}, false);
/* 95  */ 
/* 96  */   document.addEventListener('touchmove', function(e) { e.preventDefault(); }, false);
/* 97  */   
/* 98  */   containerScroller = new iScroll('wrapper', { 
/* 99  */     checkDOMChanges: false, 
/* 100 */     hScrollbar: false,

/* native_tablet.js */

/* 101 */     desktopCompatibility: true,
/* 102 */     bounce: false,
/* 103 */     bounceLock: true
/* 104 */   });
/* 105 */ 
/* 106 */ 
/* 107 */   navScroller = new iScroll('navsliderwrapper', { 
/* 108 */     checkDOMChanges: false, 
/* 109 */     hScrollbar: false,
/* 110 */     vScrollbar: false,
/* 111 */     desktopCompatibility: true,
/* 112 */     bounce: false,
/* 113 */     bounceLock: true,
/* 114 */     onScrollStart: updateNavSlider,
/* 115 */     onScrollEnd: updateNavSlider
/* 116 */   });
/* 117 */ 
/* 118 */     handleWindowResize();
/* 119 */     updateNavSlider();
/* 120 */ 
/* 121 */   //run module init if present
/* 122 */   if (typeof moduleInit != 'undefined') {
/* 123 */     moduleInit();
/* 124 */   }
/* 125 */ }
/* 126 */ 
/* 127 */ function scrollToTop() {
/* 128 */   if (containerScroller) {
/* 129 */   	containerScroller.scrollTo(0,0,0); 
/* 130 */   }
/* 131 */ }
/* 132 */ 
/* 133 */ (function(window) {
/* 134 */ 
/* 135 */     function splitView (options) {
/* 136 */       // set caller options
/* 137 */         if (typeof options == 'object') {
/* 138 */             for (var i in options) {
/* 139 */                 switch (i) {
/* 140 */                     case 'linkSelect':
/* 141 */                     case 'actionForLink':
/* 142 */                         this[i] = options[i];
/* 143 */                         break;
/* 144 */                     default:
/* 145 */                         this.options[i] = options[i];
/* 146 */                         break;
/* 147 */                 }
/* 148 */             }
/* 149 */         }
/* 150 */       

/* native_tablet.js */

/* 151 */         if (window.addEventListener) {
/* 152 */           window.addEventListener(RESIZE_EVENT, this, false);
/* 153 */         } else if (window.attachEvent) {
/* 154 */           window.attachEvent(RESIZE_EVENT, this);
/* 155 */         }
/* 156 */         
/* 157 */         if (!document.getElementById(this.options.list) || !document.getElementById(this.options.detail)) {
/* 158 */             return;
/* 159 */         }
/* 160 */ 
/* 161 */         this.orientation = getOrientation();
/* 162 */         this.list = document.getElementById(this.options.list);
/* 163 */         this.detail = document.getElementById(this.options.detail);
/* 164 */         this.detailScroller = new iScroll(this.options.detail, {checkDOMChange: true});
/* 165 */         
/* 166 */         if ('content' in this.options) {
/* 167 */             this.content = document.getElementById(this.options.content);
/* 168 */         } else {
/* 169 */             this.options.content = this.options.detail;
/* 170 */             this.content = this.detail;
/* 171 */         }
/* 172 */         
/* 173 */         var self = this;
/* 174 */         
/* 175 */         var links = this.list.getElementsByTagName('a');
/* 176 */ 
/* 177 */         var linkInAnchor = null;
/* 178 */         var anchor = location.hash;
/* 179 */         if (anchor.length > 1) {
/* 180 */             var possibleLinkHref = removeBreadcrumbParameter(decodeURIComponent(anchor.slice(1)));
/* 181 */             if (possibleLinkHref) {
/* 182 */               for (var i=0;i<links.length;i++) {
/* 183 */                   if (possibleLinkHref == removeBreadcrumbParameter(links[i].href)) {
/* 184 */                      linkInAnchor = links[i];
/* 185 */                      break;
/* 186 */                   }
/* 187 */               }
/* 188 */             }
/* 189 */         }
/* 190 */         
/* 191 */         var first = true;
/* 192 */         for (var i=0;i<links.length;i++) {
/* 193 */             links[i].onclick = function(e) {
/* 194 */                 var action = self.actionForLink(this);
/* 195 */                 self[action](e, this);
/* 196 */             }
/* 197 */ 
/* 198 */             if (!linkInAnchor && first && this.options.selectFirst && this.actionForLink(links[i])=='linkSelect') {
/* 199 */                 links[i].onclick();
/* 200 */                 first = false;

/* native_tablet.js */

/* 201 */             }
/* 202 */         }
/* 203 */         if (linkInAnchor) {
/* 204 */             linkInAnchor.onclick();
/* 205 */         }
/* 206 */ 
/* 207 */         this.updateListScroller();
/* 208 */     }
/* 209 */ 
/* 210 */     splitView.prototype = {
/* 211 */         orientation: '',
/* 212 */         options: {
/* 213 */             selectFirst: true,
/* 214 */             selectID: null
/* 215 */         },
/* 216 */         baseActionForLink: function(link) {
/* 217 */             if (link.parentNode.className.match(/pagerlink/)) {
/* 218 */                 return 'linkFollow';
/* 219 */             }
/* 220 */             
/* 221 */             return 'linkSelect';
/* 222 */         },
/* 223 */         actionForLink: function(link) {
/* 224 */             return this.baseActionForLink(link);
/* 225 */         },
/* 226 */         linkFollow: function(e, link) {
/* 227 */             //just follow the link
/* 228 */         },
/* 229 */         linkSelect: function(e, link) {
/* 230 */             //ajax fun
/* 231 */             hideShare();
/* 232 */             var self = this;
/* 233 */             var selected = this.list.getElementsByTagName('a');
/* 234 */             for (var j=0;j<selected.length;j++) {
/* 235 */                 removeClass(selected[j],'listSelected');
/* 236 */             }
/* 237 */             addClass(link,'listSelected');
/* 238 */             this.detailScroller.scrollTo(0,0);
/* 239 */             var httpRequest = new XMLHttpRequest();
/* 240 */             httpRequest.open("GET", link.href+'&ajax=1', true);
/* 241 */             httpRequest.onreadystatechange = function() {
/* 242 */                 if (httpRequest.readyState == 4 && httpRequest.status == 200) {
/* 243 */                     self.content.innerHTML = httpRequest.responseText;
/* 244 */                     
/* 245 */                     var hash = '#'+encodeURIComponent(removeBreadcrumbParameter(link.href));
/* 246 */                     if (window.history && window.history.pushState && window.history.replaceState && // Regexs from history js plugin
/* 247 */                       !((/ Mobile\/([1-7][a-z]|(8([abcde]|f(1[0-8]))))/i).test(navigator.userAgent) || // disable for versions of iOS < 4.3 (8F190)
/* 248 */                          (/AppleWebKit\/5([0-2]|3[0-2])/i).test(navigator.userAgent))) { // disable for the mercury iOS browser and older webkit
/* 249 */                       history.pushState({}, document.title, hash);
/* 250 */                     } else {

/* native_tablet.js */

/* 251 */                       location.hash = hash;
/* 252 */                     }
/* 253 */                     
/* 254 */                     self.detailScroller.refresh();
/* 255 */                     if (typeof moduleHandleWindowResize != 'undefined') {
/* 256 */                         moduleHandleWindowResize(e);
/* 257 */                     }
/* 258 */                 }
/* 259 */             }
/* 260 */             showLoadingMsg(this.options.content);
/* 261 */             httpRequest.send(null);
/* 262 */             e && e.preventDefault();
/* 263 */             return false;
/* 264 */         },
/* 265 */         listScroller: null,
/* 266 */         detailScroller: null,
/* 267 */         handleEvent: function (e) {
/* 268 */             switch (e.type) {
/* 269 */                 case 'orientationchange':
/* 270 */                 case 'resize':
/* 271 */                     if (this.orientation != getOrientation()) {
/* 272 */                         this.orientation = getOrientation();
/* 273 */                         this.updateListScroller();
/* 274 */                         if (typeof moduleHandleWindowResize != 'undefined') {
/* 275 */                             moduleHandleWindowResize(e);
/* 276 */                         }
/* 277 */                     }
/* 278 */                     break;
/* 279 */             }
/* 280 */         },
/* 281 */         updateListScroller: function() {
/* 282 */             var self = this, options={};
/* 283 */             switch (getOrientation()) {
/* 284 */                 case 'portrait':
/* 285 */                     options.vScrollbar = false;
/* 286 */                     options.hScrollbar = true;
/* 287 */                     options.vScroll = false;
/* 288 */                     options.hScroll = true;
/* 289 */                     break;
/* 290 */                 case 'landscape':
/* 291 */                     options.vScrollbar = true;
/* 292 */                     options.hScrollbar = false;
/* 293 */                     options.hScroll = false;
/* 294 */                     options.vScroll = true;
/* 295 */                     break;
/* 296 */             }
/* 297 */ 
/* 298 */             if (this.listScroller) {
/* 299 */                 for (var i in options) {
/* 300 */                     this.listScroller.options[i] = options[i];

/* native_tablet.js */

/* 301 */                 }
/* 302 */                 
/* 303 */                 setTimeout(function() {
/* 304 */                     self.listScroller.refresh();
/* 305 */                     var items = self.list.getElementsByTagName('a');
/* 306 */                     for (var i=0;i<items.length; i++) {
/* 307 */                         if (hasClass(items[i],'listSelected')) {
/* 308 */                             self.listScroller.scrollToElement(items[i].parentNode,0);
/* 309 */                         }
/* 310 */                     }
/* 311 */                 },0);
/* 312 */                 return;
/* 313 */             } else {
/* 314 */               this.listScroller = new iScroll(this.options.list, options);
/* 315 */             }
/* 316 */         },
/* 317 */         refreshScrollers: function () {
/* 318 */             if (self.detailScroller) {
/* 319 */                 self.detailScroller.refresh();
/* 320 */             }
/* 321 */             if (self.listScroller) {
/* 322 */                 self.listScroller.refresh();
/* 323 */             }
/* 324 */         },
/* 325 */     }
/* 326 */     
/* 327 */     function removeBreadcrumbParameter(url) {
/* 328 */         return url.replace(/[?&]_b=[^&]*/, '');
/* 329 */     }
/* 330 */ 
/* 331 */     var RESIZE_EVENT = window.addEventListener ? 
/* 332 */     ('onorientationchange' in window ? 
/* 333 */     'orientationchange' :  // touch device
/* 334 */     'resize')              // desktop browser
/* 335 */     : ('onresize');          // IE
/* 336 */     
/* 337 */     window.splitView = splitView;
/* 338 */ 
/* 339 */ })(window)
/* 340 */ 
/* 341 */ // Used by news and video modules for news article listings
/* 342 */ function setupSplitViewForListAndDetail(headerId, listWrapperId, detailWrapperId, detailId) {
/* 343 */     var aSplitView = null;
/* 344 */ 
/* 345 */     moduleHandleWindowResize = function () {
/* 346 */         var listWrapper = document.getElementById(listWrapperId);
/* 347 */         var detailWrapper = document.getElementById(detailWrapperId);
/* 348 */         if (!detailWrapper) {
/* 349 */           return;  // can happen for searches with no results or when feed is down
/* 350 */         }

/* native_tablet.js */

/* 351 */         detailWrapper.style.height = 'auto';
/* 352 */         
/* 353 */         var wrapperHeight = document.getElementById('wrapper').offsetHeight;
/* 354 */         var headerHeight = document.getElementById(headerId).offsetHeight;
/* 355 */         var contentHeight = wrapperHeight - headerHeight;
/* 356 */         
/* 357 */         switch (getOrientation()) {
/* 358 */             case 'landscape':
/* 359 */                 listWrapper.style.height = contentHeight + 'px';
/* 360 */                 detailWrapper.style.height = contentHeight + 'px';
/* 361 */                 var list = listWrapper.getElementsByTagName('li')[0].parentNode;
/* 362 */                 list.style.width = '';
/* 363 */                 break;
/* 364 */             
/* 365 */             case 'portrait':
/* 366 */                 listWrapper.style.height = '';
/* 367 */                 // this is a hack because for some reason the width isn't being properly set
/* 368 */                 var width = 0;
/* 369 */                 var listItems = listWrapper.getElementsByTagName('li');
/* 370 */                 var list;
/* 371 */                 for (var i = 0; i < listItems.length; i++) {
/* 372 */                     list = listItems[i].parentNode;
/* 373 */                     width+=listItems[i].offsetWidth;
/* 374 */                 }
/* 375 */                 list.style.width = width+'px';
/* 376 */                 
/* 377 */                 var listWrapperHeight = listWrapper.offsetHeight;
/* 378 */                 detailWrapper.style.height = (contentHeight - listWrapperHeight) + 'px';
/* 379 */                 break;
/* 380 */         }
/* 381 */         
/* 382 */         if (aSplitView) {
/* 383 */             aSplitView.refreshScrollers();
/* 384 */         }
/* 385 */     }
/* 386 */     
/* 387 */     containerScroller.destroy();
/* 388 */     containerScroller = null;
/* 389 */     
/* 390 */     moduleHandleWindowResize();
/* 391 */     
/* 392 */     aSplitView = new splitView({
/* 393 */         list: listWrapperId,
/* 394 */         detail: detailWrapperId,
/* 395 */         content: detailId
/* 396 */     });
/* 397 */ }
/* 398 */ 

;
/* common.js */

/* 1  */ // Initalize the ellipsis event handlers
/* 2  */ var newsEllipsizer;
/* 3  */ function setupNewsListing() {
/* 4  */     newsEllipsizer = new ellipsizer();
/* 5  */     
/* 6  */     // cap at 100 divs to avoid overloading phone
/* 7  */     for (var i = 0; i < 100; i++) {
/* 8  */         var elem = document.getElementById('ellipsis_'+i);
/* 9  */         if (!elem) { break; }
/* 10 */         newsEllipsizer.addElement(elem);
/* 11 */     }
/* 12 */ }
/* 13 */ 

;
/* search-native_tablet.js */

/* 1 */ function moduleInit() {
/* 2 */     setupSplitViewForListAndDetail('newsHeader', 'stories', 'storyDetailWrapper', 'storyDetail');
/* 3 */ }
/* 4 */ 
