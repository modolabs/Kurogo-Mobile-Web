
/* common.js */

/* 1   */ var currentTab;
/* 2   */ 
/* 3   */ String.prototype.strip = function() {
/* 4   */     return this.replace(/^\s+/, '').replace(/\s+$/, '');
/* 5   */ }
/* 6   */ 
/* 7   */ function showTab(strID, objTrigger) {
/* 8   */ // Displays the tab with ID strID
/* 9   */ 	var objTab = document.getElementById(strID);
/* 10  */ 	if(objTab) {
/* 11  */ 		show(strID);
/* 12  */ 		if(currentTab && (currentTab != objTab)) {
/* 13  */ 			hide(currentTab.id);
/* 14  */ 			//currentTab.style.display = "none";
/* 15  */ 		}
/* 16  */ 	}
/* 17  */ 	currentTab = objTab; // Remember which is the currently displayed tab
/* 18  */ 	
/* 19  */ 	// Set the clicked tab to look current
/* 20  */ 	var objTabs = document.getElementById("tabs");
/* 21  */   if (objTabs) {
/* 22  */     var arrTabs = objTabs.getElementsByTagName("li");
/* 23  */     if(objTrigger) {
/* 24  */       for(var i=0; i<arrTabs.length; i++) {
/* 25  */         arrTabs[i].className="";
/* 26  */       }
/* 27  */       var objTriggerTab = objTrigger.parentNode;
/* 28  */       if(objTriggerTab) {
/* 29  */         objTriggerTab.className="active";
/* 30  */       }
/* 31  */     }
/* 32  */ 
/* 33  */     // fake resize event in case tab body was resized while hidden 
/* 34  */     if (document.createEvent) {
/* 35  */       var e = document.createEvent('HTMLEvents');
/* 36  */       e.initEvent('resize', true, true);
/* 37  */       window.dispatchEvent(e);
/* 38  */     
/* 39  */     } else if( document.createEventObject ) {
/* 40  */       var e = document.createEventObject();
/* 41  */       document.documentElement.fireEvent('onresize', e);
/* 42  */     }
/* 43  */   }
/* 44  */ 	
/* 45  */ 	onDOMChange();
/* 46  */ }
/* 47  */ 
/* 48  */ function rotateScreen() {
/* 49  */   setOrientation(getOrientation());
/* 50  */   setTimeout(scrollToTop, 500);

/* common.js */

/* 51  */ }
/* 52  */ 
/* 53  */ function getOrientation() {
/* 54  */     if (typeof getOrientation.orientationIsFlipped == 'undefined') {
/* 55  */         // detect how we are detecting orientation
/* 56  */         getOrientation.orientationIsFlipped = false;
/* 57  */         
/* 58  */         if (!('orientation' in window)) {
/* 59  */             getOrientation.orientationMethod = 'size';
/* 60  */         } else {
/* 61  */             getOrientation.orientationMethod = 'orientation';
/* 62  */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 63  */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 64  */             
/* 65  */             /* at this point the method of orientation detection is not perfect */
/* 66  */             if (navigator.userAgent.match(/(PlayBook.+RIM Tablet|Xoom|Android 3\.\d)/)) {
/* 67  */                 getOrientation.orientationIsFlipped = true;
/* 68  */             }
/* 69  */         }
/* 70  */     }
/* 71  */ 
/* 72  */     switch (getOrientation.orientationMethod) {
/* 73  */         case 'size':
/* 74  */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 75  */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 76  */ 
/* 77  */             return (width > height) ? 'landscape' : 'portrait';
/* 78  */             break;
/* 79  */ 
/* 80  */         case 'orientation':
/* 81  */             switch (window.orientation) {
/* 82  */                 case 0:
/* 83  */                 case 180:
/* 84  */                     return getOrientation.orientationIsFlipped ? 'landscape' : 'portrait';
/* 85  */                     break;
/* 86  */                 
/* 87  */                 case 90:
/* 88  */                 case -90:
/* 89  */                     return getOrientation.orientationIsFlipped ? 'portrait': 'landscape';
/* 90  */                     break;
/* 91  */             }
/* 92  */     }
/* 93  */ }
/* 94  */ 
/* 95  */ function setOrientation(orientation) {
/* 96  */     var body = document.getElementsByTagName("body")[0];
/* 97  */  
/* 98  */  //remove existing portrait/landscape class if there
/* 99  */     removeClass(body, 'portrait');
/* 100 */     removeClass(body, 'landscape');

/* common.js */

/* 101 */     addClass(body, orientation);
/* 102 */ }
/* 103 */ 
/* 104 */ 
/* 105 */ function showLoadingMsg(strID) {
/* 106 */ // Show a temporary loading message in the element with ID strID
/* 107 */ 	var objToStuff = document.getElementById(strID);
/* 108 */ 	if(objToStuff) {
/* 109 */ 		objToStuff.innerHTML = '<div class="loading"><img src="'+URL_BASE+'common/images/loading.gif" width="27" height="21" alt="Loading" align="absmiddle" />Loading data...</div>';
/* 110 */ 	}
/* 111 */ 	onDOMChange();
/* 112 */ }
/* 113 */ 
/* 114 */ function hide(strID) {
/* 115 */ // Hides the object with ID strID 
/* 116 */ 	var objToHide = document.getElementById(strID);
/* 117 */ 	if(objToHide) {
/* 118 */ 		objToHide.style.display = "none";
/* 119 */ 	}
/* 120 */ 	
/* 121 */ 	onDOMChange();
/* 122 */ }
/* 123 */ 
/* 124 */ function show(strID) {
/* 125 */ // Displays the object with ID strID 
/* 126 */ 	var objToHide = document.getElementById(strID);
/* 127 */ 	if(objToHide) {
/* 128 */ 		objToHide.style.display = "block";
/* 129 */ 	}
/* 130 */ 	
/* 131 */ 	onDOMChange();
/* 132 */ }
/* 133 */ 
/* 134 */ function showHideFull(objContainer) {
/* 135 */ 	var strClass = objContainer.className;
/* 136 */ 	if(strClass.indexOf("collapsed") > -1) {
/* 137 */ 		strClass = strClass.replace("collapsed","expanded");
/* 138 */ 	} else {
/* 139 */ 		strClass = strClass.replace("expanded","collapsed");
/* 140 */ 	}
/* 141 */ 	objContainer.className = strClass;
/* 142 */ 	objContainer.blur();
/* 143 */ 	
/* 144 */ 	onDOMChange();
/* 145 */ }
/* 146 */ 
/* 147 */ function clearField(objField,strDefault) {
/* 148 */ // Clears the placeholder text in an input field if it matches the default string - fixes a bug in Android
/* 149 */ 	if((objField.value==strDefault) || (objField.value=="")) {
/* 150 */ 		objField.value="";

/* common.js */

/* 151 */ 	}
/* 152 */ }
/* 153 */ 
/* 154 */ // Android doesn't respond to onfocus="clearField(...)" until the 
/* 155 */ // input field loses focus
/* 156 */ function androidPlaceholderFix(searchbox) {
/* 157 */     // this forces the search box to display the empty string
/* 158 */     // instead of the place holder when the search box takes focus
/* 159 */     if (searchbox.value == "") {
/* 160 */         searchbox.value = "";
/* 161 */     }
/* 162 */ }
/* 163 */ 
/* 164 */ function getCookie(name) {
/* 165 */   var cookie = document.cookie;
/* 166 */   var result = "";
/* 167 */   var start = cookie.indexOf(name + "=");
/* 168 */   if (start > -1) {
/* 169 */     start += name.length + 1;
/* 170 */     var end = cookie.indexOf(";", start);
/* 171 */     if (end < 0) {
/* 172 */       end = cookie.length;
/* 173 */     }
/* 174 */     result = unescape(cookie.substring(start, end));
/* 175 */   }
/* 176 */   return result;
/* 177 */ }
/* 178 */ 
/* 179 */ function setCookie(name, value, expireseconds, path) {
/* 180 */   var exdate = new Date();
/* 181 */   exdate.setTime(exdate.getTime() + (expireseconds * 1000));
/* 182 */   var exdateclause = (expireseconds == 0) ? "" : "; expires=" + exdate.toGMTString();
/* 183 */   var pathclause = (path == null) ? "" : "; path=" + path;
/* 184 */   document.cookie = name + "=" + escape(value) + exdateclause + pathclause;
/* 185 */ }
/* 186 */ 
/* 187 */ function getCookieArrayValue(name) {
/* 188 */   var value = getCookie(name);
/* 189 */   if (value && value.length) {
/* 190 */     return value.split('@@');
/* 191 */   } else {
/* 192 */     return new Array();
/* 193 */   }
/* 194 */ }
/* 195 */ 
/* 196 */ function setCookieArrayValue(name, values, expireseconds, path) {
/* 197 */   var value = '';
/* 198 */   if (values && values.length) {
/* 199 */     value = values.join('@@');
/* 200 */   }

/* common.js */

/* 201 */   setCookie(name, value, expireseconds, path);
/* 202 */ }
/* 203 */ 
/* 204 */ function hasClass(ele,cls) {
/* 205 */     return ele.className.match(new RegExp('(\\s|^)'+cls+'(\\s|$)'));
/* 206 */ }
/* 207 */         
/* 208 */ function addClass(ele,cls) {
/* 209 */     if (!this.hasClass(ele,cls)) ele.className += " "+cls;
/* 210 */ }
/* 211 */ 
/* 212 */ function removeClass(ele,cls) {
/* 213 */     if (hasClass(ele,cls)) {
/* 214 */         var reg = new RegExp('(\\s|^)'+cls+'(\\s|$)');
/* 215 */         ele.className=ele.className.replace(reg,' ').strip();
/* 216 */     }
/* 217 */ }
/* 218 */         
/* 219 */ function toggleClass(ele, cls) {
/* 220 */     if (hasClass(ele, cls)) {
/* 221 */         removeClass(ele, cls);
/* 222 */     } else {
/* 223 */         addClass(ele, cls);
/* 224 */     }
/* 225 */ }
/* 226 */ 
/* 227 */ // Share-related functions
/* 228 */ function showShare() {
/* 229 */     if (!document.getElementById("sharesheet")) {
/* 230 */         return;
/* 231 */     }
/* 232 */ 	document.getElementById("sharesheet").style.display="block";
/* 233 */ 	var iframes = document.getElementsByTagName('iframe');
/* 234 */ 	for (var i=0; i<iframes.length; i++) {
/* 235 */ 	    iframes[i].style.visibility = 'hidden';
/* 236 */ 	    iframes[i].style.height = '0';
/* 237 */ 	}
/* 238 */ 	window.scrollTo(0,0);
/* 239 */ }
/* 240 */ function hideShare() {
/* 241 */     if (!document.getElementById("sharesheet")) {
/* 242 */         return;
/* 243 */     }
/* 244 */ 	document.getElementById("sharesheet").style.display="none";
/* 245 */ 	var iframes = document.getElementsByTagName('iframe');
/* 246 */ 	for (var i=0; i<iframes.length; i++) {
/* 247 */ 	    iframes[i].style.visibility = 'visible';
/* 248 */ 	    iframes[i].style.height = '';
/* 249 */ 	}
/* 250 */ }

/* common.js */

/* 251 */ 
/* 252 */ // Bookmarks
/* 253 */ function toggleBookmark(name, item, expireseconds, path, bookmarkId) {
/* 254 */   // facility for module to respond to bookmark state change
/* 255 */   if (typeof moduleBookmarkWillToggle != 'undefined') {
/* 256 */     $result = moduleBookmarkWillToggle(name, item, expireseconds, path);
/* 257 */     if ($result === false) { return; }
/* 258 */   }
/* 259 */ 
/* 260 */   if (!bookmarkId) {
/* 261 */     bookmarkId = "bookmark";
/* 262 */   }
/* 263 */   var bookmark = document.getElementById(bookmarkId);
/* 264 */   toggleClass(bookmark, "on");
/* 265 */   var items = getCookieArrayValue(name);
/* 266 */   var newItems = new Array();
/* 267 */   if (items.length == 0) {
/* 268 */     newItems[0] = item;
/* 269 */   } else {
/* 270 */     var found = false;
/* 271 */     for (var i = 0; i < items.length; i++) {
/* 272 */       if (items[i] == item) {
/* 273 */         found = true;
/* 274 */       } else {
/* 275 */         newItems.push(items[i]);
/* 276 */       }
/* 277 */     }
/* 278 */     if (!found) {
/* 279 */       newItems.push(item);
/* 280 */     }
/* 281 */   }
/* 282 */   setCookieArrayValue(name, newItems, expireseconds, path);
/* 283 */   
/* 284 */   // facility for module to respond to bookmark state change
/* 285 */   if (typeof moduleBookmarkToggled != 'undefined') {
/* 286 */     moduleBookmarkToggled(name, item, expireseconds, path);
/* 287 */   }
/* 288 */ }
/* 289 */ 
/* 290 */ // TODO this needs to handle encoded strings and parameter separators (&amp;)
/* 291 */ if (typeof makeAPICall === 'undefined' && typeof jQuery === 'undefined') {
/* 292 */   function makeAPICall(type, module, command, data, callback) {
/* 293 */     var urlParts = [];
/* 294 */     for (var param in data) {
/* 295 */       urlParts.push(param + "=" + data[param]);
/* 296 */     }
/* 297 */     url = URL_BASE + API_URL_PREFIX + '/' + module + '/' + command + '?' + urlParts.join('&');
/* 298 */     var handleError = function(errorObj) {}
/* 299 */ 
/* 300 */     var httpRequest = new XMLHttpRequest();

/* common.js */

/* 301 */     httpRequest.open("GET", url, true);
/* 302 */     httpRequest.onreadystatechange = function() {
/* 303 */       if (httpRequest.readyState == 4 && httpRequest.status == 200) {
/* 304 */         var obj;
/* 305 */         if (window.JSON) {
/* 306 */             obj = JSON.parse(httpRequest.responseText);
/* 307 */             // TODO: catch SyntaxError
/* 308 */         } else {
/* 309 */             obj = eval('(' + httpRequest.responseText + ')');
/* 310 */         }
/* 311 */         if (obj !== undefined) {
/* 312 */           if ("response" in obj) {
/* 313 */             callback(obj["response"]);
/* 314 */           }
/* 315 */ 
/* 316 */           if ("error" in obj && obj["error"] !== null) {
/* 317 */             handleError(obj["error"]);
/* 318 */           } else {
/* 319 */             handleError("response not found");
/* 320 */           }
/* 321 */         } else {
/* 322 */           handleError("failed to parse response");
/* 323 */         }
/* 324 */       }
/* 325 */     }
/* 326 */     httpRequest.send(null);
/* 327 */   }
/* 328 */ }
/* 329 */ 
/* 330 */ 
/* 331 */ 
/* 332 */ 
/* 333 */ 
/* 334 */ 
/* 335 */ 
/* 336 */ 
/* 337 */ 

;
/* compliant.js */

/* 1 */ function scrollToTop() {
/* 2 */ 	scrollTo(0,1); 
/* 3 */ }
/* 4 */ 
/* 5 */ function onDOMChange() {
/* 6 */   // Not needed for compliant
/* 7 */ }
/* 8 */ 

;
/* common-common-native.js */

/* 1   */ (function (window) {
/* 2   */     function kgoBridgeHandler(config) {
/* 3   */         if (typeof config == 'object') {
/* 4   */             for (var i in config) {
/* 5   */                 this.config[i] = config[i];
/* 6   */             }
/* 7   */         }
/* 8   */     }
/* 9   */     
/* 10  */     kgoBridgeHandler.prototype = {
/* 11  */         config: {
/* 12  */             events: false,  // desktop browser simulation mode
/* 13  */             base: "",
/* 14  */             url: "",
/* 15  */             ajaxArgs: "",
/* 16  */             pagePage: "",
/* 17  */             pageArgs: "",
/* 18  */             serverURL: "",
/* 19  */             timeout: 60,
/* 20  */             localizedStrings: {}
/* 21  */         },
/* 22  */         callbacks : {},
/* 23  */         callbackIdCounter : 0,
/* 24  */         
/* 25  */         // This code list is duplicated in iOS and Android code.  
/* 26  */         // Do not change existing codes!
/* 27  */         errorCodes : {
/* 28  */             KGOBridgeErrorAPINotSupported : 1,
/* 29  */             KGOBridgeErrorJSONConvertFailed : 2
/* 30  */         },
/* 31  */         
/* 32  */         // ====================================================================
/* 33  */         // Bridge API
/* 34  */         // ====================================================================
/* 35  */         
/* 36  */         //
/* 37  */         // Page load
/* 38  */         //
/* 39  */         
/* 40  */         initPage: function (params, statusCallback) {
/* 41  */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 42  */             
/* 43  */             this.nativeAPI("page", "init", params, statusCallback);
/* 44  */         },
/* 45  */         
/* 46  */         //
/* 47  */         // Errors
/* 48  */         //
/* 49  */         
/* 50  */         initPageError: function (httpStatus, title, message) {

/* common-common-native.js */

/* 51  */             switch (httpStatus) {
/* 52  */                 case 401:
/* 53  */                 case 407:
/* 54  */                     title = this.localizedString("ERROR_HTTP_UNAUTHORIZED_REQUEST_TITLE");
/* 55  */                     message = this.localizedString("ERROR_HTTP_UNAUTHORIZED_REQUEST_MESSAGE");
/* 56  */                     break;
/* 57  */                 case 408:
/* 58  */                     title = this.localizedString("ERROR_HTTP_CONNECTION_TIMEOUT_TITLE");
/* 59  */                     message = this.localizedString("ERROR_HTTP_CONNECTION_TIMEOUT_MESSAGE");
/* 60  */                     break;
/* 61  */                 case 404:
/* 62  */                 case 503:
/* 63  */                 default:
/* 64  */                     title = this.localizedString("ERROR_HTTP_CONNECTION_FAILED_TITLE");
/* 65  */                     message = this.localizedString("ERROR_HTTP_CONNECTION_FAILED_MESSAGE");
/* 66  */                     break;
/* 67  */             }
/* 68  */             
/* 69  */             this.handleError("pageinit", httpStatus, title, message);
/* 70  */         },
/* 71  */ 
/* 72  */         handleError: function (errorType, code, title, message) {
/* 73  */             if (typeof title   != "string") { title   = ""; }
/* 74  */             if (typeof message != "string") { message = ""; }
/* 75  */             
/* 76  */             this.nativeAPI("error", errorType, {
/* 77  */                 "code"    : code, 
/* 78  */                 "title"   : title, 
/* 79  */                 "message" : message
/* 80  */             });
/* 81  */         },
/* 82  */         
/* 83  */         //
/* 84  */         // Dialogs
/* 85  */         //
/* 86  */         
/* 87  */         alert: function (message, responseCallback /* optional */) {
/* 88  */             var ok = this.localizedString("BUTTON_OK");
/* 89  */ 
/* 90  */             this.alertDialog(message, null, ok, null, null, function (error, params) {
/* 91  */                 if (typeof responseCallback != "undefined" && responseCallback && error !== null) {
/* 92  */                     responseCallback();
/* 93  */                 }
/* 94  */             }, function (error, params) {
/* 95  */                 if (typeof responseCallback != "undefined" && responseCallback) {
/* 96  */                     responseCallback();
/* 97  */                 }
/* 98  */             });
/* 99  */         },
/* 100 */         

/* common-common-native.js */

/* 101 */         confirm: function (question, responseCallback) {
/* 102 */             var ok = this.localizedString("BUTTON_OK");
/* 103 */             var cancel = this.localizedString("BUTTON_CANCEL");
/* 104 */             
/* 105 */             this.alertDialog(message, null, ok, cancel, null, function (error, params) {
/* 106 */                 if (error !== null) {
/* 107 */                     responseCallback(false);
/* 108 */                 }
/* 109 */             }, function (error, params) {
/* 110 */                 // Return true when main button is pressed
/* 111 */                 responseCallback(error === null && params["button"] == "main");
/* 112 */             });
/* 113 */         },
/* 114 */         
/* 115 */         shareDialog: function (buttonConfig) {
/* 116 */             var buttonTitles = [];
/* 117 */             var actionURLs = [];
/* 118 */             if ("mail" in buttonConfig) {
/* 119 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_EMAIL"));
/* 120 */                 actionURLs.push(buttonConfig["mail"]);
/* 121 */             }
/* 122 */             if ("facebook" in buttonConfig) {
/* 123 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_FACEBOOK"));
/* 124 */                 actionURLs.push(buttonConfig["facebook"]);
/* 125 */             }
/* 126 */             if ("twitter" in buttonConfig) {
/* 127 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_TWITTER"));
/* 128 */                 actionURLs.push(buttonConfig["twitter"]);
/* 129 */             }
/* 130 */             
/* 131 */             var title = this.localizedString("SHARE_THIS_ITEM");
/* 132 */             var cancel = this.localizedString("BUTTON_CANCEL");
/* 133 */             
/* 134 */             var that = this;
/* 135 */             this.actionDialog(title, cancel, null, buttonTitles, null, function(error, params) {
/* 136 */                 if ("button" in params && params["button"].indexOf('alternate') === 0) {
/* 137 */                     var index = +params["button"].substr(9);
/* 138 */                     if (index >= 0 && index < actionURLs.length) {
/* 139 */                         setTimeout(function () {
/* 140 */                             that.loadURL(actionURLs[index]);
/* 141 */                         }, 100);
/* 142 */                     }
/* 143 */                 }
/* 144 */             });
/* 145 */         },
/* 146 */         
/* 147 */         alertDialog: function (title, message, 
/* 148 */                                cancelButtonTitle, mainButtonTitle, alternateButtonTitle, 
/* 149 */                                statusCallback, buttonCallback) {
/* 150 */             // required params

/* common-common-native.js */

/* 151 */             var params = {
/* 152 */                 "title" : title,
/* 153 */                 "cancelButtonTitle" : cancelButtonTitle
/* 154 */             };
/* 155 */             
/* 156 */             // optional params
/* 157 */             if (typeof message == "string") {
/* 158 */                 params["message"] = message;
/* 159 */             }
/* 160 */             if (typeof mainButtonTitle == "string") {
/* 161 */                 params["mainButtonTitle"] = mainButtonTitle;
/* 162 */             }
/* 163 */             if (typeof alternateButtonTitle == "string") {
/* 164 */                 params["alternateButtonTitle"] = alternateButtonTitle;
/* 165 */             }
/* 166 */             
/* 167 */             // optional callbacks
/* 168 */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 169 */             
/* 170 */             var additionalCallbacks = [];
/* 171 */             if (typeof buttonCallback != "undefined") {
/* 172 */                 additionalCallbacks.push({
/* 173 */                     "param"     : "buttonClickedCallback",
/* 174 */                     "callback"  : buttonCallback,
/* 175 */                     "repeating" : false
/* 176 */                 });
/* 177 */             }
/* 178 */             
/* 179 */             this.nativeAPI("dialog", "alert", params, statusCallback, additionalCallbacks);
/* 180 */         },
/* 181 */         
/* 182 */         actionDialog: function (title, 
/* 183 */                                 cancelButtonTitle, destructiveButtonTitle, alternateButtonTitles, 
/* 184 */                                 statusCallback, buttonCallback) {
/* 185 */             // required params
/* 186 */             var params = {
/* 187 */                 "title" : title,
/* 188 */                 "cancelButtonTitle" : cancelButtonTitle
/* 189 */             };
/* 190 */             
/* 191 */             // optional params
/* 192 */             if (typeof destructiveActionTitle == "string") {
/* 193 */                 params["destructiveButtonTitle"] = destructiveButtonTitle;
/* 194 */             }
/* 195 */             if (typeof alternateButtonTitles != "undefined") {
/* 196 */                 for (var i = 0; i < alternateButtonTitles.length; i++) {
/* 197 */                     params["alternateButtonTitle"+i] = alternateButtonTitles[i];
/* 198 */                 }
/* 199 */             }
/* 200 */             

/* common-common-native.js */

/* 201 */             // optional callbacks
/* 202 */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 203 */             
/* 204 */             var additionalCallbacks = [];
/* 205 */             if (typeof buttonCallback != "undefined") {
/* 206 */                 additionalCallbacks.push({
/* 207 */                     "param"     : "buttonClickedCallback",
/* 208 */                     "callback"  : buttonCallback,
/* 209 */                     "repeating" : false
/* 210 */                 });
/* 211 */             }
/* 212 */             
/* 213 */             this.nativeAPI("dialog", "action", params, statusCallback, additionalCallbacks);
/* 214 */         },
/* 215 */ 
/* 216 */         //
/* 217 */         // Events
/* 218 */         //
/* 219 */         
/* 220 */         addEventListener: function (eventType, eventHandlerCallback, statusCallback) {
/* 221 */             var params = {
/* 222 */                 "event" : eventType
/* 223 */             };
/* 224 */             
/* 225 */             this.nativeAPI("listener", "add", params, statusCallback, [{
/* 226 */                 "param"     : "eventHandlerCallback",
/* 227 */                 "callback"  : eventHandlerCallback,
/* 228 */                 "repeating" : true
/* 229 */             }]);
/* 230 */         },
/* 231 */         
/* 232 */         removeEventListener: function (eventType, eventHandlerCallback, statusCallback) {
/* 233 */             var params = {
/* 234 */                 "event" : eventType
/* 235 */             };
/* 236 */             
/* 237 */             this.nativeAPI("listener", "remove", params, statusCallback, [{
/* 238 */                 "param"     : "eventHandlerCallback",
/* 239 */                 "callback"  : eventHandlerCallback,
/* 240 */                 "repeating" : true,
/* 241 */                 "remove"    : true
/* 242 */             }]);
/* 243 */         },
/* 244 */         
/* 245 */         // ====================================================================
/* 246 */         // Low level implementation
/* 247 */         // ====================================================================
/* 248 */         
/* 249 */         nativeAPI: function (category, type, params, statusCallback, additionalCallbacks) {
/* 250 */             var url = "kgobridge://"+escape(category)+"/"+escape(type);

/* common-common-native.js */

/* 251 */             var paramStrings = [];
/* 252 */             if (typeof params == "object") {
/* 253 */                 for (var key in params) {
/* 254 */                     paramStrings.push(escape(key)+"="+escape(params[key]));
/* 255 */                 }
/* 256 */             }
/* 257 */             
/* 258 */             // status callback
/* 259 */             var callbackId = this.callbackIdCounter++;
/* 260 */             this.callbacks[callbackId] = {
/* 261 */                 "callback"  : function (error, params) {
/* 262 */                     if (typeof statusCallback != "undefined" && statusCallback) {
/* 263 */                         statusCallback(error, params);
/* 264 */                     }
/* 265 */                     if (error !== null && typeof additionalCallbacks != "undefined") {
/* 266 */                         // Remove other callbacks on error
/* 267 */                         for (var i = 0; i < additionalCallbacks.length; i++) {
/* 268 */                             if (typeof additionalCallbacks[i]["remove"] == "undefined" || !additionalCallbacks[i]["remove"]) {
/* 269 */                                 var callbackId = this.callbackIdForCallback(additionalCallbacks[i]["callback"]);
/* 270 */                                 if (callbackId) {
/* 271 */                                     delete this.callbacks[callbackId];
/* 272 */                                 }
/* 273 */                             }
/* 274 */                         }
/* 275 */                     }
/* 276 */                 },
/* 277 */                 "repeating" : false
/* 278 */             };
/* 279 */             paramStrings.push("statusCallback="+callbackId);
/* 280 */             
/* 281 */             // additional callbacks
/* 282 */             if (typeof additionalCallbacks != "undefined") {
/* 283 */                 for (var i = 0; i < additionalCallbacks.length; i++) {
/* 284 */                     if (typeof additionalCallbacks[i]["remove"] == "undefined" || !additionalCallbacks[i]["remove"]) {
/* 285 */                         // Adding a callback
/* 286 */                         var callbackId = this.callbackIdCounter++;
/* 287 */                         this.callbacks[callbackId] = {
/* 288 */                             "callback"  : additionalCallbacks[i]["callback"],
/* 289 */                             "repeating" : additionalCallbacks[i]["repeating"]
/* 290 */                         };
/* 291 */                         paramStrings.push(additionalCallbacks[i]["param"]+"="+callbackId);
/* 292 */                         
/* 293 */                     } else {
/* 294 */                         // Removing a callback
/* 295 */                         var callbackId = this.callbackIdForCallback(additionalCallbacks[i]["callback"]);
/* 296 */                         if (callbackId) {
/* 297 */                             paramStrings.push(additionalCallbacks[i]["param"]+"="+callbackId);
/* 298 */                             delete this.callbacks[callbackId];
/* 299 */                         }
/* 300 */                     }

/* common-common-native.js */

/* 301 */                 }
/* 302 */             }
/* 303 */             
/* 304 */             if (paramStrings.length) {
/* 305 */                 url += "?"+paramStrings.join("&");
/* 306 */             }
/* 307 */             
/* 308 */             this.loadURL(url);
/* 309 */         },
/* 310 */         
/* 311 */         nativeAPICallback: function (callbackId, error, params) {
/* 312 */             if (callbackId in this.callbacks && this.callbacks[callbackId]) {
/* 313 */                 if (typeof params !== "object") {
/* 314 */                     params = {};
/* 315 */                 }
/* 316 */                 
/* 317 */                 this.callbacks[callbackId]["callback"](error, params);
/* 318 */                 
/* 319 */                 if (!this.callbacks[callbackId]["repeating"]) {
/* 320 */                     delete this.callbacks[callbackId];
/* 321 */                 }
/* 322 */             }
/* 323 */         },
/* 324 */         
/* 325 */         callbackIdForCallback: function (callback) {
/* 326 */             for (var callbackId in this.callbacks) {
/* 327 */                 if (this.callbacks[callbackId]["callback"] === callback) {
/* 328 */                     return callbackId;
/* 329 */                 }
/* 330 */             }
/* 331 */             return null;
/* 332 */         },
/* 333 */         
/* 334 */         loadURL: function (url) {
/* 335 */             if (this.config.events) {
/* 336 */                 var iframe = document.createElement("IFRAME");
/* 337 */                 iframe.setAttribute("src", url);
/* 338 */                 document.documentElement.appendChild(iframe);
/* 339 */                 iframe.parentNode.removeChild(iframe);
/* 340 */                 iframe = null;
/* 341 */             } else if (typeof console != "undefined" && typeof console.log != "undefined") {
/* 342 */                 console.log("DEBUG_MODE: kgoBridge would have called "+url);
/* 343 */             }
/* 344 */         },
/* 345 */         
/* 346 */         localizedString: function (key) {
/* 347 */             if (key in this.config.localizedStrings) {
/* 348 */                 return this.config.localizedStrings[key];
/* 349 */             } else {
/* 350 */                 return key;

/* common-common-native.js */

/* 351 */             }
/* 352 */         },
/* 353 */         
/* 354 */         ajaxLoad: function () {
/* 355 */             var pageURL = this.config.url+this.config.pagePath+"?"+this.config.ajaxArgs;
/* 356 */             if (this.config.pageArgs.length) {
/* 357 */                 pageURL += "&"+this.config.pageArgs;
/* 358 */             }
/* 359 */             var timeout = this.config.timeout * 1000;
/* 360 */             
/* 361 */             var httpRequest = new XMLHttpRequest();
/* 362 */             httpRequest.open("GET", pageURL, true);
/* 363 */             
/* 364 */             var that = this;
/* 365 */             
/* 366 */             var requestTimer = setTimeout(function() {
/* 367 */                 // some browsers set readyState to 4 on abort so remove handler first
/* 368 */                 httpRequest.onreadystatechange = function() { };
/* 369 */                 httpRequest.abort();
/* 370 */                 
/* 371 */                 that.initPageError(408); // http request timeout status code
/* 372 */             }, timeout);
/* 373 */             
/* 374 */             httpRequest.onreadystatechange = function() {
/* 375 */                 // return if still in progress
/* 376 */                 if (httpRequest.readyState != 4) { return; }
/* 377 */                 
/* 378 */                 // Got answer, don't abort
/* 379 */                 clearTimeout(requestTimer);
/* 380 */                 
/* 381 */                 if (httpRequest.status == 200) {
/* 382 */                     // Success
/* 383 */                     var container = document.getElementById("container");
/* 384 */                     container.innerHTML = httpRequest.responseText;
/* 385 */                     
/* 386 */                     // Grab script tags and appendChild them so they get evaluated
/* 387 */                     var scripts = container.getElementsByTagName("script");
/* 388 */                     var count = scripts.length; // scripts.length will change as we add elements
/* 389 */                     
/* 390 */                     for (var i = 0; i < count; i++) {
/* 391 */                         var script = document.createElement("script");
/* 392 */                         script.type = "text/javascript";
/* 393 */                         script.text = scripts[i].text;
/* 394 */                         container.appendChild(script);
/* 395 */                     }
/* 396 */                     
/* 397 */                     if (typeof kgoBridgeOnAjaxLoad != 'undefined') {
/* 398 */                         kgoBridgeOnAjaxLoad();
/* 399 */                     } else {
/* 400 */                         console.log("Warning! kgoBridgeOnAjaxLoad is not defined by the page content");

/* common-common-native.js */

/* 401 */                     }
/* 402 */                     
/* 403 */                 } else {
/* 404 */                     // Error
/* 405 */                     that.initPageError(httpRequest.status);
/* 406 */                 }
/* 407 */             }
/* 408 */             
/* 409 */             httpRequest.send(null);
/* 410 */         },
/* 411 */         
/* 412 */         bridgeToAjaxLink: function (href) {
/* 413 */             // must be able to pass through non-kgobridge links
/* 414 */             var bridgePrefix = "kgobridge://link/";
/* 415 */             var oldhref= href;
/* 416 */             if (href.indexOf(bridgePrefix) == 0) {
/* 417 */                 href = this.config.url+"/"+href.substr(bridgePrefix.length);
/* 418 */                 
/* 419 */                 var anchor = '';
/* 420 */                 var anchorPos = href.indexOf("#");
/* 421 */                 if (anchorPos > 0) {
/* 422 */                     anchor = href.substr(anchorPos);
/* 423 */                     href = href.substr(0, anchorPos);
/* 424 */                 }
/* 425 */                 href = href+(href.indexOf("?") > 0 ? "&" : "?")+this.config.ajaxArgs+anchor;
/* 426 */             }
/* 427 */             return href;
/* 428 */         }
/* 429 */     };
/* 430 */     
/* 431 */     window.kgoBridgeHandler = kgoBridgeHandler;
/* 432 */ })(window);
/* 433 */ 

;
/* common-iphone-native.js */

/* 1 */ 

;
/* common.js */

/* 1  */ // Initalize the ellipsis event handlers
/* 2  */ var newsEllipsizer;
/* 3  */ function setupNewsListing() {
/* 4  */     newsEllipsizer = new ellipsizer();
/* 5  */     
/* 6  */     // cap at 100 divs to avoid overloading phone
/* 7  */     for (var i = 0; i < 100; i++) {
/* 8  */         var elem = document.getElementById('ellipsis_'+i);
/* 9  */         if (!elem) { break; }
/* 10 */         newsEllipsizer.addElement(elem);
/* 11 */     }
/* 12 */ }
/* 13 */ 
