
/* common.js */

/* 1   */ var currentTab;
/* 2   */ 
/* 3   */ String.prototype.strip = function() {
/* 4   */     return this.replace(/^\s+/, '').replace(/\s+$/, '');
/* 5   */ }
/* 6   */ 
/* 7   */ function showTab(strID, objTrigger) {
/* 8   */ // Displays the tab with ID strID
/* 9   */ 	var objTab = document.getElementById(strID);
/* 10  */ 	if(objTab) {
/* 11  */ 		show(strID);
/* 12  */ 		if(currentTab && (currentTab != objTab)) {
/* 13  */ 			hide(currentTab.id);
/* 14  */ 			//currentTab.style.display = "none";
/* 15  */ 		}
/* 16  */ 	}
/* 17  */ 	currentTab = objTab; // Remember which is the currently displayed tab
/* 18  */ 	
/* 19  */ 	// Set the clicked tab to look current
/* 20  */ 	var objTabs = document.getElementById("tabs");
/* 21  */   if (objTabs) {
/* 22  */     var arrTabs = objTabs.getElementsByTagName("li");
/* 23  */     if(objTrigger) {
/* 24  */       for(var i=0; i<arrTabs.length; i++) {
/* 25  */         arrTabs[i].className="";
/* 26  */       }
/* 27  */       var objTriggerTab = objTrigger.parentNode;
/* 28  */       if(objTriggerTab) {
/* 29  */         objTriggerTab.className="active";
/* 30  */       }
/* 31  */     }
/* 32  */ 
/* 33  */     // fake resize event in case tab body was resized while hidden 
/* 34  */     if (document.createEvent) {
/* 35  */       var e = document.createEvent('HTMLEvents');
/* 36  */       e.initEvent('resize', true, true);
/* 37  */       window.dispatchEvent(e);
/* 38  */     
/* 39  */     } else if( document.createEventObject ) {
/* 40  */       var e = document.createEventObject();
/* 41  */       document.documentElement.fireEvent('onresize', e);
/* 42  */     }
/* 43  */   }
/* 44  */ 	
/* 45  */ 	onDOMChange();
/* 46  */ }
/* 47  */ 
/* 48  */ function rotateScreen() {
/* 49  */   setOrientation(getOrientation());
/* 50  */   setTimeout(scrollToTop, 500);

/* common.js */

/* 51  */ }
/* 52  */ 
/* 53  */ function getOrientation() {
/* 54  */     if (typeof getOrientation.orientationIsFlipped == 'undefined') {
/* 55  */         // detect how we are detecting orientation
/* 56  */         getOrientation.orientationIsFlipped = false;
/* 57  */         
/* 58  */         if (!('orientation' in window)) {
/* 59  */             getOrientation.orientationMethod = 'size';
/* 60  */         } else {
/* 61  */             getOrientation.orientationMethod = 'orientation';
/* 62  */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 63  */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 64  */             
/* 65  */             /* at this point the method of orientation detection is not perfect */
/* 66  */             if (navigator.userAgent.match(/(PlayBook.+RIM Tablet|Xoom|Android 3\.\d)/)) {
/* 67  */                 getOrientation.orientationIsFlipped = true;
/* 68  */             }
/* 69  */         }
/* 70  */     }
/* 71  */ 
/* 72  */     switch (getOrientation.orientationMethod) {
/* 73  */         case 'size':
/* 74  */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 75  */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 76  */ 
/* 77  */             return (width > height) ? 'landscape' : 'portrait';
/* 78  */             break;
/* 79  */ 
/* 80  */         case 'orientation':
/* 81  */             switch (window.orientation) {
/* 82  */                 case 0:
/* 83  */                 case 180:
/* 84  */                     return getOrientation.orientationIsFlipped ? 'landscape' : 'portrait';
/* 85  */                     break;
/* 86  */                 
/* 87  */                 case 90:
/* 88  */                 case -90:
/* 89  */                     return getOrientation.orientationIsFlipped ? 'portrait': 'landscape';
/* 90  */                     break;
/* 91  */             }
/* 92  */     }
/* 93  */ }
/* 94  */ 
/* 95  */ function setOrientation(orientation) {
/* 96  */     var body = document.getElementsByTagName("body")[0];
/* 97  */  
/* 98  */  //remove existing portrait/landscape class if there
/* 99  */     removeClass(body, 'portrait');
/* 100 */     removeClass(body, 'landscape');

/* common.js */

/* 101 */     addClass(body, orientation);
/* 102 */ }
/* 103 */ 
/* 104 */ 
/* 105 */ function showLoadingMsg(strID) {
/* 106 */ // Show a temporary loading message in the element with ID strID
/* 107 */ 	var objToStuff = document.getElementById(strID);
/* 108 */ 	if(objToStuff) {
/* 109 */ 		objToStuff.innerHTML = '<div class="loading"><img src="'+URL_BASE+'common/images/loading.gif" width="27" height="21" alt="Loading" align="absmiddle" />Loading data...</div>';
/* 110 */ 	}
/* 111 */ 	onDOMChange();
/* 112 */ }
/* 113 */ 
/* 114 */ function hide(strID) {
/* 115 */ // Hides the object with ID strID 
/* 116 */ 	var objToHide = document.getElementById(strID);
/* 117 */ 	if(objToHide) {
/* 118 */ 		objToHide.style.display = "none";
/* 119 */ 	}
/* 120 */ 	
/* 121 */ 	onDOMChange();
/* 122 */ }
/* 123 */ 
/* 124 */ function show(strID) {
/* 125 */ // Displays the object with ID strID 
/* 126 */ 	var objToHide = document.getElementById(strID);
/* 127 */ 	if(objToHide) {
/* 128 */ 		objToHide.style.display = "block";
/* 129 */ 	}
/* 130 */ 	
/* 131 */ 	onDOMChange();
/* 132 */ }
/* 133 */ 
/* 134 */ function showHideFull(objContainer) {
/* 135 */ 	var strClass = objContainer.className;
/* 136 */ 	if(strClass.indexOf("collapsed") > -1) {
/* 137 */ 		strClass = strClass.replace("collapsed","expanded");
/* 138 */ 	} else {
/* 139 */ 		strClass = strClass.replace("expanded","collapsed");
/* 140 */ 	}
/* 141 */ 	objContainer.className = strClass;
/* 142 */ 	objContainer.blur();
/* 143 */ 	
/* 144 */ 	onDOMChange();
/* 145 */ }
/* 146 */ 
/* 147 */ function clearField(objField,strDefault) {
/* 148 */ // Clears the placeholder text in an input field if it matches the default string - fixes a bug in Android
/* 149 */ 	if((objField.value==strDefault) || (objField.value=="")) {
/* 150 */ 		objField.value="";

/* common.js */

/* 151 */ 	}
/* 152 */ }
/* 153 */ 
/* 154 */ // Android doesn't respond to onfocus="clearField(...)" until the 
/* 155 */ // input field loses focus
/* 156 */ function androidPlaceholderFix(searchbox) {
/* 157 */     // this forces the search box to display the empty string
/* 158 */     // instead of the place holder when the search box takes focus
/* 159 */     if (searchbox.value == "") {
/* 160 */         searchbox.value = "";
/* 161 */     }
/* 162 */ }
/* 163 */ 
/* 164 */ function getCookie(name) {
/* 165 */   var cookie = document.cookie;
/* 166 */   var result = "";
/* 167 */   var start = cookie.indexOf(name + "=");
/* 168 */   if (start > -1) {
/* 169 */     start += name.length + 1;
/* 170 */     var end = cookie.indexOf(";", start);
/* 171 */     if (end < 0) {
/* 172 */       end = cookie.length;
/* 173 */     }
/* 174 */     result = unescape(cookie.substring(start, end));
/* 175 */   }
/* 176 */   return result;
/* 177 */ }
/* 178 */ 
/* 179 */ function setCookie(name, value, expireseconds, path) {
/* 180 */   var exdate = new Date();
/* 181 */   exdate.setTime(exdate.getTime() + (expireseconds * 1000));
/* 182 */   var exdateclause = (expireseconds == 0) ? "" : "; expires=" + exdate.toGMTString();
/* 183 */   var pathclause = (path == null) ? "" : "; path=" + path;
/* 184 */   document.cookie = name + "=" + escape(value) + exdateclause + pathclause;
/* 185 */ }
/* 186 */ 
/* 187 */ function getCookieArrayValue(name) {
/* 188 */   var value = getCookie(name);
/* 189 */   if (value && value.length) {
/* 190 */     return value.split('@@');
/* 191 */   } else {
/* 192 */     return new Array();
/* 193 */   }
/* 194 */ }
/* 195 */ 
/* 196 */ function setCookieArrayValue(name, values, expireseconds, path) {
/* 197 */   var value = '';
/* 198 */   if (values && values.length) {
/* 199 */     value = values.join('@@');
/* 200 */   }

/* common.js */

/* 201 */   setCookie(name, value, expireseconds, path);
/* 202 */ }
/* 203 */ 
/* 204 */ function hasClass(ele,cls) {
/* 205 */     return ele.className.match(new RegExp('(\\s|^)'+cls+'(\\s|$)'));
/* 206 */ }
/* 207 */         
/* 208 */ function addClass(ele,cls) {
/* 209 */     if (!this.hasClass(ele,cls)) ele.className += " "+cls;
/* 210 */ }
/* 211 */ 
/* 212 */ function removeClass(ele,cls) {
/* 213 */     if (hasClass(ele,cls)) {
/* 214 */         var reg = new RegExp('(\\s|^)'+cls+'(\\s|$)');
/* 215 */         ele.className=ele.className.replace(reg,' ').strip();
/* 216 */     }
/* 217 */ }
/* 218 */         
/* 219 */ function toggleClass(ele, cls) {
/* 220 */     if (hasClass(ele, cls)) {
/* 221 */         removeClass(ele, cls);
/* 222 */     } else {
/* 223 */         addClass(ele, cls);
/* 224 */     }
/* 225 */ }
/* 226 */ 
/* 227 */ // Share-related functions
/* 228 */ function showShare() {
/* 229 */     if (!document.getElementById("sharesheet")) {
/* 230 */         return;
/* 231 */     }
/* 232 */ 	document.getElementById("sharesheet").style.display="block";
/* 233 */ 	var iframes = document.getElementsByTagName('iframe');
/* 234 */ 	for (var i=0; i<iframes.length; i++) {
/* 235 */ 	    iframes[i].style.visibility = 'hidden';
/* 236 */ 	    iframes[i].style.height = '0';
/* 237 */ 	}
/* 238 */ 	window.scrollTo(0,0);
/* 239 */ }
/* 240 */ function hideShare() {
/* 241 */     if (!document.getElementById("sharesheet")) {
/* 242 */         return;
/* 243 */     }
/* 244 */ 	document.getElementById("sharesheet").style.display="none";
/* 245 */ 	var iframes = document.getElementsByTagName('iframe');
/* 246 */ 	for (var i=0; i<iframes.length; i++) {
/* 247 */ 	    iframes[i].style.visibility = 'visible';
/* 248 */ 	    iframes[i].style.height = '';
/* 249 */ 	}
/* 250 */ }

/* common.js */

/* 251 */ 
/* 252 */ // Bookmarks
/* 253 */ function toggleBookmark(name, item, expireseconds, path, bookmarkId) {
/* 254 */   // facility for module to respond to bookmark state change
/* 255 */   if (typeof moduleBookmarkWillToggle != 'undefined') {
/* 256 */     $result = moduleBookmarkWillToggle(name, item, expireseconds, path);
/* 257 */     if ($result === false) { return; }
/* 258 */   }
/* 259 */ 
/* 260 */   if (!bookmarkId) {
/* 261 */     bookmarkId = "bookmark";
/* 262 */   }
/* 263 */   var bookmark = document.getElementById(bookmarkId);
/* 264 */   toggleClass(bookmark, "on");
/* 265 */   var items = getCookieArrayValue(name);
/* 266 */   var newItems = new Array();
/* 267 */   if (items.length == 0) {
/* 268 */     newItems[0] = item;
/* 269 */   } else {
/* 270 */     var found = false;
/* 271 */     for (var i = 0; i < items.length; i++) {
/* 272 */       if (items[i] == item) {
/* 273 */         found = true;
/* 274 */       } else {
/* 275 */         newItems.push(items[i]);
/* 276 */       }
/* 277 */     }
/* 278 */     if (!found) {
/* 279 */       newItems.push(item);
/* 280 */     }
/* 281 */   }
/* 282 */   setCookieArrayValue(name, newItems, expireseconds, path);
/* 283 */   
/* 284 */   // facility for module to respond to bookmark state change
/* 285 */   if (typeof moduleBookmarkToggled != 'undefined') {
/* 286 */     moduleBookmarkToggled(name, item, expireseconds, path);
/* 287 */   }
/* 288 */ }
/* 289 */ 
/* 290 */ // TODO this needs to handle encoded strings and parameter separators (&amp;)
/* 291 */ if (typeof makeAPICall === 'undefined' && typeof jQuery === 'undefined') {
/* 292 */   function makeAPICall(type, module, command, data, callback) {
/* 293 */     var urlParts = [];
/* 294 */     for (var param in data) {
/* 295 */       urlParts.push(param + "=" + data[param]);
/* 296 */     }
/* 297 */     url = URL_BASE + API_URL_PREFIX + '/' + module + '/' + command + '?' + urlParts.join('&');
/* 298 */     var handleError = function(errorObj) {}
/* 299 */ 
/* 300 */     var httpRequest = new XMLHttpRequest();

/* common.js */

/* 301 */     httpRequest.open("GET", url, true);
/* 302 */     httpRequest.onreadystatechange = function() {
/* 303 */       if (httpRequest.readyState == 4 && httpRequest.status == 200) {
/* 304 */         var obj;
/* 305 */         if (window.JSON) {
/* 306 */             obj = JSON.parse(httpRequest.responseText);
/* 307 */             // TODO: catch SyntaxError
/* 308 */         } else {
/* 309 */             obj = eval('(' + httpRequest.responseText + ')');
/* 310 */         }
/* 311 */         if (obj !== undefined) {
/* 312 */           if ("response" in obj) {
/* 313 */             callback(obj["response"]);
/* 314 */           }
/* 315 */ 
/* 316 */           if ("error" in obj && obj["error"] !== null) {
/* 317 */             handleError(obj["error"]);
/* 318 */           } else {
/* 319 */             handleError("response not found");
/* 320 */           }
/* 321 */         } else {
/* 322 */           handleError("failed to parse response");
/* 323 */         }
/* 324 */       }
/* 325 */     }
/* 326 */     httpRequest.send(null);
/* 327 */   }
/* 328 */ }
/* 329 */ 
/* 330 */ 
/* 331 */ 
/* 332 */ 
/* 333 */ 
/* 334 */ 
/* 335 */ 
/* 336 */ 
/* 337 */ 

;
/* compliant.js */

/* 1 */ function scrollToTop() {
/* 2 */ 	scrollTo(0,1); 
/* 3 */ }
/* 4 */ 
/* 5 */ function onDOMChange() {
/* 6 */   // Not needed for compliant
/* 7 */ }
/* 8 */ 

;
/* common-common-native.js */

/* 1   */ (function (window) {
/* 2   */     function kgoBridgeHandler(config) {
/* 3   */         if (typeof config == 'object') {
/* 4   */             for (var i in config) {
/* 5   */                 this.config[i] = config[i];
/* 6   */             }
/* 7   */         }
/* 8   */     }
/* 9   */     
/* 10  */     kgoBridgeHandler.prototype = {
/* 11  */         config: {
/* 12  */             events: false,  // desktop browser simulation mode
/* 13  */             base: "",
/* 14  */             url: "",
/* 15  */             ajaxArgs: "",
/* 16  */             pagePage: "",
/* 17  */             pageArgs: "",
/* 18  */             serverURL: "",
/* 19  */             timeout: 60,
/* 20  */             localizedStrings: {}
/* 21  */         },
/* 22  */         callbacks : {},
/* 23  */         callbackIdCounter : 0,
/* 24  */         
/* 25  */         localizedString: function (key) {
/* 26  */             if (key in this.config.localizedStrings) {
/* 27  */                 return this.config.localizedStrings[key];
/* 28  */             } else {
/* 29  */                 return key;
/* 30  */             }
/* 31  */         },
/* 32  */         
/* 33  */         ajaxLoad: function () {
/* 34  */             var pageURL = this.config.url+this.config.pagePath+"?"+this.config.ajaxArgs;
/* 35  */             if (this.config.pageArgs.length) {
/* 36  */                 pageURL += "&"+this.config.pageArgs;
/* 37  */             }
/* 38  */             var timeout = this.config.timeout * 1000;
/* 39  */             
/* 40  */             var httpRequest = new XMLHttpRequest();
/* 41  */             httpRequest.open("GET", pageURL, true);
/* 42  */             
/* 43  */             var that = this;
/* 44  */             
/* 45  */             var requestTimer = setTimeout(function() {
/* 46  */                 // some browsers set readyState to 4 on abort so remove handler first
/* 47  */                 httpRequest.onreadystatechange = function() { };
/* 48  */                 httpRequest.abort();
/* 49  */                 
/* 50  */                 that.initPageError(408); // http request timeout status code

/* common-common-native.js */

/* 51  */             }, timeout);
/* 52  */             
/* 53  */             httpRequest.onreadystatechange = function() {
/* 54  */                 // return if still in progress
/* 55  */                 if (httpRequest.readyState != 4) { return; }
/* 56  */                 
/* 57  */                 // Got answer, don't abort
/* 58  */                 clearTimeout(requestTimer);
/* 59  */                 
/* 60  */                 if (httpRequest.status == 200) {
/* 61  */                     // Success
/* 62  */                     var container = document.getElementById("container");
/* 63  */                     container.innerHTML = httpRequest.responseText;
/* 64  */                     
/* 65  */                     // Grab script tags and appendChild them so they get evaluated
/* 66  */                     var scripts = container.getElementsByTagName("script");
/* 67  */                     var count = scripts.length; // scripts.length will change as we add elements
/* 68  */                     
/* 69  */                     for (var i = 0; i < count; i++) {
/* 70  */                         var script = document.createElement("script");
/* 71  */                         script.type = "text/javascript";
/* 72  */                         script.text = scripts[i].text;
/* 73  */                         container.appendChild(script);
/* 74  */                     }
/* 75  */                     
/* 76  */                     if (typeof kgoBridgeOnAjaxLoad != 'undefined') {
/* 77  */                         kgoBridgeOnAjaxLoad();
/* 78  */                     } else {
/* 79  */                         console.log("Warning! kgoBridgeOnAjaxLoad is not defined by the page content");
/* 80  */                     }
/* 81  */                     
/* 82  */                 } else {
/* 83  */                     // Error
/* 84  */                     that.initPageError(httpRequest.status);
/* 85  */                 }
/* 86  */             }
/* 87  */             
/* 88  */             httpRequest.send(null);
/* 89  */         },
/* 90  */         
/* 91  */         bridgeToAjaxLink: function (href) {
/* 92  */             // must be able to pass through non-kgobridge links
/* 93  */             var bridgePrefix = "kgobridge://link/";
/* 94  */             var oldhref= href;
/* 95  */             if (href.indexOf(bridgePrefix) == 0) {
/* 96  */                 href = this.config.url+"/"+href.substr(bridgePrefix.length);
/* 97  */                 
/* 98  */                 var anchor = '';
/* 99  */                 var anchorPos = href.indexOf("#");
/* 100 */                 if (anchorPos > 0) {

/* common-common-native.js */

/* 101 */                     anchor = href.substr(anchorPos);
/* 102 */                     href = href.substr(0, anchorPos);
/* 103 */                 }
/* 104 */                 href = href+(href.indexOf("?") > 0 ? "&" : "?")+this.config.ajaxArgs+anchor;
/* 105 */             }
/* 106 */             return href;
/* 107 */         },
/* 108 */         
/* 109 */         //
/* 110 */         // Page load
/* 111 */         //
/* 112 */         
/* 113 */         initPage: function (params, statusCallback) {
/* 114 */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 115 */             
/* 116 */             this.nativeAPI("page", "init", params, statusCallback);
/* 117 */         },
/* 118 */         
/* 119 */         //
/* 120 */         // Errors
/* 121 */         //
/* 122 */         
/* 123 */         initPageError: function (status, title, message) {
/* 124 */             this.handleError("pageinit", status, title, message);
/* 125 */         },
/* 126 */ 
/* 127 */         handleError: function (errorType, code, title, message) {
/* 128 */             if (typeof title   != "string") { title   = ""; }
/* 129 */             if (typeof message != "string") { message = ""; }
/* 130 */             
/* 131 */             this.nativeAPI("error", errorType, {
/* 132 */                 "code"    : code, 
/* 133 */                 "title"   : title, 
/* 134 */                 "message" : message
/* 135 */             });
/* 136 */         },
/* 137 */         
/* 138 */         //
/* 139 */         // Dialogs
/* 140 */         //
/* 141 */         
/* 142 */         alert: function (message, responseCallback /* optional */) {
/* 143 */             var ok = this.localizedString("BUTTON_OK");
/* 144 */ 
/* 145 */             this.alertDialog(message, null, ok, null, null, function (error, params) {
/* 146 */                 if (typeof responseCallback != "undefined" && responseCallback && error !== null) {
/* 147 */                     responseCallback();
/* 148 */                 }
/* 149 */             }, function (error, params) {
/* 150 */                 if (typeof responseCallback != "undefined" && responseCallback) {

/* common-common-native.js */

/* 151 */                     responseCallback();
/* 152 */                 }
/* 153 */             });
/* 154 */         },
/* 155 */         
/* 156 */         confirm: function (question, responseCallback) {
/* 157 */             var ok = this.localizedString("BUTTON_OK");
/* 158 */             var cancel = this.localizedString("BUTTON_CANCEL");
/* 159 */             
/* 160 */             this.alertDialog(message, null, ok, cancel, null, function (error, params) {
/* 161 */                 if (error !== null) {
/* 162 */                     responseCallback(false);
/* 163 */                 }
/* 164 */             }, function (error, params) {
/* 165 */                 // Return true when main button is pressed
/* 166 */                 responseCallback(error === null && params["button"] == "main");
/* 167 */             });
/* 168 */         },
/* 169 */         
/* 170 */         shareDialog: function (buttonConfig) {
/* 171 */             var buttonTitles = [];
/* 172 */             var actionURLs = [];
/* 173 */             if ("email" in buttonConfig) {
/* 174 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_EMAIL"));
/* 175 */                 actionURLs.push(buttonConfig["email"]);
/* 176 */             }
/* 177 */             if ("facebook" in buttonConfig) {
/* 178 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_FACEBOOK"));
/* 179 */                 actionURLs.push(buttonConfig["email"]);
/* 180 */             }
/* 181 */             if ("twitter" in buttonConfig) {
/* 182 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_TWITTER"));
/* 183 */                 actionURLs.push(buttonConfig["email"]);
/* 184 */             }
/* 185 */             
/* 186 */             var title = this.localizedString("SHARE_THIS_ITEM");
/* 187 */             var cancel = this.localizedString("BUTTON_CANCEL");
/* 188 */             
/* 189 */             this.actionDialog(title, cancel, null, buttonTitles, null, function(error, params) {
/* 190 */                 if ("button" in params && params["button"].indexOf('alternate') === 0) {
/* 191 */                     var index = +params["button"].substr(9);
/* 192 */                     if (index >= 0 && index < actionURLs.length) {
/* 193 */                         setTimeout(function () {
/* 194 */                             this.loadURL(actionURLs[index]);
/* 195 */                         }, 100);
/* 196 */                     }
/* 197 */                 }
/* 198 */             });
/* 199 */         },
/* 200 */         

/* common-common-native.js */

/* 201 */         alertDialog: function (title, message, 
/* 202 */                                cancelButtonTitle, mainButtonTitle, alternateButtonTitle, 
/* 203 */                                statusCallback, buttonCallback) {
/* 204 */             // required params
/* 205 */             var params = {
/* 206 */                 "title" : title,
/* 207 */                 "cancelButtonTitle" : cancelButtonTitle
/* 208 */             };
/* 209 */             
/* 210 */             // optional params
/* 211 */             if (typeof message == "string") {
/* 212 */                 params["message"] = message;
/* 213 */             }
/* 214 */             if (typeof mainButtonTitle == "string") {
/* 215 */                 params["mainButtonTitle"] = mainButtonTitle;
/* 216 */             }
/* 217 */             if (typeof alternateButtonTitle == "string") {
/* 218 */                 params["alternateButtonTitle"] = alternateButtonTitle;
/* 219 */             }
/* 220 */             
/* 221 */             // optional callbacks
/* 222 */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 223 */             
/* 224 */             var additionalCallbacks = [];
/* 225 */             if (typeof buttonCallback != "undefined") {
/* 226 */                 additionalCallbacks.push({
/* 227 */                     "param"     : "buttonClickedCallback",
/* 228 */                     "callback"  : buttonCallback,
/* 229 */                     "repeating" : false
/* 230 */                 });
/* 231 */             }
/* 232 */             
/* 233 */             this.nativeAPI("dialog", "alert", params, statusCallback, additionalCallbacks);
/* 234 */         },
/* 235 */         
/* 236 */         actionDialog: function (title, 
/* 237 */                                 cancelButtonTitle, destructiveButtonTitle, alternateButtonTitles, 
/* 238 */                                 statusCallback, buttonCallback) {
/* 239 */             // required params
/* 240 */             var params = {
/* 241 */                 "title" : title,
/* 242 */                 "cancelButtonTitle" : cancelButtonTitle
/* 243 */             };
/* 244 */             
/* 245 */             // optional params
/* 246 */             if (typeof destructiveActionTitle == "string") {
/* 247 */                 params["destructiveButtonTitle"] = destructiveButtonTitle;
/* 248 */             }
/* 249 */             if (typeof alternateButtonTitles != "undefined") {
/* 250 */                 for (var i = 0; i < alternateButtonTitles.length; i++) {

/* common-common-native.js */

/* 251 */                     params["alternateButtonTitle"+i] = alternateButtonTitles[i];
/* 252 */                 }
/* 253 */             }
/* 254 */             
/* 255 */             // optional callbacks
/* 256 */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 257 */             
/* 258 */             var additionalCallbacks = [];
/* 259 */             if (typeof buttonCallback != "undefined") {
/* 260 */                 additionalCallbacks.push({
/* 261 */                     "param"     : "buttonClickedCallback",
/* 262 */                     "callback"  : buttonCallback,
/* 263 */                     "repeating" : false
/* 264 */                 });
/* 265 */             }
/* 266 */             
/* 267 */             this.nativeAPI("dialog", "action", params, statusCallback, additionalCallbacks);
/* 268 */         },
/* 269 */ 
/* 270 */         //
/* 271 */         // Events
/* 272 */         //
/* 273 */         
/* 274 */         addEventListener: function (eventType, eventHandlerCallback, statusCallback) {
/* 275 */             var params = {
/* 276 */                 "event" : eventType
/* 277 */             };
/* 278 */             
/* 279 */             this.nativeAPI("listener", "add", params, statusCallback, [{
/* 280 */                 "param"     : "eventHandlerCallback",
/* 281 */                 "callback"  : eventHandlerCallback,
/* 282 */                 "repeating" : true
/* 283 */             }]);
/* 284 */         },
/* 285 */         
/* 286 */         removeEventListener: function (eventType, eventHandlerCallback, statusCallback) {
/* 287 */             var params = {
/* 288 */                 "event" : eventType
/* 289 */             };
/* 290 */             
/* 291 */             this.nativeAPI("listener", "remove", params, statusCallback, [{
/* 292 */                 "param"     : "eventHandlerCallback",
/* 293 */                 "callback"  : eventHandlerCallback,
/* 294 */                 "repeating" : true,
/* 295 */                 "remove"    : true
/* 296 */             }]);
/* 297 */         },
/* 298 */         
/* 299 */         //
/* 300 */         // Low level implementation

/* common-common-native.js */

/* 301 */         //
/* 302 */         
/* 303 */         nativeAPI: function (category, type, params, statusCallback, additionalCallbacks) {
/* 304 */             var url = "kgobridge://"+escape(category)+"/"+escape(type);
/* 305 */             var paramStrings = [];
/* 306 */             if (typeof params == "object") {
/* 307 */                 for (var key in params) {
/* 308 */                     paramStrings.push(escape(key)+"="+escape(params[key]));
/* 309 */                 }
/* 310 */             }
/* 311 */             
/* 312 */             // status callback
/* 313 */             var callbackId = this.callbackIdCounter++;
/* 314 */             this.callbacks[callbackId] = {
/* 315 */                 "callback"  : function (error, params) {
/* 316 */                     if (typeof statusCallback != "undefined" && statusCallback) {
/* 317 */                         statusCallback(error, params);
/* 318 */                     }
/* 319 */                     if (error !== null && typeof additionalCallbacks != "undefined") {
/* 320 */                         // Remove other callbacks on error
/* 321 */                         for (var i = 0; i < additionalCallbacks.length; i++) {
/* 322 */                             if (typeof additionalCallbacks[i]["remove"] == "undefined" || !additionalCallbacks[i]["remove"]) {
/* 323 */                                 var callbackId = this.callbackIdForCallback(additionalCallbacks[i]["callback"]);
/* 324 */                                 if (callbackId) {
/* 325 */                                     delete this.callbacks[callbackId];
/* 326 */                                 }
/* 327 */                             }
/* 328 */                         }
/* 329 */                     }
/* 330 */                 },
/* 331 */                 "repeating" : false
/* 332 */             };
/* 333 */             paramStrings.push("statusCallback="+callbackId);
/* 334 */             
/* 335 */             // additional callbacks
/* 336 */             if (typeof additionalCallbacks != "undefined") {
/* 337 */                 for (var i = 0; i < additionalCallbacks.length; i++) {
/* 338 */                     if (typeof additionalCallbacks[i]["remove"] == "undefined" || !additionalCallbacks[i]["remove"]) {
/* 339 */                         // Adding a callback
/* 340 */                         var callbackId = this.callbackIdCounter++;
/* 341 */                         this.callbacks[callbackId] = {
/* 342 */                             "callback"  : additionalCallbacks[i]["callback"],
/* 343 */                             "repeating" : additionalCallbacks[i]["repeating"]
/* 344 */                         };
/* 345 */                         paramStrings.push(additionalCallbacks[i]["param"]+"="+callbackId);
/* 346 */                         
/* 347 */                     } else {
/* 348 */                         // Removing a callback
/* 349 */                         var callbackId = this.callbackIdForCallback(additionalCallbacks[i]["callback"]);
/* 350 */                         if (callbackId) {

/* common-common-native.js */

/* 351 */                             paramStrings.push(additionalCallbacks[i]["param"]+"="+callbackId);
/* 352 */                             delete this.callbacks[callbackId];
/* 353 */                         }
/* 354 */                     }
/* 355 */                 }
/* 356 */             }
/* 357 */             
/* 358 */             if (paramStrings.length) {
/* 359 */                 url += "?"+paramStrings.join("&");
/* 360 */             }
/* 361 */             
/* 362 */             this.loadURL(url);
/* 363 */         },
/* 364 */         
/* 365 */         nativeAPICallback: function (callbackId, error, params) {
/* 366 */             if (callbackId in this.callbacks && this.callbacks[callbackId]) {
/* 367 */                 if (typeof params !== "object") {
/* 368 */                     params = {};
/* 369 */                 }
/* 370 */                 
/* 371 */                 this.callbacks[callbackId]["callback"](error, params);
/* 372 */                 
/* 373 */                 if (!this.callbacks[callbackId]["repeating"]) {
/* 374 */                     delete this.callbacks[callbackId];
/* 375 */                 }
/* 376 */             }
/* 377 */         },
/* 378 */         
/* 379 */         callbackIdForCallback: function (callback) {
/* 380 */             for (var callbackId in this.callbacks) {
/* 381 */                 if (this.callbacks[callbackId]["callback"] === callback) {
/* 382 */                     return callbackId;
/* 383 */                 }
/* 384 */             }
/* 385 */             return null;
/* 386 */         },
/* 387 */         
/* 388 */         loadURL: function (url) {
/* 389 */             if (this.config.events) {
/* 390 */                 var iframe = document.createElement("IFRAME");
/* 391 */                 iframe.setAttribute("src", url);
/* 392 */                 document.documentElement.appendChild(iframe);
/* 393 */                 iframe.parentNode.removeChild(iframe);
/* 394 */                 iframe = null;
/* 395 */             } else {
/* 396 */                 alert("bridgeCallback: "+url);
/* 397 */             }
/* 398 */         }
/* 399 */     };
/* 400 */     

/* common-common-native.js */

/* 401 */     window.kgoBridgeHandler = kgoBridgeHandler;
/* 402 */ })(window);
/* 403 */ 

;
/* common-iphone-native.js */

/* 1 */ 

;
/* common.js */

/* 1  */ // Initialize the ellipsis event handlers
/* 2  */ function setupListing() {
/* 3  */     var anEllipsizer = new ellipsizer();
/* 4  */     
/* 5  */     // cap at 100 divs to avoid overloading phone
/* 6  */     for (var i = 0; i < 100; i++) {
/* 7  */         var elem = document.getElementById('ellipsis_'+i);
/* 8  */         if (!elem) { break; }
/* 9  */         anEllipsizer.addElement(elem);
/* 10 */     }
/* 11 */ }
/* 12 */ 
