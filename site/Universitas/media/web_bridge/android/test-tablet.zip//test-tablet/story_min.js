
/* common.js */

/* 1   */ String.prototype.strip = function() {
/* 2   */     return this.replace(/^\s+/, '').replace(/\s+$/, '');
/* 3   */ }
/* 4   */ 
/* 5   */ function showTab(id) {
/* 6   */     var tabId = id+'-tab';
/* 7   */     var tabbodyId = id+'-tabbody';
/* 8   */     
/* 9   */     var tab = document.getElementById(tabId);
/* 10  */     var tabbody = document.getElementById(tabbodyId);
/* 11  */     var tabBodies = tabbody.parentNode.childNodes;
/* 12  */     if (!tab || !tabbody || !tabBodies) { return; } // safety check
/* 13  */     
/* 14  */     var tabs = tab.parentNode.getElementsByTagName('li');
/* 15  */     if (!tabs) { return; } // safety check
/* 16  */     
/* 17  */     // Display the tab body and hide others
/* 18  */     for (var i = 0; i < tabBodies.length; i++) {
/* 19  */         if (tabBodies[i].id == tabbodyId) {
/* 20  */             show(tabBodies[i].id);
/* 21  */         } else {
/* 22  */             hide(tabBodies[i].id);
/* 23  */         }
/* 24  */     }
/* 25  */     
/* 26  */     // Display the tab and hide others
/* 27  */     for (var i = 0; i < tabs.length; i++) {
/* 28  */         if (tabs[i].id == tabId) {
/* 29  */             addClass(tabs[i], 'active');
/* 30  */         } else {
/* 31  */             removeClass(tabs[i], 'active');
/* 32  */         }
/* 33  */     }
/* 34  */     
/* 35  */     // fake resize event in case tab body was resized while hidden 
/* 36  */     if (document.createEvent) {
/* 37  */         var e = document.createEvent('HTMLEvents');
/* 38  */         e.initEvent('resize', true, true);
/* 39  */         window.dispatchEvent(e);
/* 40  */     
/* 41  */     } else if( document.createEventObject ) {
/* 42  */         var e = document.createEventObject();
/* 43  */         document.documentElement.fireEvent('onresize', e);
/* 44  */     }
/* 45  */     
/* 46  */     onDOMChange();
/* 47  */ }
/* 48  */ 
/* 49  */ function onOrientationChange() {
/* 50  */     /* the galaxy tab sends orientation change events constantly */

/* common.js */

/* 51  */     if (typeof onOrientationChange.lastOrientation == 'undefined') {
/* 52  */         onOrientationChange.lastOrientation = null;
/* 53  */     }
/* 54  */     
/* 55  */     var newOrientation = getOrientation();
/* 56  */     
/* 57  */     if (newOrientation != onOrientationChange.lastOrientation) {
/* 58  */         rotateScreen();
/* 59  */         
/* 60  */         if (typeof onOrientationChange.callbackFunctions !== 'undefined') {
/* 61  */             for (var i = 0; i < onOrientationChange.callbackFunctions.length; i++) {
/* 62  */                 onOrientationChange.callbackFunctions[i]();
/* 63  */             }
/* 64  */         }
/* 65  */         
/* 66  */         onOrientationChange.lastOrientation = newOrientation;
/* 67  */     }
/* 68  */ }
/* 69  */ 
/* 70  */ function onResize() {
/* 71  */     if (typeof onResize.callbackFunctions !== 'undefined') {
/* 72  */         for (var i = 0; i < onResize.callbackFunctions.length; i++) {
/* 73  */             onResize.callbackFunctions[i]();
/* 74  */         }
/* 75  */     }
/* 76  */ }
/* 77  */ 
/* 78  */ function addOnOrientationChangeCallback(callback) {
/* 79  */     if (typeof onOrientationChange.callbackFunctions == 'undefined') {
/* 80  */         onOrientationChange.callbackFunctions = [];
/* 81  */     }
/* 82  */     onOrientationChange.callbackFunctions.push(callback);
/* 83  */     
/* 84  */     if (typeof onResize.callbackFunctions == 'undefined') {
/* 85  */         onResize.callbackFunctions = [];
/* 86  */     }
/* 87  */     onResize.callbackFunctions.push(callback);
/* 88  */ }
/* 89  */ 
/* 90  */ function setupOrientationChangeHandlers() {
/* 91  */     if (window.addEventListener) {
/* 92  */         window.addEventListener("orientationchange", onOrientationChange, false);
/* 93  */     } else if (window.attachEvent) {
/* 94  */         window.attachEvent("onorientationchange", onOrientationChange);
/* 95  */     }
/* 96  */     if (window.addEventListener) {
/* 97  */         window.addEventListener("resize", onResize, false);
/* 98  */     } else if (window.attachEvent) {
/* 99  */         window.attachEvent("onresize", onResize);
/* 100 */     }

/* common.js */

/* 101 */ }
/* 102 */ 
/* 103 */ function rotateScreen() {
/* 104 */   setOrientation(getOrientation());
/* 105 */   setTimeout(scrollToTop, 500);
/* 106 */ }
/* 107 */ 
/* 108 */ function getOrientation() {
/* 109 */     if (typeof getOrientation.orientationIsFlipped == 'undefined') {
/* 110 */         // detect how we are detecting orientation
/* 111 */         getOrientation.orientationIsFlipped = false;
/* 112 */         
/* 113 */         if (!('orientation' in window)) {
/* 114 */             getOrientation.orientationMethod = 'size';
/* 115 */         } else {
/* 116 */             getOrientation.orientationMethod = 'orientation';
/* 117 */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 118 */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 119 */             
/* 120 */             /* at this point the method of orientation detection is not perfect */
/* 121 */             if (navigator.userAgent.match(/(PlayBook.+RIM Tablet|Xoom|Android 3\.\d)/)) {
/* 122 */                 getOrientation.orientationIsFlipped = true;
/* 123 */             }
/* 124 */         }
/* 125 */     }
/* 126 */ 
/* 127 */     switch (getOrientation.orientationMethod) {
/* 128 */         case 'size':
/* 129 */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 130 */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 131 */ 
/* 132 */             return (width > height) ? 'landscape' : 'portrait';
/* 133 */             break;
/* 134 */ 
/* 135 */         case 'orientation':
/* 136 */             switch (window.orientation) {
/* 137 */                 case 0:
/* 138 */                 case 180:
/* 139 */                     return getOrientation.orientationIsFlipped ? 'landscape' : 'portrait';
/* 140 */                     break;
/* 141 */                 
/* 142 */                 case 90:
/* 143 */                 case -90:
/* 144 */                     return getOrientation.orientationIsFlipped ? 'portrait': 'landscape';
/* 145 */                     break;
/* 146 */             }
/* 147 */     }
/* 148 */ }
/* 149 */ 
/* 150 */ function setOrientation(orientation) {

/* common.js */

/* 151 */     var body = document.getElementsByTagName("body")[0];
/* 152 */  
/* 153 */  //remove existing portrait/landscape class if there
/* 154 */     removeClass(body, 'portrait');
/* 155 */     removeClass(body, 'landscape');
/* 156 */     addClass(body, orientation);
/* 157 */ }
/* 158 */ 
/* 159 */ 
/* 160 */ function showLoadingMsg(strID) {
/* 161 */ // Show a temporary loading message in the element with ID strID
/* 162 */ 	var objToStuff = document.getElementById(strID);
/* 163 */ 	if(objToStuff) {
/* 164 */ 		objToStuff.innerHTML = '<div class="loading"><img src="'+URL_BASE+'common/images/loading.gif" width="27" height="21" alt="Loading" align="absmiddle" />Loading data...</div>';
/* 165 */ 	}
/* 166 */ 	onDOMChange();
/* 167 */ }
/* 168 */ 
/* 169 */ function hide(strID) {
/* 170 */ // Hides the object with ID strID 
/* 171 */ 	var objToHide = document.getElementById(strID);
/* 172 */ 	if(objToHide) {
/* 173 */ 		objToHide.style.display = "none";
/* 174 */ 	}
/* 175 */ 	
/* 176 */ 	onDOMChange();
/* 177 */ }
/* 178 */ 
/* 179 */ function show(strID) {
/* 180 */ // Displays the object with ID strID 
/* 181 */ 	var objToHide = document.getElementById(strID);
/* 182 */ 	if(objToHide) {
/* 183 */ 		objToHide.style.display = "block";
/* 184 */ 	}
/* 185 */ 	
/* 186 */ 	onDOMChange();
/* 187 */ }
/* 188 */ 
/* 189 */ function showHideFull(objContainer) {
/* 190 */ 	var strClass = objContainer.className;
/* 191 */ 	if(strClass.indexOf("collapsed") > -1) {
/* 192 */ 		strClass = strClass.replace("collapsed","expanded");
/* 193 */ 	} else {
/* 194 */ 		strClass = strClass.replace("expanded","collapsed");
/* 195 */ 	}
/* 196 */ 	objContainer.className = strClass;
/* 197 */ 	objContainer.blur();
/* 198 */ 	
/* 199 */ 	onDOMChange();
/* 200 */ }

/* common.js */

/* 201 */ 
/* 202 */ function clearField(objField,strDefault) {
/* 203 */ // Clears the placeholder text in an input field if it matches the default string - fixes a bug in Android
/* 204 */ 	if((objField.value==strDefault) || (objField.value=="")) {
/* 205 */ 		objField.value="";
/* 206 */ 	}
/* 207 */ }
/* 208 */ 
/* 209 */ // Android doesn't respond to onfocus="clearField(...)" until the 
/* 210 */ // input field loses focus
/* 211 */ function androidPlaceholderFix(searchbox) {
/* 212 */     // this forces the search box to display the empty string
/* 213 */     // instead of the place holder when the search box takes focus
/* 214 */     if (searchbox.value == "") {
/* 215 */         searchbox.value = "";
/* 216 */     }
/* 217 */ }
/* 218 */ 
/* 219 */ function getCookie(name) {
/* 220 */   var cookie = document.cookie;
/* 221 */   var result = "";
/* 222 */   var start = cookie.indexOf(name + "=");
/* 223 */   if (start > -1) {
/* 224 */     start += name.length + 1;
/* 225 */     var end = cookie.indexOf(";", start);
/* 226 */     if (end < 0) {
/* 227 */       end = cookie.length;
/* 228 */     }
/* 229 */     result = unescape(cookie.substring(start, end));
/* 230 */   }
/* 231 */   return result;
/* 232 */ }
/* 233 */ 
/* 234 */ function setCookie(name, value, expireseconds, path) {
/* 235 */   var exdate = new Date();
/* 236 */   exdate.setTime(exdate.getTime() + (expireseconds * 1000));
/* 237 */   var exdateclause = (expireseconds == 0) ? "" : "; expires=" + exdate.toGMTString();
/* 238 */   var pathclause = (path == null) ? "" : "; path=" + path;
/* 239 */   document.cookie = name + "=" + escape(value) + exdateclause + pathclause;
/* 240 */ }
/* 241 */ 
/* 242 */ function getCookieArrayValue(name) {
/* 243 */   var value = getCookie(name);
/* 244 */   if (value && value.length) {
/* 245 */     return value.split('@@');
/* 246 */   } else {
/* 247 */     return new Array();
/* 248 */   }
/* 249 */ }
/* 250 */ 

/* common.js */

/* 251 */ function setCookieArrayValue(name, values, expireseconds, path) {
/* 252 */   var value = '';
/* 253 */   if (values && values.length) {
/* 254 */     value = values.join('@@');
/* 255 */   }
/* 256 */   setCookie(name, value, expireseconds, path);
/* 257 */ }
/* 258 */ 
/* 259 */ function hasClass(ele,cls) {
/* 260 */     return ele.className.match(new RegExp('(\\s|^)'+cls+'(\\s|$)'));
/* 261 */ }
/* 262 */         
/* 263 */ function addClass(ele,cls) {
/* 264 */     if (!this.hasClass(ele,cls)) ele.className += " "+cls;
/* 265 */ }
/* 266 */ 
/* 267 */ function removeClass(ele,cls) {
/* 268 */     if (hasClass(ele,cls)) {
/* 269 */         var reg = new RegExp('(\\s|^)'+cls+'(\\s|$)');
/* 270 */         ele.className=ele.className.replace(reg,' ').strip();
/* 271 */     }
/* 272 */ }
/* 273 */         
/* 274 */ function toggleClass(ele, cls) {
/* 275 */     if (hasClass(ele, cls)) {
/* 276 */         removeClass(ele, cls);
/* 277 */     } else {
/* 278 */         addClass(ele, cls);
/* 279 */     }
/* 280 */ }
/* 281 */ 
/* 282 */ // Share-related functions
/* 283 */ function showShare() {
/* 284 */     if (!document.getElementById("sharesheet")) {
/* 285 */         return;
/* 286 */     }
/* 287 */ 	document.getElementById("sharesheet").style.display="block";
/* 288 */ 	var iframes = document.getElementsByTagName('iframe');
/* 289 */ 	for (var i=0; i<iframes.length; i++) {
/* 290 */ 	    iframes[i].style.visibility = 'hidden';
/* 291 */ 	    iframes[i].style.height = '0';
/* 292 */ 	}
/* 293 */ 	window.scrollTo(0,0);
/* 294 */ }
/* 295 */ function hideShare() {
/* 296 */     if (!document.getElementById("sharesheet")) {
/* 297 */         return;
/* 298 */     }
/* 299 */ 	document.getElementById("sharesheet").style.display="none";
/* 300 */ 	var iframes = document.getElementsByTagName('iframe');

/* common.js */

/* 301 */ 	for (var i=0; i<iframes.length; i++) {
/* 302 */ 	    iframes[i].style.visibility = 'visible';
/* 303 */ 	    iframes[i].style.height = '';
/* 304 */ 	}
/* 305 */ }
/* 306 */ 
/* 307 */ // Bookmarks
/* 308 */ function toggleBookmark(name, item, expireseconds, path, bookmarkId) {
/* 309 */   // facility for module to respond to bookmark state change
/* 310 */   if (typeof moduleBookmarkWillToggle != 'undefined') {
/* 311 */     $result = moduleBookmarkWillToggle(name, item, expireseconds, path);
/* 312 */     if ($result === false) { return; }
/* 313 */   }
/* 314 */ 
/* 315 */   if (!bookmarkId) {
/* 316 */     bookmarkId = "bookmark";
/* 317 */   }
/* 318 */   var bookmark = document.getElementById(bookmarkId);
/* 319 */   toggleClass(bookmark, "on");
/* 320 */   var items = getCookieArrayValue(name);
/* 321 */   var newItems = new Array();
/* 322 */   if (items.length == 0) {
/* 323 */     newItems[0] = item;
/* 324 */   } else {
/* 325 */     var found = false;
/* 326 */     for (var i = 0; i < items.length; i++) {
/* 327 */       if (items[i] == item) {
/* 328 */         found = true;
/* 329 */       } else {
/* 330 */         newItems.push(items[i]);
/* 331 */       }
/* 332 */     }
/* 333 */     if (!found) {
/* 334 */       newItems.push(item);
/* 335 */     }
/* 336 */   }
/* 337 */   setCookieArrayValue(name, newItems, expireseconds, path);
/* 338 */   
/* 339 */   // facility for module to respond to bookmark state change
/* 340 */   if (typeof moduleBookmarkToggled != 'undefined') {
/* 341 */     moduleBookmarkToggled(name, item, expireseconds, path);
/* 342 */   }
/* 343 */ }
/* 344 */ 
/* 345 */ // TODO this needs to handle encoded strings and parameter separators (&amp;)
/* 346 */ if (typeof makeAPICall === 'undefined' && typeof jQuery === 'undefined') {
/* 347 */   function makeAPICall(type, module, command, data, callback) {
/* 348 */     var urlParts = [];
/* 349 */     for (var param in data) {
/* 350 */       urlParts.push(param + "=" + data[param]);

/* common.js */

/* 351 */     }
/* 352 */     url = URL_BASE + API_URL_PREFIX + '/' + module + '/' + command + '?' + urlParts.join('&');
/* 353 */     var handleError = function(errorObj) {}
/* 354 */ 
/* 355 */     var httpRequest = new XMLHttpRequest();
/* 356 */     httpRequest.open("GET", url, true);
/* 357 */     httpRequest.onreadystatechange = function() {
/* 358 */       if (httpRequest.readyState == 4 && httpRequest.status == 200) {
/* 359 */         var obj;
/* 360 */         if (window.JSON) {
/* 361 */             obj = JSON.parse(httpRequest.responseText);
/* 362 */             // TODO: catch SyntaxError
/* 363 */         } else {
/* 364 */             obj = eval('(' + httpRequest.responseText + ')');
/* 365 */         }
/* 366 */         if (obj !== undefined) {
/* 367 */           if ("response" in obj) {
/* 368 */             callback(obj["response"]);
/* 369 */           }
/* 370 */ 
/* 371 */           if ("error" in obj && obj["error"] !== null) {
/* 372 */             handleError(obj["error"]);
/* 373 */           } else {
/* 374 */             handleError("response not found");
/* 375 */           }
/* 376 */         } else {
/* 377 */           handleError("failed to parse response");
/* 378 */         }
/* 379 */       }
/* 380 */     }
/* 381 */     httpRequest.send(null);
/* 382 */   }
/* 383 */ }
/* 384 */ 
/* 385 */ function ajaxContentIntoContainer(options) {
/* 386 */     if (typeof options != 'object') { return; } // safety
/* 387 */     
/* 388 */     var defaults = {
/* 389 */         url: null, 
/* 390 */         container: null, 
/* 391 */         timeout: 60, 
/* 392 */         success: function () {},
/* 393 */         error: function (code) {} 
/* 394 */     };
/* 395 */     for (var i in defaults) {
/* 396 */         if (typeof options[i] == 'undefined') {
/* 397 */             options[i] = defaults[i];
/* 398 */         }
/* 399 */     }
/* 400 */     if (!options.url || !options.container) { return; } // safety

/* common.js */

/* 401 */     
/* 402 */     var httpRequest = new XMLHttpRequest();
/* 403 */     httpRequest.open("GET", options.url, true);
/* 404 */     
/* 405 */     var requestTimer = setTimeout(function() {
/* 406 */         // some browsers set readyState to 4 on abort so remove handler first
/* 407 */         httpRequest.onreadystatechange = function() { };
/* 408 */         httpRequest.abort();
/* 409 */         
/* 410 */         options.error(408); // http request timeout status code
/* 411 */     }, options.timeout * 1000);
/* 412 */     
/* 413 */     httpRequest.onreadystatechange = function() {
/* 414 */         // return if still in progress
/* 415 */         if (httpRequest.readyState != 4) { return; }
/* 416 */         
/* 417 */         // Got answer, don't abort
/* 418 */         clearTimeout(requestTimer);
/* 419 */         
/* 420 */         if (httpRequest.status == 200) { // Success
/* 421 */             options.container.innerHTML = "";
/* 422 */             
/* 423 */             var div = document.createElement("div");
/* 424 */             div.innerHTML = httpRequest.responseText;
/* 425 */             
/* 426 */             // Manually appendChild elements so scripts get evaluated
/* 427 */             for (var i = 0; i < div.childNodes.length; i++) {
/* 428 */                 var node = div.childNodes[i].cloneNode(true);
/* 429 */                 
/* 430 */                 if (node.nodeName == "SCRIPT") {
/* 431 */                     document.body.appendChild(node);
/* 432 */                 } else if (node.nodeName == "STYLE") {
/* 433 */                     document.getElementsByTagName("head")[0].appendChild(node);
/* 434 */                 } else {
/* 435 */                     options.container.appendChild(node);
/* 436 */                 }
/* 437 */             }
/* 438 */             
/* 439 */             options.success();
/* 440 */             
/* 441 */         } else {
/* 442 */             options.error(httpRequest.status);
/* 443 */         }
/* 444 */     };
/* 445 */     
/* 446 */     httpRequest.send(null);
/* 447 */ }
/* 448 */ 
/* 449 */ function getCSSValue(element, key) {
/* 450 */     if (window.getComputedStyle) {

/* common.js */

/* 451 */         return document.defaultView.getComputedStyle(element, null).getPropertyValue(key);
/* 452 */         
/* 453 */     } else if (element.currentStyle) {
/* 454 */         if (key == 'float') { 
/* 455 */             key = 'styleFloat'; 
/* 456 */         } else {
/* 457 */             var re = /(\-([a-z]){1})/g; // hyphens to camel case
/* 458 */             if (re.test(key)) {
/* 459 */                 key = key.replace(re, function () {
/* 460 */                     return arguments[2].toUpperCase();
/* 461 */                 });
/* 462 */             }
/* 463 */         }
/* 464 */         return element.currentStyle[key] ? element.currentStyle[key] : null;
/* 465 */     }
/* 466 */     return '';
/* 467 */ }
/* 468 */ 
/* 469 */ function getCSSHeight(element) {
/* 470 */     return element.offsetHeight
/* 471 */         - parseFloat(getCSSValue(element, 'border-top-width')) 
/* 472 */         - parseFloat(getCSSValue(element, 'border-bottom-width'))
/* 473 */         - parseFloat(getCSSValue(element, 'padding-top'))
/* 474 */         - parseFloat(getCSSValue(element, 'padding-bottom'));
/* 475 */ }
/* 476 */ 
/* 477 */ 
/* 478 */ 
/* 479 */ 
/* 480 */ 
/* 481 */ 
/* 482 */ 
/* 483 */ 

;
/* tablet.js */

/* 1   */ var containerScroller = null;
/* 2   */ var navScroller = null;
/* 3   */ 
/* 4   */ function onDOMChange() {
/* 5   */   if (containerScroller) {
/* 6   */     setContainerWrapperHeight();
/* 7   */     setTimeout(function () {
/* 8   */       containerScroller.refresh();
/* 9   */     }, 0);
/* 10  */   }
/* 11  */ }
/* 12  */ 
/* 13  */ // Update the nav slide indicators
/* 14  */ function updateNavSlider() {
/* 15  */     if (navScroller) {
/* 16  */         var current = Math.abs(navScroller.x);
/* 17  */         var max = Math.abs(navScroller.maxScrollX);
/* 18  */       
/* 19  */         var canScrollLeft = (current > 0);
/* 20  */         var canScrollRight = (current < max-1);
/* 21  */         
/* 22  */         document.getElementById('slideleft').style.display  = canScrollLeft  ? 'block' : 'none';
/* 23  */         document.getElementById('slideright').style.display = canScrollRight ? 'block' : 'none';
/* 24  */     }
/* 25  */ }
/* 26  */ 
/* 27  */ function navSliderScrollLeft() {
/* 28  */   if (navScroller) {
/* 29  */     navScroller.scrollTo(0, navScroller.y, 500);
/* 30  */   }
/* 31  */ }
/* 32  */ 
/* 33  */ function navSliderScrollRight() {
/* 34  */   if (navScroller) {
/* 35  */     navScroller.scrollTo(navScroller.maxScrollX, navScroller.y, 500);
/* 36  */   }
/* 37  */ }
/* 38  */ 
/* 39  */ // Change wrapper height based on device orientation.
/* 40  */ function setContainerWrapperHeight() {
/* 41  */   document.getElementById('container').style.height = 'auto';
/* 42  */   
/* 43  */   var footerNav = document.getElementById('footernav');
/* 44  */   
/* 45  */ 	var navbarHeight = document.getElementById('navbar').offsetHeight;
/* 46  */   var footerNavHeight = footerNav ? footerNav.offsetHeight : 0;
/* 47  */ 	var wrapperHeight = window.innerHeight - navbarHeight - footerNavHeight;
/* 48  */ 	var containerHeight = document.getElementById('container').offsetHeight;
/* 49  */ 	
/* 50  */ 	document.getElementById('wrapper').style.height = wrapperHeight + 'px';

/* tablet.js */

/* 51  */ 	
/* 52  */ 	if (containerHeight < wrapperHeight) {
/* 53  */ 	  document.getElementById('container').style.height = wrapperHeight + 'px';
/* 54  */ 	}
/* 55  */ 	
/* 56  */ 	// when this exists, make it fill the screen
/* 57  */ 	var fillscreen = document.getElementById('fillscreen');
/* 58  */ 	if (fillscreen) {
/* 59  */ 	  fillscreen.style.height = wrapperHeight + 'px';
/* 60  */ 	}
/* 61  */ }
/* 62  */ 
/* 63  */ function handleWindowResize(e) {
/* 64  */     if (!('orientation' in window)) {
/* 65  */         rotateScreen();
/* 66  */     }
/* 67  */     setContainerWrapperHeight();
/* 68  */   
/* 69  */     setTimeout(updateNavSlider, 0);
/* 70  */     
/* 71  */     if (typeof moduleHandleWindowResize != 'undefined') {
/* 72  */         moduleHandleWindowResize(e);
/* 73  */     }
/* 74  */     if (navigator.userAgent.match(/(Android [34]\.\d)/)) {
/* 75  */         // Android 3/4 browsers don't reliably set client and offset heights
/* 76  */         // before calling orientationchange or resize handlers.
/* 77  */         var self = this;
/* 78  */         setTimeout(function() {
/* 79  */             setContainerWrapperHeight();
/* 80  */             setTimeout(updateNavSlider, 0);
/* 81  */             if (typeof moduleHandleWindowResize != 'undefined') {
/* 82  */                 moduleHandleWindowResize(e);
/* 83  */             }
/* 84  */         }, 600); // approx. how long after the event before the offsetHeights are correct
/* 85  */     }
/* 86  */ } 
/* 87  */ 
/* 88  */ // form element-safe version of iScroll initialization
/* 89  */ function iScrollInit(id, options) {
/* 90  */     options.useTransform = true;
/* 91  */     options.onBeforeScrollStart = function (e) {
/* 92  */         var target = e.target;
/* 93  */         while (target.nodeType != 1) { target = target.parentNode; }
/* 94  */         
/* 95  */         var tagName = target.tagName;
/* 96  */         if (target.tagName != 'SELECT' && target.tagName != 'INPUT' && target.tagName != 'TEXTAREA') {
/* 97  */             e.preventDefault();
/* 98  */         }
/* 99  */     };
/* 100 */ 

/* tablet.js */

/* 101 */     return new iScroll(id, options);
/* 102 */ }
/* 103 */ 
/* 104 */ function tabletInit() {
/* 105 */    setOrientation(getOrientation());
/* 106 */     if(!document.getElementById('navbar')) {
/* 107 */         // page has no footer so do not attempt
/* 108 */         // to use fancy tablet container
/* 109 */         return;
/* 110 */     }
/* 111 */ 
/* 112 */   setContainerWrapperHeight();
/* 113 */   
/* 114 */   // Adjust wrapper height on orientation change or resize
/* 115 */   var resizeEvent = 'onorientationchange' in window ? 'orientationchange' : 'resize';
/* 116 */   window.addEventListener(resizeEvent, function() {setTimeout(handleWindowResize,0)}, false);
/* 117 */ 
/* 118 */   containerScroller = iScrollInit('wrapper', { 
/* 119 */     hScrollbar: false,
/* 120 */     bounce: false,
/* 121 */     bounceLock: true
/* 122 */   });
/* 123 */ 
/* 124 */   if (document.getElementById('navsliderwrapper')) {
/* 125 */     navScroller = iScrollInit('navsliderwrapper', { 
/* 126 */       hScrollbar: false,
/* 127 */       vScrollbar: false,
/* 128 */       bounce: false,
/* 129 */       bounceLock: true,
/* 130 */       onScrollStart: updateNavSlider,
/* 131 */       onScrollEnd: updateNavSlider
/* 132 */     });
/* 133 */   }
/* 134 */ 
/* 135 */     handleWindowResize();
/* 136 */     updateNavSlider();
/* 137 */ 
/* 138 */   //run module init if present
/* 139 */   if (typeof moduleInit != 'undefined') {
/* 140 */     moduleInit();
/* 141 */   }
/* 142 */ }
/* 143 */ 
/* 144 */ function scrollToTop() {
/* 145 */   if (containerScroller) {
/* 146 */   	containerScroller.scrollTo(0,0,0); 
/* 147 */   }
/* 148 */ }
/* 149 */ 
/* 150 */ (function(window) {

/* tablet.js */

/* 151 */ 
/* 152 */     function splitView (options) {
/* 153 */       // set caller options
/* 154 */         if (typeof options == 'object') {
/* 155 */             for (var i in options) {
/* 156 */                 switch (i) {
/* 157 */                     case 'linkSelect':
/* 158 */                     case 'actionForLink':
/* 159 */                         this[i] = options[i];
/* 160 */                         break;
/* 161 */                     default:
/* 162 */                         this.options[i] = options[i];
/* 163 */                         break;
/* 164 */                 }
/* 165 */             }
/* 166 */         }
/* 167 */       
/* 168 */         if (window.addEventListener) {
/* 169 */           window.addEventListener(RESIZE_EVENT, this, false);
/* 170 */         } else if (window.attachEvent) {
/* 171 */           window.attachEvent(RESIZE_EVENT, this);
/* 172 */         }
/* 173 */         
/* 174 */         if (!document.getElementById(this.options.list) || !document.getElementById(this.options.detail)) {
/* 175 */             return;
/* 176 */         }
/* 177 */ 
/* 178 */         this.orientation = getOrientation();
/* 179 */         this.list = document.getElementById(this.options.list);
/* 180 */         this.detail = document.getElementById(this.options.detail);
/* 181 */         this.detailScroller = iScrollInit(this.options.detail, {
/* 182 */             hScrollbar : false,
/* 183 */             hScroll : false
/* 184 */         });
/* 185 */         
/* 186 */         if ('content' in this.options) {
/* 187 */             this.content = document.getElementById(this.options.content);
/* 188 */         } else {
/* 189 */             this.options.content = this.options.detail;
/* 190 */             this.content = this.detail;
/* 191 */         }
/* 192 */         
/* 193 */         var self = this;
/* 194 */         
/* 195 */         var links = this.list.getElementsByTagName('a');
/* 196 */ 
/* 197 */         var linkInAnchor = null;
/* 198 */         var anchor = location.hash;
/* 199 */         if (anchor.length > 1) {
/* 200 */             var possibleLinkHref = removeBreadcrumbParameter(decodeURIComponent(anchor.slice(1)));

/* tablet.js */

/* 201 */             if (possibleLinkHref) {
/* 202 */               for (var i=0;i<links.length;i++) {
/* 203 */                   if (possibleLinkHref == removeBreadcrumbParameter(links[i].href)) {
/* 204 */                      linkInAnchor = links[i];
/* 205 */                      break;
/* 206 */                   }
/* 207 */               }
/* 208 */             }
/* 209 */         }
/* 210 */         
/* 211 */         var first = true;
/* 212 */         for (var i=0;i<links.length;i++) {
/* 213 */             links[i].onclick = function(e) {
/* 214 */                 var action = self.actionForLink(this);
/* 215 */                 self[action](e, this);
/* 216 */             }
/* 217 */ 
/* 218 */             if (!linkInAnchor && first && this.options.selectFirst && this.actionForLink(links[i])=='linkSelect') {
/* 219 */                 links[i].onclick();
/* 220 */                 first = false;
/* 221 */             }
/* 222 */         }
/* 223 */         if (linkInAnchor) {
/* 224 */             linkInAnchor.onclick();
/* 225 */         }
/* 226 */ 
/* 227 */         this.updateListScroller();
/* 228 */     }
/* 229 */ 
/* 230 */     splitView.prototype = {
/* 231 */         orientation: '',
/* 232 */         options: {
/* 233 */             selectFirst: true,
/* 234 */             selectID: null
/* 235 */         },
/* 236 */         baseActionForLink: function(link) {
/* 237 */             if (link.parentNode.className.match(/pagerlink/)) {
/* 238 */                 return 'linkFollow';
/* 239 */             }
/* 240 */             
/* 241 */             return 'linkSelect';
/* 242 */         },
/* 243 */         actionForLink: function(link) {
/* 244 */             return this.baseActionForLink(link);
/* 245 */         },
/* 246 */         linkFollow: function(e, link) {
/* 247 */             //just follow the link
/* 248 */         },
/* 249 */         linkSelect: function(e, link) {
/* 250 */             //ajax fun

/* tablet.js */

/* 251 */             hideShare();
/* 252 */             var self = this;
/* 253 */             var selected = this.list.getElementsByTagName('a');
/* 254 */             for (var j=0;j<selected.length;j++) {
/* 255 */                 removeClass(selected[j],'listSelected');
/* 256 */             }
/* 257 */             addClass(link,'listSelected');
/* 258 */             this.detailScroller.scrollTo(0,0);
/* 259 */             
/* 260 */             ajaxContentIntoContainer({
/* 261 */                 url: link.href+'&ajax=1', 
/* 262 */                 container: self.content, 
/* 263 */                 timeout: 60, 
/* 264 */                 success: function () {
/* 265 */                     var hash = '#'+encodeURIComponent(removeBreadcrumbParameter(link.href));
/* 266 */                     if (window.history && window.history.pushState && window.history.replaceState && // Regexs from history js plugin
/* 267 */                       !((/ Mobile\/([1-7][a-z]|(8([abcde]|f(1[0-8]))))/i).test(navigator.userAgent) || // disable for versions of iOS < 4.3 (8F190)
/* 268 */                          (/AppleWebKit\/5([0-2]|3[0-3])/i).test(navigator.userAgent))) { // disable for the mercury iOS browser and older webkit/uiwebview
/* 269 */                       window.history.pushState({}, document.title, hash);
/* 270 */                     } else {
/* 271 */                       location.hash = hash;
/* 272 */                     }
/* 273 */                     
/* 274 */                     if (typeof moduleHandleWindowResize != 'undefined') {
/* 275 */                         moduleHandleWindowResize(e);
/* 276 */                     }
/* 277 */                     
/* 278 */                     var refreshOnLoad = function () {
/* 279 */                         setTimeout(function () {
/* 280 */                             self.detailScroller.refresh();
/* 281 */                         }, 0);
/* 282 */                     };
/* 283 */                     
/* 284 */                     // As images load the height of the detail view will change so
/* 285 */                     // refresh the scroller when each image loads:
/* 286 */                     var images = self.content.getElementsByTagName("img");
/* 287 */                     for (var i = 0; i < images.length; i++) {
/* 288 */                         // ignore images with a height attribute since the DOM already knows their height
/* 289 */                         if (images[i].getAttribute("height")) { continue; }
/* 290 */                         
/* 291 */                         if (images[i].addEventListener) {
/* 292 */                             images[i].addEventListener("load", refreshOnLoad, false);
/* 293 */                         } else if (images[i].attachEvent) {
/* 294 */                             images[i].attachEvent("onload", refreshOnLoad);
/* 295 */                         }
/* 296 */                     }
/* 297 */                     refreshOnLoad();
/* 298 */                 },
/* 299 */                 error: function (code) {
/* 300 */                 }

/* tablet.js */

/* 301 */             });
/* 302 */             
/* 303 */             showLoadingMsg(this.options.content);
/* 304 */             e && e.preventDefault();
/* 305 */             return false;
/* 306 */         },
/* 307 */         listScroller: null,
/* 308 */         detailScroller: null,
/* 309 */         handleEvent: function (e) {
/* 310 */             switch (e.type) {
/* 311 */                 case 'orientationchange':
/* 312 */                 case 'resize':
/* 313 */                     if (this.orientation != getOrientation()) {
/* 314 */                         this.orientation = getOrientation();
/* 315 */                         this.updateListScroller();
/* 316 */                         if (typeof moduleHandleWindowResize != 'undefined') {
/* 317 */                             moduleHandleWindowResize(e);
/* 318 */                         }
/* 319 */                     }
/* 320 */                     break;
/* 321 */             }
/* 322 */         },
/* 323 */         updateListScroller: function() {
/* 324 */             var self = this, options={};
/* 325 */             switch (getOrientation()) {
/* 326 */                 case 'portrait':
/* 327 */                     options.vScrollbar = false;
/* 328 */                     options.hScrollbar = true;
/* 329 */                     options.vScroll = false;
/* 330 */                     options.hScroll = true;
/* 331 */                     break;
/* 332 */                 case 'landscape':
/* 333 */                     options.vScrollbar = true;
/* 334 */                     options.hScrollbar = false;
/* 335 */                     options.hScroll = false;
/* 336 */                     options.vScroll = true;
/* 337 */                     break;
/* 338 */             }
/* 339 */ 
/* 340 */             if (this.listScroller) {
/* 341 */                 for (var i in options) {
/* 342 */                     this.listScroller.options[i] = options[i];
/* 343 */                 }
/* 344 */                 
/* 345 */                 setTimeout(function() {
/* 346 */                     self.listScroller.refresh();
/* 347 */                     var items = self.list.getElementsByTagName('a');
/* 348 */                     for (var i=0;i<items.length; i++) {
/* 349 */                         if (hasClass(items[i],'listSelected')) {
/* 350 */                             self.listScroller.scrollToElement(items[i].parentNode,0);

/* tablet.js */

/* 351 */                         }
/* 352 */                     }
/* 353 */                 },0);
/* 354 */                 return;
/* 355 */             } else {
/* 356 */               this.listScroller = iScrollInit(this.options.list, options);
/* 357 */             }
/* 358 */         },
/* 359 */         refreshScrollers: function () {
/* 360 */             setTimeout(function() {
/* 361 */                 if (self.detailScroller) {
/* 362 */                     self.detailScroller.refresh();
/* 363 */                 }
/* 364 */                 if (self.listScroller) {
/* 365 */                     self.listScroller.refresh();
/* 366 */                 }
/* 367 */             }, 0);
/* 368 */         },
/* 369 */     }
/* 370 */     
/* 371 */     function removeBreadcrumbParameter(url) {
/* 372 */         return url.replace(/[?&]_b=[^&]*/, '');
/* 373 */     }
/* 374 */ 
/* 375 */     var RESIZE_EVENT = window.addEventListener ? 
/* 376 */     ('onorientationchange' in window ? 
/* 377 */     'orientationchange' :  // touch device
/* 378 */     'resize')              // desktop browser
/* 379 */     : ('onresize');          // IE
/* 380 */     
/* 381 */     window.splitView = splitView;
/* 382 */ 
/* 383 */ })(window)
/* 384 */ 
/* 385 */ // Used by news and video modules for news article listings
/* 386 */ function setupSplitViewForListAndDetail(headerId, listWrapperId, detailWrapperId, detailId, options) {
/* 387 */     var aSplitView = null;
/* 388 */ 
/* 389 */     moduleHandleWindowResize = function () {
/* 390 */         var listWrapper = document.getElementById(listWrapperId);
/* 391 */         var detailWrapper = document.getElementById(detailWrapperId);
/* 392 */         if (!detailWrapper) {
/* 393 */           return;  // can happen for searches with no results or when feed is down
/* 394 */         }
/* 395 */         detailWrapper.style.height = 'auto';
/* 396 */         
/* 397 */         var wrapperHeight = document.getElementById('wrapper').offsetHeight;
/* 398 */         var headerHeight = document.getElementById(headerId).offsetHeight;
/* 399 */         var contentHeight = wrapperHeight - headerHeight;
/* 400 */         

/* tablet.js */

/* 401 */         switch (getOrientation()) {
/* 402 */             case 'landscape':
/* 403 */                 listWrapper.style.height = contentHeight + 'px';
/* 404 */                 detailWrapper.style.height = contentHeight + 'px';
/* 405 */                 var list = listWrapper.getElementsByTagName('li')[0].parentNode;
/* 406 */                 list.style.width = '';
/* 407 */                 break;
/* 408 */             
/* 409 */             case 'portrait':
/* 410 */                 listWrapper.style.height = '';
/* 411 */                 // this is a hack because for some reason the width isn't being properly set
/* 412 */                 var width = 0;
/* 413 */                 var listItems = listWrapper.getElementsByTagName('li');
/* 414 */                 var list;
/* 415 */                 for (var i = 0; i < listItems.length; i++) {
/* 416 */                     list = listItems[i].parentNode;
/* 417 */                     width+=listItems[i].offsetWidth;
/* 418 */                 }
/* 419 */                 list.style.width = width+'px';
/* 420 */                 
/* 421 */                 var listWrapperHeight = listWrapper.offsetHeight;
/* 422 */                 detailWrapper.style.height = (contentHeight - listWrapperHeight) + 'px';
/* 423 */                 break;
/* 424 */         }
/* 425 */         
/* 426 */         if (aSplitView) {
/* 427 */             aSplitView.refreshScrollers();
/* 428 */         }
/* 429 */     }
/* 430 */     
/* 431 */     if (containerScroller != null) {
/* 432 */         containerScroller.destroy();
/* 433 */         containerScroller = null;
/* 434 */     }
/* 435 */     
/* 436 */     moduleHandleWindowResize();
/* 437 */ 
/* 438 */     options = options || {};
/* 439 */     options["list"] = listWrapperId;
/* 440 */     options["detail"] = detailWrapperId;
/* 441 */     options["content"] = detailId;
/* 442 */     
/* 443 */     aSplitView = new splitView(options);
/* 444 */ }
/* 445 */ 

;
/* common-common-native.js */

/* 1   */ function scrollToTop() {
/* 2   */ 	scrollTo(0,0); 
/* 3   */ }
/* 4   */ 
/* 5   */ (function (window) {
/* 6   */     function kgoBridgeHandler(config) {
/* 7   */         if (typeof config == 'object') {
/* 8   */             for (var i in config) {
/* 9   */                 this.config[i] = config[i];
/* 10  */             }
/* 11  */         }
/* 12  */     }
/* 13  */     
/* 14  */     kgoBridgeHandler.prototype = {
/* 15  */         config: {
/* 16  */             events: false,  // desktop browser simulation mode
/* 17  */             base: "",
/* 18  */             url: "",
/* 19  */             ajaxArgs: "",
/* 20  */             pagePage: "",
/* 21  */             pageArgs: "",
/* 22  */             serverURL: "",
/* 23  */             timeout: 60,
/* 24  */             localizedStrings: {}
/* 25  */         },
/* 26  */         callbacks : {},
/* 27  */         callbackIdCounter : 0,
/* 28  */         
/* 29  */         // This code list is duplicated in iOS and Android code.  
/* 30  */         // Do not change existing codes!
/* 31  */         errorCodes : {
/* 32  */             KGOBridgeErrorAPINotSupported : 1,
/* 33  */             KGOBridgeErrorJSONConvertFailed : 2
/* 34  */         },
/* 35  */         
/* 36  */         // ====================================================================
/* 37  */         // Bridge API
/* 38  */         // ====================================================================
/* 39  */         
/* 40  */         //
/* 41  */         // Page load
/* 42  */         //
/* 43  */         
/* 44  */         initPage: function (params, statusCallback) {
/* 45  */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 46  */             
/* 47  */             this.nativeAPI("page", "init", params, statusCallback);
/* 48  */         },
/* 49  */         
/* 50  */         //

/* common-common-native.js */

/* 51  */         // Errors
/* 52  */         //
/* 53  */         
/* 54  */         initPageError: function (httpStatus, title, message) {
/* 55  */             switch (httpStatus) {
/* 56  */                 case 401:
/* 57  */                 case 407:
/* 58  */                     title = this.localizedString("ERROR_HTTP_UNAUTHORIZED_REQUEST_TITLE");
/* 59  */                     message = this.localizedString("ERROR_HTTP_UNAUTHORIZED_REQUEST_MESSAGE");
/* 60  */                     break;
/* 61  */                 case 408:
/* 62  */                     title = this.localizedString("ERROR_HTTP_CONNECTION_TIMEOUT_TITLE");
/* 63  */                     message = this.localizedString("ERROR_HTTP_CONNECTION_TIMEOUT_MESSAGE");
/* 64  */                     break;
/* 65  */                 case 404:
/* 66  */                 case 503:
/* 67  */                 default:
/* 68  */                     title = this.localizedString("ERROR_HTTP_CONNECTION_FAILED_TITLE");
/* 69  */                     message = this.localizedString("ERROR_HTTP_CONNECTION_FAILED_MESSAGE");
/* 70  */                     break;
/* 71  */             }
/* 72  */             
/* 73  */             this.handleError("pageinit", httpStatus, title, message);
/* 74  */         },
/* 75  */ 
/* 76  */         handleError: function (errorType, code, title, message) {
/* 77  */             if (typeof title   != "string") { title   = ""; }
/* 78  */             if (typeof message != "string") { message = ""; }
/* 79  */             
/* 80  */             this.nativeAPI("error", errorType, {
/* 81  */                 "code"    : code, 
/* 82  */                 "title"   : title, 
/* 83  */                 "message" : message
/* 84  */             });
/* 85  */         },
/* 86  */         
/* 87  */         //
/* 88  */         // Dialogs
/* 89  */         //
/* 90  */         
/* 91  */         alert: function (message, responseCallback /* optional */) {
/* 92  */             var ok = this.localizedString("BUTTON_OK");
/* 93  */ 
/* 94  */             this.alertDialog(message, null, ok, null, null, function (error, params) {
/* 95  */                 if (typeof responseCallback != "undefined" && responseCallback && error !== null) {
/* 96  */                     responseCallback();
/* 97  */                 }
/* 98  */             }, function (error, params) {
/* 99  */                 if (typeof responseCallback != "undefined" && responseCallback) {
/* 100 */                     responseCallback();

/* common-common-native.js */

/* 101 */                 }
/* 102 */             });
/* 103 */         },
/* 104 */         
/* 105 */         confirm: function (question, responseCallback) {
/* 106 */             var ok = this.localizedString("BUTTON_OK");
/* 107 */             var cancel = this.localizedString("BUTTON_CANCEL");
/* 108 */             
/* 109 */             this.alertDialog(message, null, ok, cancel, null, function (error, params) {
/* 110 */                 if (error !== null) {
/* 111 */                     responseCallback(false);
/* 112 */                 }
/* 113 */             }, function (error, params) {
/* 114 */                 // Return true when main button is pressed
/* 115 */                 responseCallback(error === null && params["button"] == "main");
/* 116 */             });
/* 117 */         },
/* 118 */         
/* 119 */         shareDialog: function (buttonConfig) {
/* 120 */             var buttonTitles = [];
/* 121 */             var actionURLs = [];
/* 122 */             if ("mail" in buttonConfig) {
/* 123 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_EMAIL"));
/* 124 */                 actionURLs.push(buttonConfig["mail"]);
/* 125 */             }
/* 126 */             if ("facebook" in buttonConfig) {
/* 127 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_FACEBOOK"));
/* 128 */                 actionURLs.push(buttonConfig["facebook"]);
/* 129 */             }
/* 130 */             if ("twitter" in buttonConfig) {
/* 131 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_TWITTER"));
/* 132 */                 actionURLs.push(buttonConfig["twitter"]);
/* 133 */             }
/* 134 */             
/* 135 */             var title = this.localizedString("SHARE_THIS_ITEM");
/* 136 */             var cancel = this.localizedString("BUTTON_CANCEL");
/* 137 */             
/* 138 */             var that = this;
/* 139 */             this.actionDialog(title, cancel, null, buttonTitles, null, function(error, params) {
/* 140 */                 if ("button" in params && params["button"].indexOf('alternate') === 0) {
/* 141 */                     var index = +params["button"].substr(9);
/* 142 */                     if (index >= 0 && index < actionURLs.length) {
/* 143 */                         that.loadURL(actionURLs[index]);
/* 144 */                     }
/* 145 */                 }
/* 146 */             });
/* 147 */         },
/* 148 */         
/* 149 */         alertDialog: function (title, message, 
/* 150 */                                cancelButtonTitle, mainButtonTitle, alternateButtonTitle, 

/* common-common-native.js */

/* 151 */                                statusCallback, buttonCallback) {
/* 152 */             // required params
/* 153 */             var params = {
/* 154 */                 "title" : title,
/* 155 */                 "cancelButtonTitle" : cancelButtonTitle
/* 156 */             };
/* 157 */             
/* 158 */             // optional params
/* 159 */             if (typeof message == "string") {
/* 160 */                 params["message"] = message;
/* 161 */             }
/* 162 */             if (typeof mainButtonTitle == "string") {
/* 163 */                 params["mainButtonTitle"] = mainButtonTitle;
/* 164 */             }
/* 165 */             if (typeof alternateButtonTitle == "string") {
/* 166 */                 params["alternateButtonTitle"] = alternateButtonTitle;
/* 167 */             }
/* 168 */             
/* 169 */             // optional callbacks
/* 170 */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 171 */             
/* 172 */             var additionalCallbacks = [];
/* 173 */             if (typeof buttonCallback != "undefined") {
/* 174 */                 additionalCallbacks.push({
/* 175 */                     "param"     : "buttonClickedCallback",
/* 176 */                     "callback"  : buttonCallback,
/* 177 */                     "repeating" : false
/* 178 */                 });
/* 179 */             }
/* 180 */             
/* 181 */             this.nativeAPI("dialog", "alert", params, statusCallback, additionalCallbacks);
/* 182 */         },
/* 183 */         
/* 184 */         actionDialog: function (title, 
/* 185 */                                 cancelButtonTitle, destructiveButtonTitle, alternateButtonTitles, 
/* 186 */                                 statusCallback, buttonCallback) {
/* 187 */             // required params
/* 188 */             var params = {
/* 189 */                 "title" : title,
/* 190 */                 "cancelButtonTitle" : cancelButtonTitle
/* 191 */             };
/* 192 */             
/* 193 */             // optional params
/* 194 */             if (typeof destructiveButtonTitle == "string") {
/* 195 */                 params["destructiveButtonTitle"] = destructiveButtonTitle;
/* 196 */             }
/* 197 */             if (typeof alternateButtonTitles != "undefined") {
/* 198 */                 for (var i = 0; i < alternateButtonTitles.length; i++) {
/* 199 */                     params["alternateButtonTitle"+i] = alternateButtonTitles[i];
/* 200 */                 }

/* common-common-native.js */

/* 201 */             }
/* 202 */             
/* 203 */             // optional callbacks
/* 204 */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 205 */             
/* 206 */             var additionalCallbacks = [];
/* 207 */             if (typeof buttonCallback != "undefined") {
/* 208 */                 additionalCallbacks.push({
/* 209 */                     "param"     : "buttonClickedCallback",
/* 210 */                     "callback"  : buttonCallback,
/* 211 */                     "repeating" : false
/* 212 */                 });
/* 213 */             }
/* 214 */             
/* 215 */             this.nativeAPI("dialog", "action", params, statusCallback, additionalCallbacks);
/* 216 */         },
/* 217 */ 
/* 218 */         //
/* 219 */         // Events
/* 220 */         //
/* 221 */         
/* 222 */         addEventListener: function (eventType, eventHandlerCallback, statusCallback) {
/* 223 */             var params = {
/* 224 */                 "event" : eventType
/* 225 */             };
/* 226 */             
/* 227 */             this.nativeAPI("listener", "add", params, statusCallback, [{
/* 228 */                 "param"     : "eventHandlerCallback",
/* 229 */                 "callback"  : eventHandlerCallback,
/* 230 */                 "repeating" : true
/* 231 */             }]);
/* 232 */         },
/* 233 */         
/* 234 */         removeEventListener: function (eventType, eventHandlerCallback, statusCallback) {
/* 235 */             var params = {
/* 236 */                 "event" : eventType
/* 237 */             };
/* 238 */             
/* 239 */             this.nativeAPI("listener", "remove", params, statusCallback, [{
/* 240 */                 "param"     : "eventHandlerCallback",
/* 241 */                 "callback"  : eventHandlerCallback,
/* 242 */                 "repeating" : true,
/* 243 */                 "remove"    : true
/* 244 */             }]);
/* 245 */         },
/* 246 */         
/* 247 */         // ====================================================================
/* 248 */         // Low level implementation
/* 249 */         // ====================================================================
/* 250 */         

/* common-common-native.js */

/* 251 */         nativeAPI: function (category, type, params, statusCallback, additionalCallbacks) {
/* 252 */             var url = "kgobridge://"+escape(category)+"/"+escape(type);
/* 253 */             var paramStrings = [];
/* 254 */             if (typeof params == "object") {
/* 255 */                 for (var key in params) {
/* 256 */                     paramStrings.push(escape(key)+"="+escape(params[key]));
/* 257 */                 }
/* 258 */             }
/* 259 */             
/* 260 */             // status callback
/* 261 */             var that = this;
/* 262 */             var callbackId = this.callbackIdCounter++;
/* 263 */             this.callbacks[callbackId] = {
/* 264 */                 "callback" : function (error, params) {
/* 265 */                     if (error !== null && "code" in error) {
/* 266 */                         var code = error["code"];
/* 267 */                         var title = "title" in error ? error["title"] : "Unknown Title";
/* 268 */                         var message = "message" in error ? error["message"] : "Unknown message";
/* 269 */                         
/* 270 */                         for (codeKey in that.errorCodes) {
/* 271 */                             if (that.errorCodes[codeKey] == code) {
/* 272 */                                 code = codeKey;
/* 273 */                                 break;
/* 274 */                             }
/* 275 */                         }
/* 276 */                         that.log("kgoBridge api returned error "+code+" ("+title+" : "+message+")");
/* 277 */                     }
/* 278 */                     if (typeof statusCallback != "undefined" && statusCallback) {
/* 279 */                         statusCallback(error, params);
/* 280 */                     }
/* 281 */                     if (error !== null && typeof additionalCallbacks != "undefined") {
/* 282 */                         // Remove other callbacks on error
/* 283 */                         for (var i = 0; i < additionalCallbacks.length; i++) {
/* 284 */                             if (typeof additionalCallbacks[i]["remove"] == "undefined" || !additionalCallbacks[i]["remove"]) {
/* 285 */                                 var callbackId = that.callbackIdForCallback(additionalCallbacks[i]["callback"]);
/* 286 */                                 if (callbackId) {
/* 287 */                                     delete that.callbacks[callbackId];
/* 288 */                                 }
/* 289 */                             }
/* 290 */                         }
/* 291 */                     }
/* 292 */                 },
/* 293 */                 "repeating" : false
/* 294 */             };
/* 295 */             paramStrings.push("statusCallback="+callbackId);
/* 296 */             
/* 297 */             // additional callbacks
/* 298 */             if (typeof additionalCallbacks != "undefined") {
/* 299 */                 for (var i = 0; i < additionalCallbacks.length; i++) {
/* 300 */                     if (typeof additionalCallbacks[i]["remove"] == "undefined" || !additionalCallbacks[i]["remove"]) {

/* common-common-native.js */

/* 301 */                         // Adding a callback
/* 302 */                         var callbackId = this.callbackIdCounter++;
/* 303 */                         this.callbacks[callbackId] = {
/* 304 */                             "callback"  : additionalCallbacks[i]["callback"],
/* 305 */                             "repeating" : additionalCallbacks[i]["repeating"]
/* 306 */                         };
/* 307 */                         paramStrings.push(additionalCallbacks[i]["param"]+"="+callbackId);
/* 308 */                         
/* 309 */                     } else {
/* 310 */                         // Removing a callback
/* 311 */                         var callbackId = this.callbackIdForCallback(additionalCallbacks[i]["callback"]);
/* 312 */                         if (callbackId) {
/* 313 */                             paramStrings.push(additionalCallbacks[i]["param"]+"="+callbackId);
/* 314 */                             delete this.callbacks[callbackId];
/* 315 */                         }
/* 316 */                     }
/* 317 */                 }
/* 318 */             }
/* 319 */             
/* 320 */             if (paramStrings.length) {
/* 321 */                 url += "?"+paramStrings.join("&");
/* 322 */             }
/* 323 */             
/* 324 */             this.loadURL(url);
/* 325 */         },
/* 326 */         
/* 327 */         nativeAPICallback: function (callbackId, error, params) {
/* 328 */             if (callbackId in this.callbacks && this.callbacks[callbackId]) {
/* 329 */                 if (typeof params !== "object") {
/* 330 */                     params = {};
/* 331 */                 }
/* 332 */                 
/* 333 */                 // Callbacks frequently perform operations which will not work
/* 334 */                 // at the time the native app sends the callback (alert, log, etc)
/* 335 */                 // So delay the callback by 100ms to avoid these problems.
/* 336 */                 var that = this;
/* 337 */                 setTimeout(function () {
/* 338 */                     that.callbacks[callbackId]["callback"].call(that, error, params);
/* 339 */                     
/* 340 */                     if (!that.callbacks[callbackId]["repeating"]) {
/* 341 */                         delete that.callbacks[callbackId];
/* 342 */                     }
/* 343 */                 }, 100);
/* 344 */             }
/* 345 */         },
/* 346 */         
/* 347 */         callbackIdForCallback: function (callback) {
/* 348 */             for (var callbackId in this.callbacks) {
/* 349 */                 if (this.callbacks[callbackId]["callback"] === callback) {
/* 350 */                     return callbackId;

/* common-common-native.js */

/* 351 */                 }
/* 352 */             }
/* 353 */             return null;
/* 354 */         },
/* 355 */         
/* 356 */         loadURL: function (url) {
/* 357 */             var lcURL = url.toLowerCase();
/* 358 */             if (lcURL.indexOf("http://") == 0 || lcURL.indexOf("https://") == 0) {
/* 359 */                 // wrap external URLs so that we don't get confused by other iframes
/* 360 */                 url = "kgobridge://external/link?url="+encodeURIComponent(url);
/* 361 */             }
/* 362 */             
/* 363 */             if (this.config.events) {
/* 364 */                 var iframe = document.createElement("IFRAME");
/* 365 */                 iframe.setAttribute("src", url);
/* 366 */                 document.documentElement.appendChild(iframe);
/* 367 */                 iframe.parentNode.removeChild(iframe);
/* 368 */                 iframe = null;
/* 369 */             } else {
/* 370 */                 this.log("kgoBridge would have called "+url);
/* 371 */             }
/* 372 */         },
/* 373 */         
/* 374 */         localizedString: function (key) {
/* 375 */             if (key in this.config.localizedStrings) {
/* 376 */                 return this.config.localizedStrings[key];
/* 377 */             } else {
/* 378 */                 return key;
/* 379 */             }
/* 380 */         },
/* 381 */         
/* 382 */         ajaxLoad: function () {
/* 383 */             var pageURL = this.config.url+this.config.pagePath+"?"+this.config.ajaxArgs;
/* 384 */             if (this.config.pageArgs.length) {
/* 385 */                 pageURL += "&"+this.config.pageArgs;
/* 386 */             }
/* 387 */             
/* 388 */             ajaxContentIntoContainer({
/* 389 */                 url: pageURL, 
/* 390 */                 container: document.getElementById("container"), 
/* 391 */                 timeout: this.config.timeout, 
/* 392 */                 error: this.initPageError
/* 393 */             });
/* 394 */         },
/* 395 */         
/* 396 */         bridgeToAjaxLink: function (href) {
/* 397 */             // must be able to pass through non-kgobridge links
/* 398 */             var bridgePrefix = "kgobridge://link/";
/* 399 */             var oldhref= href;
/* 400 */             if (href.indexOf(bridgePrefix) == 0) {

/* common-common-native.js */

/* 401 */                 href = this.config.url+"/"+href.substr(bridgePrefix.length);
/* 402 */                 
/* 403 */                 var anchor = '';
/* 404 */                 var anchorPos = href.indexOf("#");
/* 405 */                 if (anchorPos > 0) {
/* 406 */                     anchor = href.substr(anchorPos);
/* 407 */                     href = href.substr(0, anchorPos);
/* 408 */                 }
/* 409 */                 href = href+(href.indexOf("?") > 0 ? "&" : "?")+this.config.ajaxArgs+anchor;
/* 410 */             }
/* 411 */             return href;
/* 412 */         },
/* 413 */         
/* 414 */         log: function (message) {
/* 415 */             if (this.config.events) {
/* 416 */                 this.loadURL("kgobridge://console/log?message="+encodeURIComponent(message));
/* 417 */                 
/* 418 */             } else if (typeof console != "undefined" && typeof console.log != "undefined") {
/* 419 */                 console.log("KGO_LOG: "+message);
/* 420 */             }
/* 421 */         }
/* 422 */     };
/* 423 */     
/* 424 */     window.kgoBridgeHandler = kgoBridgeHandler;
/* 425 */ })(window);
/* 426 */ 

;
/* tablet-common-native.js */

/* 1  */ var oldSetContainerWrapperHeight = setContainerWrapperHeight;
/* 2  */ setContainerWrapperHeight = function () {
/* 3  */     if (!hasClass(document.body, 'iscroll-off')) {
/* 4  */         oldSetContainerWrapperHeight();
/* 5  */     }
/* 6  */ }
/* 7  */ 
/* 8  */ // form element-safe version of iScroll initialization
/* 9  */ var oldIScrollInit = iScrollInit;
/* 10 */ iScrollInit = function (id, options) {
/* 11 */     if (hasClass(document.body, 'iscroll-off')) {
/* 12 */         removeClass(document.body, 'iscroll-off');
/* 13 */         document.documentElement.style.height = "100%";
/* 14 */         document.documentElement.style.height = "hidden";
/* 15 */         
/* 16 */         setContainerWrapperHeight();
/* 17 */     }
/* 18 */     return oldIScrollInit(id, options);
/* 19 */ }
/* 20 */ 
/* 21 */ function tabletInit() {
/* 22 */     addClass(document.body, 'iscroll-off');
/* 23 */     
/* 24 */     window.splitView.prototype.oldLinkSelect = window.splitView.prototype.linkSelect;
/* 25 */     window.splitView.prototype.linkSelect = function(e, link) {
/* 26 */         link.href = kgoBridge.bridgeToAjaxLink(link.href);
/* 27 */         this.oldLinkSelect(e, link);
/* 28 */     };
/* 29 */     
/* 30 */     setOrientation(getOrientation());
/* 31 */     
/* 32 */     setContainerWrapperHeight();
/* 33 */     
/* 34 */     // Adjust wrapper height on orientation change or resize
/* 35 */     var resizeEvent = 'onorientationchange' in window ? 'orientationchange' : 'resize';
/* 36 */     window.addEventListener(resizeEvent, function() {setTimeout(handleWindowResize,0)}, false);
/* 37 */     
/* 38 */     handleWindowResize();
/* 39 */     //run module init if present
/* 40 */     if (typeof moduleInit != 'undefined') {
/* 41 */         moduleInit();
/* 42 */     }
/* 43 */ }
/* 44 */ 

;
/* common.js */

/* 1  */ // Initalize the ellipsis event handlers
/* 2  */ var newsEllipsizer;
/* 3  */ function setupNewsListing() {
/* 4  */     newsEllipsizer = new ellipsizer();
/* 5  */     
/* 6  */     // cap at 100 divs to avoid overloading phone
/* 7  */     for (var i = 0; i < 100; i++) {
/* 8  */         var elem = document.getElementById('ellipsis_'+i);
/* 9  */         if (!elem) { break; }
/* 10 */         newsEllipsizer.addElement(elem);
/* 11 */     }
/* 12 */ }
/* 13 */ 
