
/* common.js */

/* 1   */ String.prototype.strip = function() {
/* 2   */     return this.replace(/^\s+/, '').replace(/\s+$/, '');
/* 3   */ }
/* 4   */ 
/* 5   */ function showTab(id) {
/* 6   */     var tabId = id+'-tab';
/* 7   */     var tabbodyId = id+'-tabbody';
/* 8   */     
/* 9   */     var tab = document.getElementById(tabId);
/* 10  */     var tabbody = document.getElementById(tabbodyId);
/* 11  */     if (!tab || !tabbody) { return; } // safety check
/* 12  */     
/* 13  */     var tabs = tab.parentNode.getElementsByTagName('li');
/* 14  */     if (!tabs) { return; } // safety check
/* 15  */     
/* 16  */     var tabBodies = tabbody.parentNode.childNodes;
/* 17  */     if (!tabBodies) { return; } // safety check
/* 18  */     
/* 19  */     // Display the tab body and hide others
/* 20  */     for (var i = 0; i < tabBodies.length; i++) {
/* 21  */         if (tabBodies[i].id == tabbodyId) {
/* 22  */             show(tabBodies[i].id);
/* 23  */         } else {
/* 24  */             hide(tabBodies[i].id);
/* 25  */         }
/* 26  */     }
/* 27  */     
/* 28  */     // Display the tab and hide others
/* 29  */     for (var i = 0; i < tabs.length; i++) {
/* 30  */         if (tabs[i].id == tabId) {
/* 31  */             addClass(tabs[i], 'active');
/* 32  */         } else {
/* 33  */             removeClass(tabs[i], 'active');
/* 34  */         }
/* 35  */     }
/* 36  */     
/* 37  */     // fake resize event in case tab body was resized while hidden 
/* 38  */     if (document.createEvent) {
/* 39  */         var e = document.createEvent('HTMLEvents');
/* 40  */         e.initEvent('resize', true, true);
/* 41  */         window.dispatchEvent(e);
/* 42  */     
/* 43  */     } else if( document.createEventObject ) {
/* 44  */         var e = document.createEventObject();
/* 45  */         document.documentElement.fireEvent('onresize', e);
/* 46  */     }
/* 47  */     
/* 48  */     onDOMChange();
/* 49  */ }
/* 50  */ 

/* common.js */

/* 51  */ function onOrientationChange() {
/* 52  */     /* the galaxy tab sends orientation change events constantly */
/* 53  */     if (typeof onOrientationChange.lastOrientation == 'undefined') {
/* 54  */         onOrientationChange.lastOrientation = null;
/* 55  */     }
/* 56  */     
/* 57  */     var newOrientation = getOrientation();
/* 58  */     
/* 59  */     if (newOrientation != onOrientationChange.lastOrientation) {
/* 60  */         rotateScreen();
/* 61  */         
/* 62  */         if (typeof onOrientationChange.callbackFunctions !== 'undefined') {
/* 63  */             for (var i = 0; i < onOrientationChange.callbackFunctions.length; i++) {
/* 64  */                 onOrientationChange.callbackFunctions[i]();
/* 65  */             }
/* 66  */         }
/* 67  */         
/* 68  */         onOrientationChange.lastOrientation = newOrientation;
/* 69  */     }
/* 70  */ }
/* 71  */ 
/* 72  */ function onResize() {
/* 73  */     if (typeof onResize.callbackFunctions !== 'undefined') {
/* 74  */         for (var i = 0; i < onResize.callbackFunctions.length; i++) {
/* 75  */             onResize.callbackFunctions[i]();
/* 76  */         }
/* 77  */     }
/* 78  */ }
/* 79  */ 
/* 80  */ function addOnOrientationChangeCallback(callback) {
/* 81  */     if (typeof onOrientationChange.callbackFunctions == 'undefined') {
/* 82  */         onOrientationChange.callbackFunctions = [];
/* 83  */     }
/* 84  */     onOrientationChange.callbackFunctions.push(callback);
/* 85  */     
/* 86  */     if (typeof onResize.callbackFunctions == 'undefined') {
/* 87  */         onResize.callbackFunctions = [];
/* 88  */     }
/* 89  */     onResize.callbackFunctions.push(callback);
/* 90  */ }
/* 91  */ 
/* 92  */ function setupOrientationChangeHandlers() {
/* 93  */     if (window.addEventListener) {
/* 94  */         window.addEventListener("orientationchange", onOrientationChange, false);
/* 95  */     } else if (window.attachEvent) {
/* 96  */         window.attachEvent("onorientationchange", onOrientationChange);
/* 97  */     }
/* 98  */     if (window.addEventListener) {
/* 99  */         window.addEventListener("resize", onResize, false);
/* 100 */     } else if (window.attachEvent) {

/* common.js */

/* 101 */         window.attachEvent("onresize", onResize);
/* 102 */     }
/* 103 */ }
/* 104 */ 
/* 105 */ function rotateScreen() {
/* 106 */   setOrientation(getOrientation());
/* 107 */   setTimeout(scrollToTop, 500);
/* 108 */ }
/* 109 */ 
/* 110 */ function getOrientation() {
/* 111 */     if (typeof getOrientation.orientationIsFlipped == 'undefined') {
/* 112 */         // detect how we are detecting orientation
/* 113 */         getOrientation.orientationIsFlipped = false;
/* 114 */         
/* 115 */         if (!('orientation' in window)) {
/* 116 */             getOrientation.orientationMethod = 'size';
/* 117 */         } else {
/* 118 */             getOrientation.orientationMethod = 'orientation';
/* 119 */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 120 */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 121 */             
/* 122 */             /* at this point the method of orientation detection is not perfect */
/* 123 */             if (navigator.userAgent.match(/(PlayBook.+RIM Tablet|Xoom|Android 3\.\d)/)) {
/* 124 */                 getOrientation.orientationIsFlipped = true;
/* 125 */             }
/* 126 */         }
/* 127 */     }
/* 128 */ 
/* 129 */     switch (getOrientation.orientationMethod) {
/* 130 */         case 'size':
/* 131 */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 132 */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 133 */ 
/* 134 */             return (width > height) ? 'landscape' : 'portrait';
/* 135 */             break;
/* 136 */ 
/* 137 */         case 'orientation':
/* 138 */             switch (window.orientation) {
/* 139 */                 case 0:
/* 140 */                 case 180:
/* 141 */                     return getOrientation.orientationIsFlipped ? 'landscape' : 'portrait';
/* 142 */                     break;
/* 143 */                 
/* 144 */                 case 90:
/* 145 */                 case -90:
/* 146 */                     return getOrientation.orientationIsFlipped ? 'portrait': 'landscape';
/* 147 */                     break;
/* 148 */             }
/* 149 */     }
/* 150 */ }

/* common.js */

/* 151 */ 
/* 152 */ function setOrientation(orientation) {
/* 153 */     var body = document.getElementsByTagName("body")[0];
/* 154 */  
/* 155 */  //remove existing portrait/landscape class if there
/* 156 */     removeClass(body, 'portrait');
/* 157 */     removeClass(body, 'landscape');
/* 158 */     addClass(body, orientation);
/* 159 */ }
/* 160 */ 
/* 161 */ // Localized ajax loading and error content
/* 162 */ // takes either an element or an id
/* 163 */ function showAjaxLoadingMsg(e) {
/* 164 */     if (typeof e == 'string') {
/* 165 */         e = document.getElementById(element);
/* 166 */     }
/* 167 */ 	if (e) {
/* 168 */ 		e.innerHTML = AJAX_CONTENT_LOADING_HTML;
/* 169 */ 	}
/* 170 */ 	onDOMChange();
/* 171 */ }
/* 172 */ 
/* 173 */ function showAjaxErrorMsg(e) {
/* 174 */     if (typeof e == 'string') {
/* 175 */         e = document.getElementById(element);
/* 176 */     }
/* 177 */ 	if (e) {
/* 178 */ 		e.innerHTML = AJAX_CONTENT_ERROR_HTML;
/* 179 */ 	}
/* 180 */ 	onDOMChange();
/* 181 */ }
/* 182 */ 
/* 183 */ function hide(strID) {
/* 184 */ // Hides the object with ID strID 
/* 185 */ 	var objToHide = document.getElementById(strID);
/* 186 */ 	if(objToHide) {
/* 187 */ 		objToHide.style.display = "none";
/* 188 */ 	}
/* 189 */ 	
/* 190 */ 	onDOMChange();
/* 191 */ }
/* 192 */ 
/* 193 */ function show(strID) {
/* 194 */ // Displays the object with ID strID 
/* 195 */ 	var objToHide = document.getElementById(strID);
/* 196 */ 	if(objToHide) {
/* 197 */ 		objToHide.style.display = "block";
/* 198 */ 	}
/* 199 */ 	
/* 200 */ 	onDOMChange();

/* common.js */

/* 201 */ }
/* 202 */ 
/* 203 */ function showHideFull(objContainer) {
/* 204 */ 	var strClass = objContainer.className;
/* 205 */ 	if(strClass.indexOf("collapsed") > -1) {
/* 206 */ 		strClass = strClass.replace("collapsed","expanded");
/* 207 */ 	} else {
/* 208 */ 		strClass = strClass.replace("expanded","collapsed");
/* 209 */ 	}
/* 210 */ 	objContainer.className = strClass;
/* 211 */ 	objContainer.blur();
/* 212 */ 	
/* 213 */ 	onDOMChange();
/* 214 */ }
/* 215 */ 
/* 216 */ function clearField(objField,strDefault) {
/* 217 */ // Clears the placeholder text in an input field if it matches the default string - fixes a bug in Android
/* 218 */ 	if((objField.value==strDefault) || (objField.value=="")) {
/* 219 */ 		objField.value="";
/* 220 */ 	}
/* 221 */ }
/* 222 */ 
/* 223 */ // Android doesn't respond to onfocus="clearField(...)" until the 
/* 224 */ // input field loses focus
/* 225 */ function androidPlaceholderFix(searchbox) {
/* 226 */     // this forces the search box to display the empty string
/* 227 */     // instead of the place holder when the search box takes focus
/* 228 */     if (searchbox.value == "") {
/* 229 */         searchbox.value = "";
/* 230 */     }
/* 231 */ }
/* 232 */ 
/* 233 */ function getCookie(name) {
/* 234 */   var cookie = document.cookie;
/* 235 */   var result = "";
/* 236 */   var start = cookie.indexOf(name + "=");
/* 237 */   if (start > -1) {
/* 238 */     start += name.length + 1;
/* 239 */     var end = cookie.indexOf(";", start);
/* 240 */     if (end < 0) {
/* 241 */       end = cookie.length;
/* 242 */     }
/* 243 */     result = unescape(cookie.substring(start, end));
/* 244 */   }
/* 245 */   return result;
/* 246 */ }
/* 247 */ 
/* 248 */ function setCookie(name, value, expireseconds, path) {
/* 249 */   var exdate = new Date();
/* 250 */   exdate.setTime(exdate.getTime() + (expireseconds * 1000));

/* common.js */

/* 251 */   var exdateclause = (expireseconds == 0) ? "" : "; expires=" + exdate.toGMTString();
/* 252 */   var pathclause = (path == null) ? "" : "; path=" + path;
/* 253 */   document.cookie = name + "=" + escape(value) + exdateclause + pathclause;
/* 254 */ }
/* 255 */ 
/* 256 */ function getCookieArrayValue(name) {
/* 257 */   var value = getCookie(name);
/* 258 */   if (value && value.length) {
/* 259 */     return value.split('@@');
/* 260 */   } else {
/* 261 */     return new Array();
/* 262 */   }
/* 263 */ }
/* 264 */ 
/* 265 */ function setCookieArrayValue(name, values, expireseconds, path) {
/* 266 */   var value = '';
/* 267 */   if (values && values.length) {
/* 268 */     value = values.join('@@');
/* 269 */   }
/* 270 */   setCookie(name, value, expireseconds, path);
/* 271 */ }
/* 272 */ 
/* 273 */ function hasClass(ele,cls) {
/* 274 */     return ele.className.match(new RegExp('(\\s|^)'+cls+'(\\s|$)'));
/* 275 */ }
/* 276 */         
/* 277 */ function addClass(ele,cls) {
/* 278 */     if (!this.hasClass(ele,cls)) ele.className += " "+cls;
/* 279 */ }
/* 280 */ 
/* 281 */ function removeClass(ele,cls) {
/* 282 */     if (hasClass(ele,cls)) {
/* 283 */         var reg = new RegExp('(\\s|^)'+cls+'(\\s|$)');
/* 284 */         ele.className=ele.className.replace(reg,' ').strip();
/* 285 */     }
/* 286 */ }
/* 287 */         
/* 288 */ function toggleClass(ele, cls) {
/* 289 */     if (hasClass(ele, cls)) {
/* 290 */         removeClass(ele, cls);
/* 291 */     } else {
/* 292 */         addClass(ele, cls);
/* 293 */     }
/* 294 */ }
/* 295 */ 
/* 296 */ // Share-related functions
/* 297 */ function showShare() {
/* 298 */     if (!document.getElementById("sharesheet")) {
/* 299 */         return;
/* 300 */     }

/* common.js */

/* 301 */ 	document.getElementById("sharesheet").style.display="block";
/* 302 */ 	var iframes = document.getElementsByTagName('iframe');
/* 303 */ 	for (var i=0; i<iframes.length; i++) {
/* 304 */ 	    iframes[i].style.visibility = 'hidden';
/* 305 */ 	    iframes[i].style.height = '0';
/* 306 */ 	}
/* 307 */ 	window.scrollTo(0,0);
/* 308 */ }
/* 309 */ function hideShare() {
/* 310 */     if (!document.getElementById("sharesheet")) {
/* 311 */         return;
/* 312 */     }
/* 313 */ 	document.getElementById("sharesheet").style.display="none";
/* 314 */ 	var iframes = document.getElementsByTagName('iframe');
/* 315 */ 	for (var i=0; i<iframes.length; i++) {
/* 316 */ 	    iframes[i].style.visibility = 'visible';
/* 317 */ 	    iframes[i].style.height = '';
/* 318 */ 	}
/* 319 */ }
/* 320 */ 
/* 321 */ // Bookmarks
/* 322 */ function toggleBookmark(name, item, expireseconds, path, bookmarkId) {
/* 323 */   // facility for module to respond to bookmark state change
/* 324 */   if (typeof moduleBookmarkWillToggle != 'undefined') {
/* 325 */     $result = moduleBookmarkWillToggle(name, item, expireseconds, path);
/* 326 */     if ($result === false) { return; }
/* 327 */   }
/* 328 */ 
/* 329 */   if (!bookmarkId) {
/* 330 */     bookmarkId = "bookmark";
/* 331 */   }
/* 332 */   var bookmark = document.getElementById(bookmarkId);
/* 333 */   toggleClass(bookmark, "on");
/* 334 */   var items = getCookieArrayValue(name);
/* 335 */   var newItems = new Array();
/* 336 */   if (items.length == 0) {
/* 337 */     newItems[0] = item;
/* 338 */   } else {
/* 339 */     var found = false;
/* 340 */     for (var i = 0; i < items.length; i++) {
/* 341 */       if (items[i] == item) {
/* 342 */         found = true;
/* 343 */       } else {
/* 344 */         newItems.push(items[i]);
/* 345 */       }
/* 346 */     }
/* 347 */     if (!found) {
/* 348 */       newItems.push(item);
/* 349 */     }
/* 350 */   }

/* common.js */

/* 351 */   setCookieArrayValue(name, newItems, expireseconds, path);
/* 352 */   
/* 353 */   // facility for module to respond to bookmark state change
/* 354 */   if (typeof moduleBookmarkToggled != 'undefined') {
/* 355 */     moduleBookmarkToggled(name, item, expireseconds, path);
/* 356 */   }
/* 357 */ }
/* 358 */ 
/* 359 */ // TODO this needs to handle encoded strings and parameter separators (&amp;)
/* 360 */ if (typeof makeAPICall === 'undefined' && typeof jQuery === 'undefined') {
/* 361 */   function makeAPICall(type, module, command, data, callback) {
/* 362 */     var urlParts = [];
/* 363 */     for (var param in data) {
/* 364 */       urlParts.push(param + "=" + data[param]);
/* 365 */     }
/* 366 */     url = URL_BASE + API_URL_PREFIX + '/' + module + '/' + command + '?' + urlParts.join('&');
/* 367 */     var handleError = function(errorObj) {}
/* 368 */ 
/* 369 */     var httpRequest = new XMLHttpRequest();
/* 370 */     httpRequest.open("GET", url, true);
/* 371 */     httpRequest.onreadystatechange = function() {
/* 372 */       if (httpRequest.readyState == 4 && httpRequest.status == 200) {
/* 373 */         var obj;
/* 374 */         if (window.JSON) {
/* 375 */             obj = JSON.parse(httpRequest.responseText);
/* 376 */             // TODO: catch SyntaxError
/* 377 */         } else {
/* 378 */             obj = eval('(' + httpRequest.responseText + ')');
/* 379 */         }
/* 380 */         if (obj !== undefined) {
/* 381 */           if ("response" in obj) {
/* 382 */             callback(obj["response"]);
/* 383 */           }
/* 384 */ 
/* 385 */           if ("error" in obj && obj["error"] !== null) {
/* 386 */             handleError(obj["error"]);
/* 387 */           } else {
/* 388 */             handleError("response not found");
/* 389 */           }
/* 390 */         } else {
/* 391 */           handleError("failed to parse response");
/* 392 */         }
/* 393 */       }
/* 394 */     }
/* 395 */     httpRequest.send(null);
/* 396 */   }
/* 397 */ }
/* 398 */ 
/* 399 */ function ajaxContentIntoContainer(options) {
/* 400 */     if (typeof options != 'object') { return; } // safety

/* common.js */

/* 401 */     
/* 402 */     if (typeof ajaxContentIntoContainer.pendingRequests == 'undefined') {
/* 403 */         ajaxContentIntoContainer.pendingRequests = new Array();
/* 404 */     }
/* 405 */     
/* 406 */     var _removeRequestsForContainer = function (container) {
/* 407 */         // go backwards so removing items doesn't cause us to skip requests
/* 408 */         for (var i = ajaxContentIntoContainer.pendingRequests.length-1; i >= 0; i--) {
/* 409 */             if (ajaxContentIntoContainer.pendingRequests[i].options.container == container) {
/* 410 */                 ajaxContentIntoContainer.pendingRequests[i].httpRequest.abort();
/* 411 */                 ajaxContentIntoContainer.pendingRequests.splice(i, 1);
/* 412 */             }
/* 413 */         }
/* 414 */     }
/* 415 */     
/* 416 */     var _removeCompletedRequest = function (httpRequest) {
/* 417 */         for (var i = 0; i < ajaxContentIntoContainer.pendingRequests.length; i++) {
/* 418 */             if (ajaxContentIntoContainer.pendingRequests[i].httpRequest == httpRequest) {
/* 419 */                 ajaxContentIntoContainer.pendingRequests.splice(i, 1);
/* 420 */                 break;
/* 421 */             }
/* 422 */         }
/* 423 */     }
/* 424 */    
/* 425 */     var defaults = {
/* 426 */         url: null, 
/* 427 */         container: null, 
/* 428 */         timeout: 60, 
/* 429 */         addAjaxParameter: true,
/* 430 */         loadMessage: true,
/* 431 */         errorMessage: true,
/* 432 */         success: function () {},
/* 433 */         error: function (code) {} 
/* 434 */     };
/* 435 */     for (var i in defaults) {
/* 436 */         if (typeof options[i] == 'undefined') {
/* 437 */             options[i] = defaults[i];
/* 438 */         }
/* 439 */     }
/* 440 */     if (!options.url || !options.container) { return; } // safety
/* 441 */     
/* 442 */     if (options.addAjaxParameter && options.url.search(/[\?\&]ajax=/) < 0) {
/* 443 */         options.url += (options.url.search(/\?/) < 0 ? "?" : "&")+"ajax=1";
/* 444 */     }
/* 445 */     
/* 446 */     _removeRequestsForContainer(options.container);
/* 447 */     
/* 448 */     var httpRequest = new XMLHttpRequest();
/* 449 */     httpRequest.open("GET", options.url, true);
/* 450 */     

/* common.js */

/* 451 */     var requestTimer = setTimeout(function() {
/* 452 */         // some browsers set readyState to 4 on abort so remove handler first
/* 453 */         httpRequest.onreadystatechange = function() { };
/* 454 */         httpRequest.abort();
/* 455 */         
/* 456 */         options.error(408); // http request timeout status code
/* 457 */     }, options.timeout * 1000);
/* 458 */     
/* 459 */     httpRequest.onreadystatechange = function() {
/* 460 */         // return if still in progress
/* 461 */         if (httpRequest.readyState != 4) { return; }
/* 462 */         
/* 463 */         // Got answer, don't abort
/* 464 */         clearTimeout(requestTimer);
/* 465 */         
/* 466 */         if (httpRequest.status == 200) { // Success
/* 467 */             options.container.innerHTML = "";
/* 468 */             
/* 469 */             var div = document.createElement("div");
/* 470 */             div.innerHTML = httpRequest.responseText;
/* 471 */             
/* 472 */             // Manually appendChild elements so scripts get evaluated
/* 473 */             for (var i = 0; i < div.childNodes.length; i++) {
/* 474 */                 var node = div.childNodes[i].cloneNode(true);
/* 475 */                 
/* 476 */                 if (node.nodeName == "SCRIPT") {
/* 477 */                     document.body.appendChild(node);
/* 478 */                 } else if (node.nodeName == "STYLE") {
/* 479 */                     document.getElementsByTagName("head")[0].appendChild(node);
/* 480 */                 } else {
/* 481 */                     options.container.appendChild(node);
/* 482 */                 }
/* 483 */             }
/* 484 */             
/* 485 */             options.success();
/* 486 */             
/* 487 */         } else {
/* 488 */             if (options.errorMessage) {
/* 489 */                 showAjaxErrorMsg(options.container);
/* 490 */             }
/* 491 */             options.error(httpRequest.status);
/* 492 */         }
/* 493 */         
/* 494 */         _removeCompletedRequest(httpRequest);
/* 495 */     };
/* 496 */     
/* 497 */     if (options.loadMessage) {
/* 498 */         showAjaxLoadingMsg(options.container);
/* 499 */     }
/* 500 */     

/* common.js */

/* 501 */     httpRequest.send(null);
/* 502 */     
/* 503 */     ajaxContentIntoContainer.pendingRequests.push({
/* 504 */         'options'     : options,
/* 505 */         'httpRequest' : httpRequest
/* 506 */     });
/* 507 */ }
/* 508 */ 
/* 509 */ function getCSSValue(element, key) {
/* 510 */     if (window.getComputedStyle) {
/* 511 */         return document.defaultView.getComputedStyle(element, null).getPropertyValue(key);
/* 512 */         
/* 513 */     } else if (element.currentStyle) {
/* 514 */         if (key == 'float') { 
/* 515 */             key = 'styleFloat'; 
/* 516 */         } else {
/* 517 */             var re = /(\-([a-z]){1})/g; // hyphens to camel case
/* 518 */             if (re.test(key)) {
/* 519 */                 key = key.replace(re, function () {
/* 520 */                     return arguments[2].toUpperCase();
/* 521 */                 });
/* 522 */             }
/* 523 */         }
/* 524 */         return element.currentStyle[key] ? element.currentStyle[key] : null;
/* 525 */     }
/* 526 */     return '';
/* 527 */ }
/* 528 */ 
/* 529 */ function getCSSHeight(element) {
/* 530 */     return element.offsetHeight
/* 531 */         - parseFloat(getCSSValue(element, 'border-top-width')) 
/* 532 */         - parseFloat(getCSSValue(element, 'border-bottom-width'))
/* 533 */         - parseFloat(getCSSValue(element, 'padding-top'))
/* 534 */         - parseFloat(getCSSValue(element, 'padding-bottom'));
/* 535 */ }
/* 536 */ 

;
/* compliant.js */

/* 1 */ function scrollToTop() {
/* 2 */ 	scrollTo(0,1); 
/* 3 */ }
/* 4 */ 
/* 5 */ function onDOMChange() {
/* 6 */   // Not needed for compliant
/* 7 */ }
/* 8 */ 

;
/* common-common-native.js */

/* 1   */ function scrollToTop() {
/* 2   */ 	scrollTo(0,0); 
/* 3   */ }
/* 4   */ 
/* 5   */ function getCookie(name) {
/* 6   */     return kgoBridge.getCookie(name);
/* 7   */ }
/* 8   */ 
/* 9   */ function setCookie(name, value, expireseconds) {
/* 10  */     kgoBridge.setCookie(name, value, expireseconds);
/* 11  */ }
/* 12  */ 
/* 13  */ (function (window) {
/* 14  */     function kgoBridgeHandler(config) {
/* 15  */         if (typeof config == 'object') {
/* 16  */             for (var i in config) {
/* 17  */                 this.config[i] = config[i];
/* 18  */             }
/* 19  */         }
/* 20  */         
/* 21  */         if (!this.config.events) {
/* 22  */             // desktop emulation mode does not provide cookies
/* 23  */             var pairs = document.cookie.split(";");
/* 24  */             this.config.cookies = {};
/* 25  */             for (var i = 0; i < pairs.length; i++) {
/* 26  */                 var pair = pairs[i].split("=");
/* 27  */                 if (pair.length == 2) {
/* 28  */                     var name = pair[0].replace(/^\s+|\s+$/g, "");
/* 29  */                     var value = pair[1].replace(/^\s+|\s+$/g, "");
/* 30  */                     this.config.cookies[name] = value;
/* 31  */                 }
/* 32  */             }
/* 33  */         }
/* 34  */     }
/* 35  */     
/* 36  */     kgoBridgeHandler.prototype = {
/* 37  */         // DO NOT CHANGE THE NAMES OF THE KEYS IN THE CONFIG
/* 38  */         // SOME OF THEM ARE HARDCODED IN THE NATIVE APPS!
/* 39  */         config: {
/* 40  */             events: false,  // desktop browser simulation mode
/* 41  */             url: "",
/* 42  */             ajaxArgs: "",
/* 43  */             pagePath: "",
/* 44  */             pageArgs: "",
/* 45  */             timeout: 60,
/* 46  */             cookiePath: "",
/* 47  */             cookies: {},
/* 48  */             localizedStrings: {}
/* 49  */         },
/* 50  */         callbacks : {},

/* common-common-native.js */

/* 51  */         callbackIdCounter : 0,
/* 52  */         
/* 53  */         // This code list is duplicated in iOS and Android code.  
/* 54  */         // Do not change existing codes!
/* 55  */         errorCodes : {
/* 56  */             KGOBridgeErrorAPINotSupported : 1,
/* 57  */             KGOBridgeErrorJSONConvertFailed : 2
/* 58  */         },
/* 59  */         
/* 60  */         // ====================================================================
/* 61  */         // Bridge API
/* 62  */         // ====================================================================
/* 63  */         
/* 64  */         //
/* 65  */         // Page load
/* 66  */         //
/* 67  */         
/* 68  */         initPage: function (params, statusCallback) {
/* 69  */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 70  */             
/* 71  */             this.nativeAPI("page", "init", params, statusCallback);
/* 72  */         },
/* 73  */         
/* 74  */         //
/* 75  */         // Errors
/* 76  */         //
/* 77  */         
/* 78  */         initPageError: function (httpStatus, title, message) {
/* 79  */             switch (httpStatus) {
/* 80  */                 case 401:
/* 81  */                 case 407:
/* 82  */                     title = this.localizedString("ERROR_HTTP_UNAUTHORIZED_REQUEST_TITLE");
/* 83  */                     message = this.localizedString("ERROR_HTTP_UNAUTHORIZED_REQUEST_MESSAGE");
/* 84  */                     break;
/* 85  */                 case 408:
/* 86  */                     title = this.localizedString("ERROR_HTTP_CONNECTION_TIMEOUT_TITLE");
/* 87  */                     message = this.localizedString("ERROR_HTTP_CONNECTION_TIMEOUT_MESSAGE");
/* 88  */                     break;
/* 89  */                 case 404:
/* 90  */                 case 503:
/* 91  */                 default:
/* 92  */                     title = this.localizedString("ERROR_HTTP_CONNECTION_FAILED_TITLE");
/* 93  */                     message = this.localizedString("ERROR_HTTP_CONNECTION_FAILED_MESSAGE");
/* 94  */                     break;
/* 95  */             }
/* 96  */             
/* 97  */             this.handleError("pageinit", httpStatus, title, message);
/* 98  */         },
/* 99  */ 
/* 100 */         handleError: function (errorType, code, title, message) {

/* common-common-native.js */

/* 101 */             if (typeof title   != "string") { title   = ""; }
/* 102 */             if (typeof message != "string") { message = ""; }
/* 103 */             
/* 104 */             this.nativeAPI("error", errorType, {
/* 105 */                 "code"    : code, 
/* 106 */                 "title"   : title, 
/* 107 */                 "message" : message
/* 108 */             });
/* 109 */         },
/* 110 */         
/* 111 */         //
/* 112 */         // Dialogs
/* 113 */         //
/* 114 */         
/* 115 */         alert: function (message, responseCallback /* optional */) {
/* 116 */             var ok = this.localizedString("BUTTON_OK");
/* 117 */ 
/* 118 */             this.alertDialog(message, null, ok, null, null, function (error, params) {
/* 119 */                 if (typeof responseCallback != "undefined" && responseCallback && error !== null) {
/* 120 */                     responseCallback();
/* 121 */                 }
/* 122 */             }, function (error, params) {
/* 123 */                 if (typeof responseCallback != "undefined" && responseCallback) {
/* 124 */                     responseCallback();
/* 125 */                 }
/* 126 */             });
/* 127 */         },
/* 128 */         
/* 129 */         confirm: function (question, responseCallback) {
/* 130 */             var ok = this.localizedString("BUTTON_OK");
/* 131 */             var cancel = this.localizedString("BUTTON_CANCEL");
/* 132 */             
/* 133 */             this.alertDialog(message, null, ok, cancel, null, function (error, params) {
/* 134 */                 if (error !== null) {
/* 135 */                     responseCallback(false);
/* 136 */                 }
/* 137 */             }, function (error, params) {
/* 138 */                 // Return true when main button is pressed
/* 139 */                 responseCallback(error === null && params["button"] == "main");
/* 140 */             });
/* 141 */         },
/* 142 */         
/* 143 */         shareDialog: function (buttonConfig) {
/* 144 */             var buttonTitles = [];
/* 145 */             var actionURLs = [];
/* 146 */             if ("mail" in buttonConfig) {
/* 147 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_EMAIL"));
/* 148 */                 actionURLs.push(buttonConfig["mail"]);
/* 149 */             }
/* 150 */             if ("facebook" in buttonConfig) {

/* common-common-native.js */

/* 151 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_FACEBOOK"));
/* 152 */                 actionURLs.push(buttonConfig["facebook"]);
/* 153 */             }
/* 154 */             if ("twitter" in buttonConfig) {
/* 155 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_TWITTER"));
/* 156 */                 actionURLs.push(buttonConfig["twitter"]);
/* 157 */             }
/* 158 */             
/* 159 */             var title = this.localizedString("SHARE_THIS_ITEM");
/* 160 */             var cancel = this.localizedString("BUTTON_CANCEL");
/* 161 */             
/* 162 */             var that = this;
/* 163 */             this.actionDialog(title, cancel, null, buttonTitles, null, function(error, params) {
/* 164 */                 if ("button" in params && params["button"].indexOf('alternate') === 0) {
/* 165 */                     var index = +params["button"].substr(9);
/* 166 */                     if (index >= 0 && index < actionURLs.length) {
/* 167 */                         that.loadURL(actionURLs[index]);
/* 168 */                     }
/* 169 */                 }
/* 170 */             });
/* 171 */         },
/* 172 */         
/* 173 */         alertDialog: function (title, message, 
/* 174 */                                cancelButtonTitle, mainButtonTitle, alternateButtonTitle, 
/* 175 */                                statusCallback, buttonCallback) {
/* 176 */             // required params
/* 177 */             var params = {
/* 178 */                 "title" : title,
/* 179 */                 "cancelButtonTitle" : cancelButtonTitle
/* 180 */             };
/* 181 */             
/* 182 */             // optional params
/* 183 */             if (typeof message == "string") {
/* 184 */                 params["message"] = message;
/* 185 */             }
/* 186 */             if (typeof mainButtonTitle == "string") {
/* 187 */                 params["mainButtonTitle"] = mainButtonTitle;
/* 188 */             }
/* 189 */             if (typeof alternateButtonTitle == "string") {
/* 190 */                 params["alternateButtonTitle"] = alternateButtonTitle;
/* 191 */             }
/* 192 */             
/* 193 */             // optional callbacks
/* 194 */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 195 */             
/* 196 */             var additionalCallbacks = [];
/* 197 */             if (typeof buttonCallback != "undefined") {
/* 198 */                 additionalCallbacks.push({
/* 199 */                     "param"     : "buttonClickedCallback",
/* 200 */                     "callback"  : buttonCallback,

/* common-common-native.js */

/* 201 */                     "repeating" : false
/* 202 */                 });
/* 203 */             }
/* 204 */             
/* 205 */             this.nativeAPI("dialog", "alert", params, statusCallback, additionalCallbacks);
/* 206 */         },
/* 207 */         
/* 208 */         actionDialog: function (title, 
/* 209 */                                 cancelButtonTitle, destructiveButtonTitle, alternateButtonTitles, 
/* 210 */                                 statusCallback, buttonCallback) {
/* 211 */             // required params
/* 212 */             var params = {
/* 213 */                 "title" : title,
/* 214 */                 "cancelButtonTitle" : cancelButtonTitle
/* 215 */             };
/* 216 */             
/* 217 */             // optional params
/* 218 */             if (typeof destructiveButtonTitle == "string") {
/* 219 */                 params["destructiveButtonTitle"] = destructiveButtonTitle;
/* 220 */             }
/* 221 */             if (typeof alternateButtonTitles != "undefined") {
/* 222 */                 for (var i = 0; i < alternateButtonTitles.length; i++) {
/* 223 */                     params["alternateButtonTitle"+i] = alternateButtonTitles[i];
/* 224 */                 }
/* 225 */             }
/* 226 */             
/* 227 */             // optional callbacks
/* 228 */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 229 */             
/* 230 */             var additionalCallbacks = [];
/* 231 */             if (typeof buttonCallback != "undefined") {
/* 232 */                 additionalCallbacks.push({
/* 233 */                     "param"     : "buttonClickedCallback",
/* 234 */                     "callback"  : buttonCallback,
/* 235 */                     "repeating" : false
/* 236 */                 });
/* 237 */             }
/* 238 */             
/* 239 */             this.nativeAPI("dialog", "action", params, statusCallback, additionalCallbacks);
/* 240 */         },
/* 241 */ 
/* 242 */         //
/* 243 */         // Events
/* 244 */         //
/* 245 */         
/* 246 */         addEventListener: function (eventType, eventHandlerCallback, statusCallback) {
/* 247 */             var params = {
/* 248 */                 "event" : eventType
/* 249 */             };
/* 250 */             

/* common-common-native.js */

/* 251 */             this.nativeAPI("listener", "add", params, statusCallback, [{
/* 252 */                 "param"     : "eventHandlerCallback",
/* 253 */                 "callback"  : eventHandlerCallback,
/* 254 */                 "repeating" : true
/* 255 */             }]);
/* 256 */         },
/* 257 */         
/* 258 */         removeEventListener: function (eventType, eventHandlerCallback, statusCallback) {
/* 259 */             var params = {
/* 260 */                 "event" : eventType
/* 261 */             };
/* 262 */             
/* 263 */             this.nativeAPI("listener", "remove", params, statusCallback, [{
/* 264 */                 "param"     : "eventHandlerCallback",
/* 265 */                 "callback"  : eventHandlerCallback,
/* 266 */                 "repeating" : true,
/* 267 */                 "remove"    : true
/* 268 */             }]);
/* 269 */         },
/* 270 */         
/* 271 */         //
/* 272 */         // Cookies
/* 273 */         //
/* 274 */         
/* 275 */         getCookie: function (name) {
/* 276 */             return (name in this.config.cookies) ? this.config.cookies[name] : "";
/* 277 */         },
/* 278 */         
/* 279 */         setCookie: function (name, value, expireseconds) {
/* 280 */             var params = {
/* 281 */                 "name"     : name,
/* 282 */                 "value"    : value,
/* 283 */                 "duration" : expireseconds,
/* 284 */                 "path"     : this.config.cookiePath
/* 285 */             };
/* 286 */             
/* 287 */             // set in cookies array so getCookie is consistent
/* 288 */             var oldCookieValue = (name in this.config.cookies) ? this.config.cookies[name] : null;
/* 289 */             this.config.cookies[name] = value;
/* 290 */ 
/* 291 */             if (this.config.events) {
/* 292 */                 // tell native side to set the cookie for us
/* 293 */                 var that = this;
/* 294 */                 this.nativeAPI("cookie", "set", params, function (error, params) {
/* 295 */                     if (error !== null) {
/* 296 */                         // reset to old value on error:
/* 297 */                         if (oldCookieValue !== null) {
/* 298 */                             that.config.cookies[name] = oldCookieValue;
/* 299 */                         } else {
/* 300 */                             delete that.config.cookies[name];

/* common-common-native.js */

/* 301 */                         }
/* 302 */                     }
/* 303 */                 });
/* 304 */             } else {
/* 305 */                 // emulation mode, set cookie in js and remember in cookie object
/* 306 */                 var expires = new Date();
/* 307 */                 expires.setTime(expires.getTime() + (expireseconds * 1000));
/* 308 */ 
/* 309 */                 var cookie = name + "=" + escape(value) + 
/* 310 */                     (expireseconds == 0 ? "" : "; expires=" + expires.toGMTString()) + 
/* 311 */                     "; path=" + this.config.cookiePath;
/* 312 */                 document.cookie = cookie;
/* 313 */                 this.log("kgoBridge would have set cookie: '"+cookie+"'");
/* 314 */             }
/* 315 */         },
/* 316 */         
/* 317 */         // ====================================================================
/* 318 */         // Low level implementation
/* 319 */         // ====================================================================
/* 320 */         
/* 321 */         nativeAPI: function (category, type, params, statusCallback, additionalCallbacks) {
/* 322 */             var url = "kgobridge://"+escape(category)+"/"+escape(type);
/* 323 */             var paramStrings = [];
/* 324 */             if (typeof params == "object") {
/* 325 */                 for (var key in params) {
/* 326 */                     paramStrings.push(escape(key)+"="+escape(params[key]));
/* 327 */                 }
/* 328 */             }
/* 329 */             
/* 330 */             // status callback
/* 331 */             var that = this;
/* 332 */             var callbackId = this.callbackIdCounter++;
/* 333 */             this.callbacks[callbackId] = {
/* 334 */                 "callback" : function (error, params) {
/* 335 */                     if (error !== null && "code" in error) {
/* 336 */                         var code = error["code"];
/* 337 */                         var title = "title" in error ? error["title"] : "Unknown Title";
/* 338 */                         var message = "message" in error ? error["message"] : "Unknown message";
/* 339 */                         
/* 340 */                         for (codeKey in that.errorCodes) {
/* 341 */                             if (that.errorCodes[codeKey] == code) {
/* 342 */                                 code = codeKey;
/* 343 */                                 break;
/* 344 */                             }
/* 345 */                         }
/* 346 */                         that.log("kgoBridge api returned error "+code+" ("+title+" : "+message+")");
/* 347 */                     }
/* 348 */                     if (typeof statusCallback != "undefined" && statusCallback) {
/* 349 */                         statusCallback(error, params);
/* 350 */                     }

/* common-common-native.js */

/* 351 */                     if (error !== null && typeof additionalCallbacks != "undefined") {
/* 352 */                         // Remove other callbacks on error
/* 353 */                         for (var i = 0; i < additionalCallbacks.length; i++) {
/* 354 */                             if (typeof additionalCallbacks[i]["remove"] == "undefined" || !additionalCallbacks[i]["remove"]) {
/* 355 */                                 var callbackId = that.callbackIdForCallback(additionalCallbacks[i]["callback"]);
/* 356 */                                 if (callbackId) {
/* 357 */                                     delete that.callbacks[callbackId];
/* 358 */                                 }
/* 359 */                             }
/* 360 */                         }
/* 361 */                     }
/* 362 */                 },
/* 363 */                 "repeating" : false
/* 364 */             };
/* 365 */             paramStrings.push("statusCallback="+callbackId);
/* 366 */             
/* 367 */             // additional callbacks
/* 368 */             if (typeof additionalCallbacks != "undefined") {
/* 369 */                 for (var i = 0; i < additionalCallbacks.length; i++) {
/* 370 */                     if (typeof additionalCallbacks[i]["remove"] == "undefined" || !additionalCallbacks[i]["remove"]) {
/* 371 */                         // Adding a callback
/* 372 */                         var callbackId = this.callbackIdCounter++;
/* 373 */                         this.callbacks[callbackId] = {
/* 374 */                             "callback"  : additionalCallbacks[i]["callback"],
/* 375 */                             "repeating" : additionalCallbacks[i]["repeating"]
/* 376 */                         };
/* 377 */                         paramStrings.push(additionalCallbacks[i]["param"]+"="+callbackId);
/* 378 */                         
/* 379 */                     } else {
/* 380 */                         // Removing a callback
/* 381 */                         var callbackId = this.callbackIdForCallback(additionalCallbacks[i]["callback"]);
/* 382 */                         if (callbackId) {
/* 383 */                             paramStrings.push(additionalCallbacks[i]["param"]+"="+callbackId);
/* 384 */                             delete this.callbacks[callbackId];
/* 385 */                         }
/* 386 */                     }
/* 387 */                 }
/* 388 */             }
/* 389 */             
/* 390 */             if (paramStrings.length) {
/* 391 */                 url += "?"+paramStrings.join("&");
/* 392 */             }
/* 393 */             
/* 394 */             this.loadURL(url);
/* 395 */         },
/* 396 */         
/* 397 */         nativeAPICallback: function (callbackId, error, params) {
/* 398 */             if (callbackId in this.callbacks && this.callbacks[callbackId]) {
/* 399 */                 if (typeof params !== "object") {
/* 400 */                     params = {};

/* common-common-native.js */

/* 401 */                 }
/* 402 */                 
/* 403 */                 // Callbacks frequently perform operations which will not work
/* 404 */                 // at the time the native app sends the callback (alert, log, etc)
/* 405 */                 // So delay the callback by 100ms to avoid these problems.
/* 406 */                 var that = this;
/* 407 */                 setTimeout(function () {
/* 408 */                     that.callbacks[callbackId]["callback"].call(that, error, params);
/* 409 */                     
/* 410 */                     if (!that.callbacks[callbackId]["repeating"]) {
/* 411 */                         delete that.callbacks[callbackId];
/* 412 */                     }
/* 413 */                 }, 100);
/* 414 */             }
/* 415 */         },
/* 416 */         
/* 417 */         callbackIdForCallback: function (callback) {
/* 418 */             for (var callbackId in this.callbacks) {
/* 419 */                 if (this.callbacks[callbackId]["callback"] === callback) {
/* 420 */                     return callbackId;
/* 421 */                 }
/* 422 */             }
/* 423 */             return null;
/* 424 */         },
/* 425 */         
/* 426 */         loadURL: function (url) {
/* 427 */             var lcURL = url.toLowerCase();
/* 428 */             if (lcURL.indexOf("http://") == 0 || lcURL.indexOf("https://") == 0) {
/* 429 */                 // wrap external URLs so that we don't get confused by other iframes
/* 430 */                 url = "kgobridge://external/link?url="+encodeURIComponent(url);
/* 431 */             }
/* 432 */             
/* 433 */             if (this.config.events) {
/* 434 */                 var iframe = document.createElement("IFRAME");
/* 435 */                 iframe.setAttribute("src", url);
/* 436 */                 document.documentElement.appendChild(iframe);
/* 437 */                 iframe.parentNode.removeChild(iframe);
/* 438 */                 iframe = null;
/* 439 */             } else {
/* 440 */                 this.log("kgoBridge would have called "+url);
/* 441 */             }
/* 442 */         },
/* 443 */         
/* 444 */         localizedString: function (key) {
/* 445 */             if (key in this.config.localizedStrings) {
/* 446 */                 return this.config.localizedStrings[key];
/* 447 */             } else {
/* 448 */                 return key;
/* 449 */             }
/* 450 */         },

/* common-common-native.js */

/* 451 */         
/* 452 */         ajaxLoad: function () {
/* 453 */             var pageURL = this.config.url+this.config.pagePath+"?"+this.config.ajaxArgs;
/* 454 */             if (this.config.pageArgs.length) {
/* 455 */                 pageURL += "&"+this.config.pageArgs;
/* 456 */             }
/* 457 */             
/* 458 */             ajaxContentIntoContainer({
/* 459 */                 url: pageURL, 
/* 460 */                 container: document.getElementById("container"), 
/* 461 */                 timeout: this.config.timeout, 
/* 462 */                 error: this.initPageError
/* 463 */             });
/* 464 */         },
/* 465 */         
/* 466 */         bridgeToAjaxLink: function (href) {
/* 467 */             // must be able to pass through non-kgobridge links
/* 468 */             var bridgePrefix = "kgobridge://link/";
/* 469 */             var oldhref= href;
/* 470 */             if (href.indexOf(bridgePrefix) == 0) {
/* 471 */                 href = this.config.url+"/"+href.substr(bridgePrefix.length);
/* 472 */                 
/* 473 */                 var anchor = '';
/* 474 */                 var anchorPos = href.indexOf("#");
/* 475 */                 if (anchorPos > 0) {
/* 476 */                     anchor = href.substr(anchorPos);
/* 477 */                     href = href.substr(0, anchorPos);
/* 478 */                 }
/* 479 */                 href = href+(href.indexOf("?") > 0 ? "&" : "?")+this.config.ajaxArgs+anchor;
/* 480 */             }
/* 481 */             return href;
/* 482 */         },
/* 483 */         
/* 484 */         log: function (message) {
/* 485 */             if (this.config.events) {
/* 486 */                 this.loadURL("kgobridge://console/log?message="+encodeURIComponent(message));
/* 487 */                 
/* 488 */             } else if (typeof console != "undefined" && typeof console.log != "undefined") {
/* 489 */                 console.log("KGO_LOG: "+message);
/* 490 */             }
/* 491 */         }
/* 492 */     };
/* 493 */     
/* 494 */     window.kgoBridgeHandler = kgoBridgeHandler;
/* 495 */ })(window);
/* 496 */ 

;
/* common.js */

/* 1  */ // Initalize the ellipsis event handlers
/* 2  */ var newsEllipsizer;
/* 3  */ function setupNewsListing() {
/* 4  */     newsEllipsizer = new ellipsizer();
/* 5  */     
/* 6  */     // cap at 100 divs to avoid overloading phone
/* 7  */     for (var i = 0; i < 100; i++) {
/* 8  */         var elem = document.getElementById('ellipsis_'+i);
/* 9  */         if (!elem) { break; }
/* 10 */         newsEllipsizer.addElement(elem);
/* 11 */     }
/* 12 */ }
/* 13 */ 
