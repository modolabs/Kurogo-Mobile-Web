
/* common.js */

/* 1   */ var currentTab;
/* 2   */ 
/* 3   */ String.prototype.strip = function() {
/* 4   */     return this.replace(/^\s+/, '').replace(/\s+$/, '');
/* 5   */ }
/* 6   */ 
/* 7   */ function showTab(strID, objTrigger) {
/* 8   */ // Displays the tab with ID strID
/* 9   */ 	var objTab = document.getElementById(strID);
/* 10  */ 	if(objTab) {
/* 11  */ 		show(strID);
/* 12  */ 		if(currentTab && (currentTab != objTab)) {
/* 13  */ 			hide(currentTab.id);
/* 14  */ 			//currentTab.style.display = "none";
/* 15  */ 		}
/* 16  */ 	}
/* 17  */ 	currentTab = objTab; // Remember which is the currently displayed tab
/* 18  */ 	
/* 19  */ 	// Set the clicked tab to look current
/* 20  */ 	var objTabs = document.getElementById("tabs");
/* 21  */   if (objTabs) {
/* 22  */     var arrTabs = objTabs.getElementsByTagName("li");
/* 23  */     if(objTrigger) {
/* 24  */       for(var i=0; i<arrTabs.length; i++) {
/* 25  */         arrTabs[i].className="";
/* 26  */       }
/* 27  */       var objTriggerTab = objTrigger.parentNode;
/* 28  */       if(objTriggerTab) {
/* 29  */         objTriggerTab.className="active";
/* 30  */       }
/* 31  */     }
/* 32  */ 
/* 33  */     // fake resize event in case tab body was resized while hidden 
/* 34  */     if (document.createEvent) {
/* 35  */       var e = document.createEvent('HTMLEvents');
/* 36  */       e.initEvent('resize', true, true);
/* 37  */       window.dispatchEvent(e);
/* 38  */     
/* 39  */     } else if( document.createEventObject ) {
/* 40  */       var e = document.createEventObject();
/* 41  */       document.documentElement.fireEvent('onresize', e);
/* 42  */     }
/* 43  */   }
/* 44  */ 	
/* 45  */ 	onDOMChange();
/* 46  */ }
/* 47  */ 
/* 48  */ function rotateScreen() {
/* 49  */   setOrientation(getOrientation());
/* 50  */   setTimeout(scrollToTop, 500);

/* common.js */

/* 51  */ }
/* 52  */ 
/* 53  */ function getOrientation() {
/* 54  */     if (typeof getOrientation.orientationIsFlipped == 'undefined') {
/* 55  */         // detect how we are detecting orientation
/* 56  */         getOrientation.orientationIsFlipped = false;
/* 57  */         
/* 58  */         if (!('orientation' in window)) {
/* 59  */             getOrientation.orientationMethod = 'size';
/* 60  */         } else {
/* 61  */             getOrientation.orientationMethod = 'orientation';
/* 62  */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 63  */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 64  */             
/* 65  */             /* at this point the method of orientation detection is not perfect */
/* 66  */             if (navigator.userAgent.match(/(PlayBook.+RIM Tablet|Xoom|Android 3\.\d)/)) {
/* 67  */                 getOrientation.orientationIsFlipped = true;
/* 68  */             }
/* 69  */         }
/* 70  */     }
/* 71  */ 
/* 72  */     switch (getOrientation.orientationMethod) {
/* 73  */         case 'size':
/* 74  */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 75  */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 76  */ 
/* 77  */             return (width > height) ? 'landscape' : 'portrait';
/* 78  */             break;
/* 79  */ 
/* 80  */         case 'orientation':
/* 81  */             switch (window.orientation) {
/* 82  */                 case 0:
/* 83  */                 case 180:
/* 84  */                     return getOrientation.orientationIsFlipped ? 'landscape' : 'portrait';
/* 85  */                     break;
/* 86  */                 
/* 87  */                 case 90:
/* 88  */                 case -90:
/* 89  */                     return getOrientation.orientationIsFlipped ? 'portrait': 'landscape';
/* 90  */                     break;
/* 91  */             }
/* 92  */     }
/* 93  */ }
/* 94  */ 
/* 95  */ function setOrientation(orientation) {
/* 96  */     var body = document.getElementsByTagName("body")[0];
/* 97  */  
/* 98  */  //remove existing portrait/landscape class if there
/* 99  */     removeClass(body, 'portrait');
/* 100 */     removeClass(body, 'landscape');

/* common.js */

/* 101 */     addClass(body, orientation);
/* 102 */ }
/* 103 */ 
/* 104 */ 
/* 105 */ function showLoadingMsg(strID) {
/* 106 */ // Show a temporary loading message in the element with ID strID
/* 107 */ 	var objToStuff = document.getElementById(strID);
/* 108 */ 	if(objToStuff) {
/* 109 */ 		objToStuff.innerHTML = '<div class="loading"><img src="'+URL_BASE+'common/images/loading.gif" width="27" height="21" alt="Loading" align="absmiddle" />Loading data...</div>';
/* 110 */ 	}
/* 111 */ 	onDOMChange();
/* 112 */ }
/* 113 */ 
/* 114 */ function hide(strID) {
/* 115 */ // Hides the object with ID strID 
/* 116 */ 	var objToHide = document.getElementById(strID);
/* 117 */ 	if(objToHide) {
/* 118 */ 		objToHide.style.display = "none";
/* 119 */ 	}
/* 120 */ 	
/* 121 */ 	onDOMChange();
/* 122 */ }
/* 123 */ 
/* 124 */ function show(strID) {
/* 125 */ // Displays the object with ID strID 
/* 126 */ 	var objToHide = document.getElementById(strID);
/* 127 */ 	if(objToHide) {
/* 128 */ 		objToHide.style.display = "block";
/* 129 */ 	}
/* 130 */ 	
/* 131 */ 	onDOMChange();
/* 132 */ }
/* 133 */ 
/* 134 */ function showHideFull(objContainer) {
/* 135 */ 	var strClass = objContainer.className;
/* 136 */ 	if(strClass.indexOf("collapsed") > -1) {
/* 137 */ 		strClass = strClass.replace("collapsed","expanded");
/* 138 */ 	} else {
/* 139 */ 		strClass = strClass.replace("expanded","collapsed");
/* 140 */ 	}
/* 141 */ 	objContainer.className = strClass;
/* 142 */ 	objContainer.blur();
/* 143 */ 	
/* 144 */ 	onDOMChange();
/* 145 */ }
/* 146 */ 
/* 147 */ function clearField(objField,strDefault) {
/* 148 */ // Clears the placeholder text in an input field if it matches the default string - fixes a bug in Android
/* 149 */ 	if((objField.value==strDefault) || (objField.value=="")) {
/* 150 */ 		objField.value="";

/* common.js */

/* 151 */ 	}
/* 152 */ }
/* 153 */ 
/* 154 */ // Android doesn't respond to onfocus="clearField(...)" until the 
/* 155 */ // input field loses focus
/* 156 */ function androidPlaceholderFix(searchbox) {
/* 157 */     // this forces the search box to display the empty string
/* 158 */     // instead of the place holder when the search box takes focus
/* 159 */     if (searchbox.value == "") {
/* 160 */         searchbox.value = "";
/* 161 */     }
/* 162 */ }
/* 163 */ 
/* 164 */ function getCookie(name) {
/* 165 */   var cookie = document.cookie;
/* 166 */   var result = "";
/* 167 */   var start = cookie.indexOf(name + "=");
/* 168 */   if (start > -1) {
/* 169 */     start += name.length + 1;
/* 170 */     var end = cookie.indexOf(";", start);
/* 171 */     if (end < 0) {
/* 172 */       end = cookie.length;
/* 173 */     }
/* 174 */     result = unescape(cookie.substring(start, end));
/* 175 */   }
/* 176 */   return result;
/* 177 */ }
/* 178 */ 
/* 179 */ function setCookie(name, value, expireseconds, path) {
/* 180 */   var exdate = new Date();
/* 181 */   exdate.setTime(exdate.getTime() + (expireseconds * 1000));
/* 182 */   var exdateclause = (expireseconds == 0) ? "" : "; expires=" + exdate.toGMTString();
/* 183 */   var pathclause = (path == null) ? "" : "; path=" + path;
/* 184 */   document.cookie = name + "=" + escape(value) + exdateclause + pathclause;
/* 185 */ }
/* 186 */ 
/* 187 */ function getCookieArrayValue(name) {
/* 188 */   var value = getCookie(name);
/* 189 */   if (value && value.length) {
/* 190 */     return value.split('@@');
/* 191 */   } else {
/* 192 */     return new Array();
/* 193 */   }
/* 194 */ }
/* 195 */ 
/* 196 */ function setCookieArrayValue(name, values, expireseconds, path) {
/* 197 */   var value = '';
/* 198 */   if (values && values.length) {
/* 199 */     value = values.join('@@');
/* 200 */   }

/* common.js */

/* 201 */   setCookie(name, value, expireseconds, path);
/* 202 */ }
/* 203 */ 
/* 204 */ function hasClass(ele,cls) {
/* 205 */     return ele.className.match(new RegExp('(\\s|^)'+cls+'(\\s|$)'));
/* 206 */ }
/* 207 */         
/* 208 */ function addClass(ele,cls) {
/* 209 */     if (!this.hasClass(ele,cls)) ele.className += " "+cls;
/* 210 */ }
/* 211 */ 
/* 212 */ function removeClass(ele,cls) {
/* 213 */     if (hasClass(ele,cls)) {
/* 214 */         var reg = new RegExp('(\\s|^)'+cls+'(\\s|$)');
/* 215 */         ele.className=ele.className.replace(reg,' ').strip();
/* 216 */     }
/* 217 */ }
/* 218 */         
/* 219 */ function toggleClass(ele, cls) {
/* 220 */     if (hasClass(ele, cls)) {
/* 221 */         removeClass(ele, cls);
/* 222 */     } else {
/* 223 */         addClass(ele, cls);
/* 224 */     }
/* 225 */ }
/* 226 */ 
/* 227 */ // Share-related functions
/* 228 */ function showShare() {
/* 229 */     if (!document.getElementById("sharesheet")) {
/* 230 */         return;
/* 231 */     }
/* 232 */ 	document.getElementById("sharesheet").style.display="block";
/* 233 */ 	var iframes = document.getElementsByTagName('iframe');
/* 234 */ 	for (var i=0; i<iframes.length; i++) {
/* 235 */ 	    iframes[i].style.visibility = 'hidden';
/* 236 */ 	    iframes[i].style.height = '0';
/* 237 */ 	}
/* 238 */ 	window.scrollTo(0,0);
/* 239 */ }
/* 240 */ function hideShare() {
/* 241 */     if (!document.getElementById("sharesheet")) {
/* 242 */         return;
/* 243 */     }
/* 244 */ 	document.getElementById("sharesheet").style.display="none";
/* 245 */ 	var iframes = document.getElementsByTagName('iframe');
/* 246 */ 	for (var i=0; i<iframes.length; i++) {
/* 247 */ 	    iframes[i].style.visibility = 'visible';
/* 248 */ 	    iframes[i].style.height = '';
/* 249 */ 	}
/* 250 */ }

/* common.js */

/* 251 */ 
/* 252 */ // Bookmarks
/* 253 */ function toggleBookmark(name, item, expireseconds, path, bookmarkId) {
/* 254 */   // facility for module to respond to bookmark state change
/* 255 */   if (typeof moduleBookmarkWillToggle != 'undefined') {
/* 256 */     $result = moduleBookmarkWillToggle(name, item, expireseconds, path);
/* 257 */     if ($result === false) { return; }
/* 258 */   }
/* 259 */ 
/* 260 */   if (!bookmarkId) {
/* 261 */     bookmarkId = "bookmark";
/* 262 */   }
/* 263 */   var bookmark = document.getElementById(bookmarkId);
/* 264 */   toggleClass(bookmark, "on");
/* 265 */   var items = getCookieArrayValue(name);
/* 266 */   var newItems = new Array();
/* 267 */   if (items.length == 0) {
/* 268 */     newItems[0] = item;
/* 269 */   } else {
/* 270 */     var found = false;
/* 271 */     for (var i = 0; i < items.length; i++) {
/* 272 */       if (items[i] == item) {
/* 273 */         found = true;
/* 274 */       } else {
/* 275 */         newItems.push(items[i]);
/* 276 */       }
/* 277 */     }
/* 278 */     if (!found) {
/* 279 */       newItems.push(item);
/* 280 */     }
/* 281 */   }
/* 282 */   setCookieArrayValue(name, newItems, expireseconds, path);
/* 283 */   
/* 284 */   // facility for module to respond to bookmark state change
/* 285 */   if (typeof moduleBookmarkToggled != 'undefined') {
/* 286 */     moduleBookmarkToggled(name, item, expireseconds, path);
/* 287 */   }
/* 288 */ }
/* 289 */ 
/* 290 */ // TODO this needs to handle encoded strings and parameter separators (&amp;)
/* 291 */ if (typeof makeAPICall === 'undefined' && typeof jQuery === 'undefined') {
/* 292 */   function makeAPICall(type, module, command, data, callback) {
/* 293 */     var urlParts = [];
/* 294 */     for (var param in data) {
/* 295 */       urlParts.push(param + "=" + data[param]);
/* 296 */     }
/* 297 */     url = URL_BASE + API_URL_PREFIX + '/' + module + '/' + command + '?' + urlParts.join('&');
/* 298 */     var handleError = function(errorObj) {}
/* 299 */ 
/* 300 */     var httpRequest = new XMLHttpRequest();

/* common.js */

/* 301 */     httpRequest.open("GET", url, true);
/* 302 */     httpRequest.onreadystatechange = function() {
/* 303 */       if (httpRequest.readyState == 4 && httpRequest.status == 200) {
/* 304 */         var obj;
/* 305 */         if (window.JSON) {
/* 306 */             obj = JSON.parse(httpRequest.responseText);
/* 307 */             // TODO: catch SyntaxError
/* 308 */         } else {
/* 309 */             obj = eval('(' + httpRequest.responseText + ')');
/* 310 */         }
/* 311 */         if (obj !== undefined) {
/* 312 */           if ("response" in obj) {
/* 313 */             callback(obj["response"]);
/* 314 */           }
/* 315 */ 
/* 316 */           if ("error" in obj && obj["error"] !== null) {
/* 317 */             handleError(obj["error"]);
/* 318 */           } else {
/* 319 */             handleError("response not found");
/* 320 */           }
/* 321 */         } else {
/* 322 */           handleError("failed to parse response");
/* 323 */         }
/* 324 */       }
/* 325 */     }
/* 326 */     httpRequest.send(null);
/* 327 */   }
/* 328 */ }
/* 329 */ 
/* 330 */ 
/* 331 */ 
/* 332 */ 
/* 333 */ 
/* 334 */ 
/* 335 */ 
/* 336 */ 
/* 337 */ 

;
/* compliant.js */

/* 1 */ function scrollToTop() {
/* 2 */ 	scrollTo(0,1); 
/* 3 */ }
/* 4 */ 
/* 5 */ function onDOMChange() {
/* 6 */   // Not needed for compliant
/* 7 */ }
/* 8 */ 

;
/* common-common-native.js */

/* 1   */ function scrollToTop() {
/* 2   */ 	scrollTo(0,0); 
/* 3   */ }
/* 4   */ 
/* 5   */ (function (window) {
/* 6   */     function kgoBridgeHandler(config) {
/* 7   */         if (typeof config == 'object') {
/* 8   */             for (var i in config) {
/* 9   */                 this.config[i] = config[i];
/* 10  */             }
/* 11  */         }
/* 12  */     }
/* 13  */     
/* 14  */     kgoBridgeHandler.prototype = {
/* 15  */         config: {
/* 16  */             events: false,  // desktop browser simulation mode
/* 17  */             base: "",
/* 18  */             url: "",
/* 19  */             ajaxArgs: "",
/* 20  */             pagePage: "",
/* 21  */             pageArgs: "",
/* 22  */             serverURL: "",
/* 23  */             timeout: 60,
/* 24  */             localizedStrings: {}
/* 25  */         },
/* 26  */         callbacks : {},
/* 27  */         callbackIdCounter : 0,
/* 28  */         
/* 29  */         // This code list is duplicated in iOS and Android code.  
/* 30  */         // Do not change existing codes!
/* 31  */         errorCodes : {
/* 32  */             KGOBridgeErrorAPINotSupported : 1,
/* 33  */             KGOBridgeErrorJSONConvertFailed : 2
/* 34  */         },
/* 35  */         
/* 36  */         // ====================================================================
/* 37  */         // Bridge API
/* 38  */         // ====================================================================
/* 39  */         
/* 40  */         //
/* 41  */         // Page load
/* 42  */         //
/* 43  */         
/* 44  */         initPage: function (params, statusCallback) {
/* 45  */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 46  */             
/* 47  */             this.nativeAPI("page", "init", params, statusCallback);
/* 48  */         },
/* 49  */         
/* 50  */         //

/* common-common-native.js */

/* 51  */         // Errors
/* 52  */         //
/* 53  */         
/* 54  */         initPageError: function (httpStatus, title, message) {
/* 55  */             switch (httpStatus) {
/* 56  */                 case 401:
/* 57  */                 case 407:
/* 58  */                     title = this.localizedString("ERROR_HTTP_UNAUTHORIZED_REQUEST_TITLE");
/* 59  */                     message = this.localizedString("ERROR_HTTP_UNAUTHORIZED_REQUEST_MESSAGE");
/* 60  */                     break;
/* 61  */                 case 408:
/* 62  */                     title = this.localizedString("ERROR_HTTP_CONNECTION_TIMEOUT_TITLE");
/* 63  */                     message = this.localizedString("ERROR_HTTP_CONNECTION_TIMEOUT_MESSAGE");
/* 64  */                     break;
/* 65  */                 case 404:
/* 66  */                 case 503:
/* 67  */                 default:
/* 68  */                     title = this.localizedString("ERROR_HTTP_CONNECTION_FAILED_TITLE");
/* 69  */                     message = this.localizedString("ERROR_HTTP_CONNECTION_FAILED_MESSAGE");
/* 70  */                     break;
/* 71  */             }
/* 72  */             
/* 73  */             this.handleError("pageinit", httpStatus, title, message);
/* 74  */         },
/* 75  */ 
/* 76  */         handleError: function (errorType, code, title, message) {
/* 77  */             if (typeof title   != "string") { title   = ""; }
/* 78  */             if (typeof message != "string") { message = ""; }
/* 79  */             
/* 80  */             this.nativeAPI("error", errorType, {
/* 81  */                 "code"    : code, 
/* 82  */                 "title"   : title, 
/* 83  */                 "message" : message
/* 84  */             });
/* 85  */         },
/* 86  */         
/* 87  */         //
/* 88  */         // Dialogs
/* 89  */         //
/* 90  */         
/* 91  */         alert: function (message, responseCallback /* optional */) {
/* 92  */             var ok = this.localizedString("BUTTON_OK");
/* 93  */ 
/* 94  */             this.alertDialog(message, null, ok, null, null, function (error, params) {
/* 95  */                 if (typeof responseCallback != "undefined" && responseCallback && error !== null) {
/* 96  */                     responseCallback();
/* 97  */                 }
/* 98  */             }, function (error, params) {
/* 99  */                 if (typeof responseCallback != "undefined" && responseCallback) {
/* 100 */                     responseCallback();

/* common-common-native.js */

/* 101 */                 }
/* 102 */             });
/* 103 */         },
/* 104 */         
/* 105 */         confirm: function (question, responseCallback) {
/* 106 */             var ok = this.localizedString("BUTTON_OK");
/* 107 */             var cancel = this.localizedString("BUTTON_CANCEL");
/* 108 */             
/* 109 */             this.alertDialog(message, null, ok, cancel, null, function (error, params) {
/* 110 */                 if (error !== null) {
/* 111 */                     responseCallback(false);
/* 112 */                 }
/* 113 */             }, function (error, params) {
/* 114 */                 // Return true when main button is pressed
/* 115 */                 responseCallback(error === null && params["button"] == "main");
/* 116 */             });
/* 117 */         },
/* 118 */         
/* 119 */         shareDialog: function (buttonConfig) {
/* 120 */             var buttonTitles = [];
/* 121 */             var actionURLs = [];
/* 122 */             if ("mail" in buttonConfig) {
/* 123 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_EMAIL"));
/* 124 */                 actionURLs.push(buttonConfig["mail"]);
/* 125 */             }
/* 126 */             if ("facebook" in buttonConfig) {
/* 127 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_FACEBOOK"));
/* 128 */                 actionURLs.push(buttonConfig["facebook"]);
/* 129 */             }
/* 130 */             if ("twitter" in buttonConfig) {
/* 131 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_TWITTER"));
/* 132 */                 actionURLs.push(buttonConfig["twitter"]);
/* 133 */             }
/* 134 */             
/* 135 */             var title = this.localizedString("SHARE_THIS_ITEM");
/* 136 */             var cancel = this.localizedString("BUTTON_CANCEL");
/* 137 */             
/* 138 */             var that = this;
/* 139 */             this.actionDialog(title, cancel, null, buttonTitles, null, function(error, params) {
/* 140 */                 if ("button" in params && params["button"].indexOf('alternate') === 0) {
/* 141 */                     var index = +params["button"].substr(9);
/* 142 */                     if (index >= 0 && index < actionURLs.length) {
/* 143 */                         that.loadURL(actionURLs[index]);
/* 144 */                     }
/* 145 */                 }
/* 146 */             });
/* 147 */         },
/* 148 */         
/* 149 */         alertDialog: function (title, message, 
/* 150 */                                cancelButtonTitle, mainButtonTitle, alternateButtonTitle, 

/* common-common-native.js */

/* 151 */                                statusCallback, buttonCallback) {
/* 152 */             // required params
/* 153 */             var params = {
/* 154 */                 "title" : title,
/* 155 */                 "cancelButtonTitle" : cancelButtonTitle
/* 156 */             };
/* 157 */             
/* 158 */             // optional params
/* 159 */             if (typeof message == "string") {
/* 160 */                 params["message"] = message;
/* 161 */             }
/* 162 */             if (typeof mainButtonTitle == "string") {
/* 163 */                 params["mainButtonTitle"] = mainButtonTitle;
/* 164 */             }
/* 165 */             if (typeof alternateButtonTitle == "string") {
/* 166 */                 params["alternateButtonTitle"] = alternateButtonTitle;
/* 167 */             }
/* 168 */             
/* 169 */             // optional callbacks
/* 170 */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 171 */             
/* 172 */             var additionalCallbacks = [];
/* 173 */             if (typeof buttonCallback != "undefined") {
/* 174 */                 additionalCallbacks.push({
/* 175 */                     "param"     : "buttonClickedCallback",
/* 176 */                     "callback"  : buttonCallback,
/* 177 */                     "repeating" : false
/* 178 */                 });
/* 179 */             }
/* 180 */             
/* 181 */             this.nativeAPI("dialog", "alert", params, statusCallback, additionalCallbacks);
/* 182 */         },
/* 183 */         
/* 184 */         actionDialog: function (title, 
/* 185 */                                 cancelButtonTitle, destructiveButtonTitle, alternateButtonTitles, 
/* 186 */                                 statusCallback, buttonCallback) {
/* 187 */             // required params
/* 188 */             var params = {
/* 189 */                 "title" : title,
/* 190 */                 "cancelButtonTitle" : cancelButtonTitle
/* 191 */             };
/* 192 */             
/* 193 */             // optional params
/* 194 */             if (typeof destructiveButtonTitle == "string") {
/* 195 */                 params["destructiveButtonTitle"] = destructiveButtonTitle;
/* 196 */             }
/* 197 */             if (typeof alternateButtonTitles != "undefined") {
/* 198 */                 for (var i = 0; i < alternateButtonTitles.length; i++) {
/* 199 */                     params["alternateButtonTitle"+i] = alternateButtonTitles[i];
/* 200 */                 }

/* common-common-native.js */

/* 201 */             }
/* 202 */             
/* 203 */             // optional callbacks
/* 204 */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 205 */             
/* 206 */             var additionalCallbacks = [];
/* 207 */             if (typeof buttonCallback != "undefined") {
/* 208 */                 additionalCallbacks.push({
/* 209 */                     "param"     : "buttonClickedCallback",
/* 210 */                     "callback"  : buttonCallback,
/* 211 */                     "repeating" : false
/* 212 */                 });
/* 213 */             }
/* 214 */             
/* 215 */             this.nativeAPI("dialog", "action", params, statusCallback, additionalCallbacks);
/* 216 */         },
/* 217 */ 
/* 218 */         //
/* 219 */         // Events
/* 220 */         //
/* 221 */         
/* 222 */         addEventListener: function (eventType, eventHandlerCallback, statusCallback) {
/* 223 */             var params = {
/* 224 */                 "event" : eventType
/* 225 */             };
/* 226 */             
/* 227 */             this.nativeAPI("listener", "add", params, statusCallback, [{
/* 228 */                 "param"     : "eventHandlerCallback",
/* 229 */                 "callback"  : eventHandlerCallback,
/* 230 */                 "repeating" : true
/* 231 */             }]);
/* 232 */         },
/* 233 */         
/* 234 */         removeEventListener: function (eventType, eventHandlerCallback, statusCallback) {
/* 235 */             var params = {
/* 236 */                 "event" : eventType
/* 237 */             };
/* 238 */             
/* 239 */             this.nativeAPI("listener", "remove", params, statusCallback, [{
/* 240 */                 "param"     : "eventHandlerCallback",
/* 241 */                 "callback"  : eventHandlerCallback,
/* 242 */                 "repeating" : true,
/* 243 */                 "remove"    : true
/* 244 */             }]);
/* 245 */         },
/* 246 */         
/* 247 */         // ====================================================================
/* 248 */         // Low level implementation
/* 249 */         // ====================================================================
/* 250 */         

/* common-common-native.js */

/* 251 */         nativeAPI: function (category, type, params, statusCallback, additionalCallbacks) {
/* 252 */             var url = "kgobridge://"+escape(category)+"/"+escape(type);
/* 253 */             var paramStrings = [];
/* 254 */             if (typeof params == "object") {
/* 255 */                 for (var key in params) {
/* 256 */                     paramStrings.push(escape(key)+"="+escape(params[key]));
/* 257 */                 }
/* 258 */             }
/* 259 */             
/* 260 */             // status callback
/* 261 */             var that = this;
/* 262 */             var callbackId = this.callbackIdCounter++;
/* 263 */             this.callbacks[callbackId] = {
/* 264 */                 "callback" : function (error, params) {
/* 265 */                     if (error !== null && "code" in error) {
/* 266 */                         var code = error["code"];
/* 267 */                         var title = "title" in error ? error["title"] : "Unknown Title";
/* 268 */                         var message = "message" in error ? error["message"] : "Unknown message";
/* 269 */                         
/* 270 */                         for (codeKey in that.errorCodes) {
/* 271 */                             if (that.errorCodes[codeKey] == code) {
/* 272 */                                 code = codeKey;
/* 273 */                                 break;
/* 274 */                             }
/* 275 */                         }
/* 276 */                         that.log("kgoBridge api returned error "+code+" ("+title+" : "+message+")");
/* 277 */                     }
/* 278 */                     if (typeof statusCallback != "undefined" && statusCallback) {
/* 279 */                         statusCallback(error, params);
/* 280 */                     }
/* 281 */                     if (error !== null && typeof additionalCallbacks != "undefined") {
/* 282 */                         // Remove other callbacks on error
/* 283 */                         for (var i = 0; i < additionalCallbacks.length; i++) {
/* 284 */                             if (typeof additionalCallbacks[i]["remove"] == "undefined" || !additionalCallbacks[i]["remove"]) {
/* 285 */                                 var callbackId = that.callbackIdForCallback(additionalCallbacks[i]["callback"]);
/* 286 */                                 if (callbackId) {
/* 287 */                                     delete that.callbacks[callbackId];
/* 288 */                                 }
/* 289 */                             }
/* 290 */                         }
/* 291 */                     }
/* 292 */                 },
/* 293 */                 "repeating" : false
/* 294 */             };
/* 295 */             paramStrings.push("statusCallback="+callbackId);
/* 296 */             
/* 297 */             // additional callbacks
/* 298 */             if (typeof additionalCallbacks != "undefined") {
/* 299 */                 for (var i = 0; i < additionalCallbacks.length; i++) {
/* 300 */                     if (typeof additionalCallbacks[i]["remove"] == "undefined" || !additionalCallbacks[i]["remove"]) {

/* common-common-native.js */

/* 301 */                         // Adding a callback
/* 302 */                         var callbackId = this.callbackIdCounter++;
/* 303 */                         this.callbacks[callbackId] = {
/* 304 */                             "callback"  : additionalCallbacks[i]["callback"],
/* 305 */                             "repeating" : additionalCallbacks[i]["repeating"]
/* 306 */                         };
/* 307 */                         paramStrings.push(additionalCallbacks[i]["param"]+"="+callbackId);
/* 308 */                         
/* 309 */                     } else {
/* 310 */                         // Removing a callback
/* 311 */                         var callbackId = this.callbackIdForCallback(additionalCallbacks[i]["callback"]);
/* 312 */                         if (callbackId) {
/* 313 */                             paramStrings.push(additionalCallbacks[i]["param"]+"="+callbackId);
/* 314 */                             delete this.callbacks[callbackId];
/* 315 */                         }
/* 316 */                     }
/* 317 */                 }
/* 318 */             }
/* 319 */             
/* 320 */             if (paramStrings.length) {
/* 321 */                 url += "?"+paramStrings.join("&");
/* 322 */             }
/* 323 */             
/* 324 */             this.loadURL(url);
/* 325 */         },
/* 326 */         
/* 327 */         nativeAPICallback: function (callbackId, error, params) {
/* 328 */             if (callbackId in this.callbacks && this.callbacks[callbackId]) {
/* 329 */                 if (typeof params !== "object") {
/* 330 */                     params = {};
/* 331 */                 }
/* 332 */                 
/* 333 */                 // Callbacks frequently perform operations which will not work
/* 334 */                 // at the time the native app sends the callback (alert, log, etc)
/* 335 */                 // So delay the callback by 100ms to avoid these problems.
/* 336 */                 var that = this;
/* 337 */                 setTimeout(function () {
/* 338 */                     that.callbacks[callbackId]["callback"].call(that, error, params);
/* 339 */                     
/* 340 */                     if (!that.callbacks[callbackId]["repeating"]) {
/* 341 */                         delete that.callbacks[callbackId];
/* 342 */                     }
/* 343 */                 }, 100);
/* 344 */             }
/* 345 */         },
/* 346 */         
/* 347 */         callbackIdForCallback: function (callback) {
/* 348 */             for (var callbackId in this.callbacks) {
/* 349 */                 if (this.callbacks[callbackId]["callback"] === callback) {
/* 350 */                     return callbackId;

/* common-common-native.js */

/* 351 */                 }
/* 352 */             }
/* 353 */             return null;
/* 354 */         },
/* 355 */         
/* 356 */         loadURL: function (url) {
/* 357 */             var lcURL = url.toLowerCase();
/* 358 */             if (lcURL.indexOf("http://") == 0 || lcURL.indexOf("https://") == 0) {
/* 359 */                 // wrap external URLs so that we don't get confused by other iframes
/* 360 */                 url = "kgobridge://external/link?url="+encodeURIComponent(url);
/* 361 */             }
/* 362 */             
/* 363 */             if (this.config.events) {
/* 364 */                 var iframe = document.createElement("IFRAME");
/* 365 */                 iframe.setAttribute("src", url);
/* 366 */                 document.documentElement.appendChild(iframe);
/* 367 */                 iframe.parentNode.removeChild(iframe);
/* 368 */                 iframe = null;
/* 369 */             } else {
/* 370 */                 this.log("kgoBridge would have called "+url);
/* 371 */             }
/* 372 */         },
/* 373 */         
/* 374 */         localizedString: function (key) {
/* 375 */             if (key in this.config.localizedStrings) {
/* 376 */                 return this.config.localizedStrings[key];
/* 377 */             } else {
/* 378 */                 return key;
/* 379 */             }
/* 380 */         },
/* 381 */         
/* 382 */         ajaxLoad: function () {
/* 383 */             var pageURL = this.config.url+this.config.pagePath+"?"+this.config.ajaxArgs;
/* 384 */             if (this.config.pageArgs.length) {
/* 385 */                 pageURL += "&"+this.config.pageArgs;
/* 386 */             }
/* 387 */             var timeout = this.config.timeout * 1000;
/* 388 */             
/* 389 */             var httpRequest = new XMLHttpRequest();
/* 390 */             httpRequest.open("GET", pageURL, true);
/* 391 */             
/* 392 */             var that = this;
/* 393 */             
/* 394 */             var requestTimer = setTimeout(function() {
/* 395 */                 // some browsers set readyState to 4 on abort so remove handler first
/* 396 */                 httpRequest.onreadystatechange = function() { };
/* 397 */                 httpRequest.abort();
/* 398 */                 
/* 399 */                 that.initPageError(408); // http request timeout status code
/* 400 */             }, timeout);

/* common-common-native.js */

/* 401 */             
/* 402 */             httpRequest.onreadystatechange = function() {
/* 403 */                 // return if still in progress
/* 404 */                 if (httpRequest.readyState != 4) { return; }
/* 405 */                 
/* 406 */                 // Got answer, don't abort
/* 407 */                 clearTimeout(requestTimer);
/* 408 */                 
/* 409 */                 if (httpRequest.status == 200) {
/* 410 */                     // Success
/* 411 */                     var container = document.getElementById("container");
/* 412 */                     container.innerHTML = httpRequest.responseText;
/* 413 */                     
/* 414 */                     // Grab script tags and appendChild them so they get evaluated
/* 415 */                     var scripts = container.getElementsByTagName("script");
/* 416 */                     var count = scripts.length; // scripts.length will change as we add elements
/* 417 */                     
/* 418 */                     for (var i = 0; i < count; i++) {
/* 419 */                         var script = document.createElement("script");
/* 420 */                         script.type = "text/javascript";
/* 421 */                         script.text = scripts[i].text;
/* 422 */                         container.appendChild(script);
/* 423 */                     }
/* 424 */                     
/* 425 */                     if (typeof kgoBridgeOnAjaxLoad != 'undefined') {
/* 426 */                         kgoBridgeOnAjaxLoad();
/* 427 */                     } else {
/* 428 */                         that.log("Warning! kgoBridgeOnAjaxLoad is not defined by the page content");
/* 429 */                     }
/* 430 */                     
/* 431 */                 } else {
/* 432 */                     // Error
/* 433 */                     that.initPageError(httpRequest.status);
/* 434 */                 }
/* 435 */             }
/* 436 */             
/* 437 */             httpRequest.send(null);
/* 438 */         },
/* 439 */         
/* 440 */         bridgeToAjaxLink: function (href) {
/* 441 */             // must be able to pass through non-kgobridge links
/* 442 */             var bridgePrefix = "kgobridge://link/";
/* 443 */             var oldhref= href;
/* 444 */             if (href.indexOf(bridgePrefix) == 0) {
/* 445 */                 href = this.config.url+"/"+href.substr(bridgePrefix.length);
/* 446 */                 
/* 447 */                 var anchor = '';
/* 448 */                 var anchorPos = href.indexOf("#");
/* 449 */                 if (anchorPos > 0) {
/* 450 */                     anchor = href.substr(anchorPos);

/* common-common-native.js */

/* 451 */                     href = href.substr(0, anchorPos);
/* 452 */                 }
/* 453 */                 href = href+(href.indexOf("?") > 0 ? "&" : "?")+this.config.ajaxArgs+anchor;
/* 454 */             }
/* 455 */             return href;
/* 456 */         },
/* 457 */         
/* 458 */         log: function (message) {
/* 459 */             if (this.config.events) {
/* 460 */                 this.loadURL("kgobridge://console/log?message="+encodeURIComponent(message));
/* 461 */                 
/* 462 */             } else if (typeof console != "undefined" && typeof console.log != "undefined") {
/* 463 */                 console.log("KGO_LOG: "+message);
/* 464 */             }
/* 465 */         }
/* 466 */     };
/* 467 */     
/* 468 */     window.kgoBridgeHandler = kgoBridgeHandler;
/* 469 */ })(window);
/* 470 */ 

;
/* common.js */

/* 1  */ // Initalize the ellipsis event handlers
/* 2  */ var newsEllipsizer;
/* 3  */ function setupNewsListing() {
/* 4  */     newsEllipsizer = new ellipsizer();
/* 5  */     
/* 6  */     // cap at 100 divs to avoid overloading phone
/* 7  */     for (var i = 0; i < 100; i++) {
/* 8  */         var elem = document.getElementById('ellipsis_'+i);
/* 9  */         if (!elem) { break; }
/* 10 */         newsEllipsizer.addElement(elem);
/* 11 */     }
/* 12 */ }
/* 13 */ 
