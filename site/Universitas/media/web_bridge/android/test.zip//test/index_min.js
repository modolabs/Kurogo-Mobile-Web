
/* common.js */

/* 1   */ var currentTab;
/* 2   */ 
/* 3   */ String.prototype.strip = function() {
/* 4   */     return this.replace(/^\s+/, '').replace(/\s+$/, '');
/* 5   */ }
/* 6   */ 
/* 7   */ function showTab(strID, objTrigger) {
/* 8   */ // Displays the tab with ID strID
/* 9   */ 	var objTab = document.getElementById(strID);
/* 10  */ 	if(objTab) {
/* 11  */ 		show(strID);
/* 12  */ 		if(currentTab && (currentTab != objTab)) {
/* 13  */ 			hide(currentTab.id);
/* 14  */ 			//currentTab.style.display = "none";
/* 15  */ 		}
/* 16  */ 	}
/* 17  */ 	currentTab = objTab; // Remember which is the currently displayed tab
/* 18  */ 	
/* 19  */ 	// Set the clicked tab to look current
/* 20  */ 	var objTabs = document.getElementById("tabs");
/* 21  */   if (objTabs) {
/* 22  */     var arrTabs = objTabs.getElementsByTagName("li");
/* 23  */     if(objTrigger) {
/* 24  */       for(var i=0; i<arrTabs.length; i++) {
/* 25  */         arrTabs[i].className="";
/* 26  */       }
/* 27  */       var objTriggerTab = objTrigger.parentNode;
/* 28  */       if(objTriggerTab) {
/* 29  */         objTriggerTab.className="active";
/* 30  */       }
/* 31  */     }
/* 32  */ 
/* 33  */     // fake resize event in case tab body was resized while hidden 
/* 34  */     if (document.createEvent) {
/* 35  */       var e = document.createEvent('HTMLEvents');
/* 36  */       e.initEvent('resize', true, true);
/* 37  */       window.dispatchEvent(e);
/* 38  */     
/* 39  */     } else if( document.createEventObject ) {
/* 40  */       var e = document.createEventObject();
/* 41  */       document.documentElement.fireEvent('onresize', e);
/* 42  */     }
/* 43  */   }
/* 44  */ 	
/* 45  */ 	onDOMChange();
/* 46  */ }
/* 47  */ 
/* 48  */ function rotateScreen() {
/* 49  */   setOrientation(getOrientation());
/* 50  */   setTimeout(scrollToTop, 500);

/* common.js */

/* 51  */ }
/* 52  */ 
/* 53  */ function getOrientation() {
/* 54  */     if (typeof getOrientation.orientationIsFlipped == 'undefined') {
/* 55  */         // detect how we are detecting orientation
/* 56  */         getOrientation.orientationIsFlipped = false;
/* 57  */         
/* 58  */         if (!('orientation' in window)) {
/* 59  */             getOrientation.orientationMethod = 'size';
/* 60  */         } else {
/* 61  */             getOrientation.orientationMethod = 'orientation';
/* 62  */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 63  */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 64  */             
/* 65  */             /* at this point the method of orientation detection is not perfect */
/* 66  */             if (navigator.userAgent.match(/(PlayBook.+RIM Tablet|Xoom|Android 3\.\d)/)) {
/* 67  */                 getOrientation.orientationIsFlipped = true;
/* 68  */             }
/* 69  */         }
/* 70  */     }
/* 71  */ 
/* 72  */     switch (getOrientation.orientationMethod) {
/* 73  */         case 'size':
/* 74  */             var width = document.documentElement.clientWidth || document.body.clientWidth;
/* 75  */             var height = document.documentElement.clientHeight || document.body.clientHeight;
/* 76  */ 
/* 77  */             return (width > height) ? 'landscape' : 'portrait';
/* 78  */             break;
/* 79  */ 
/* 80  */         case 'orientation':
/* 81  */             switch (window.orientation) {
/* 82  */                 case 0:
/* 83  */                 case 180:
/* 84  */                     return getOrientation.orientationIsFlipped ? 'landscape' : 'portrait';
/* 85  */                     break;
/* 86  */                 
/* 87  */                 case 90:
/* 88  */                 case -90:
/* 89  */                     return getOrientation.orientationIsFlipped ? 'portrait': 'landscape';
/* 90  */                     break;
/* 91  */             }
/* 92  */     }
/* 93  */ }
/* 94  */ 
/* 95  */ function setOrientation(orientation) {
/* 96  */     var body = document.getElementsByTagName("body")[0];
/* 97  */  
/* 98  */  //remove existing portrait/landscape class if there
/* 99  */     removeClass(body, 'portrait');
/* 100 */     removeClass(body, 'landscape');

/* common.js */

/* 101 */     addClass(body, orientation);
/* 102 */ }
/* 103 */ 
/* 104 */ 
/* 105 */ function showLoadingMsg(strID) {
/* 106 */ // Show a temporary loading message in the element with ID strID
/* 107 */ 	var objToStuff = document.getElementById(strID);
/* 108 */ 	if(objToStuff) {
/* 109 */ 		objToStuff.innerHTML = '<div class="loading"><img src="'+URL_BASE+'common/images/loading.gif" width="27" height="21" alt="Loading" align="absmiddle" />Loading data...</div>';
/* 110 */ 	}
/* 111 */ 	onDOMChange();
/* 112 */ }
/* 113 */ 
/* 114 */ function hide(strID) {
/* 115 */ // Hides the object with ID strID 
/* 116 */ 	var objToHide = document.getElementById(strID);
/* 117 */ 	if(objToHide) {
/* 118 */ 		objToHide.style.display = "none";
/* 119 */ 	}
/* 120 */ 	
/* 121 */ 	onDOMChange();
/* 122 */ }
/* 123 */ 
/* 124 */ function show(strID) {
/* 125 */ // Displays the object with ID strID 
/* 126 */ 	var objToHide = document.getElementById(strID);
/* 127 */ 	if(objToHide) {
/* 128 */ 		objToHide.style.display = "block";
/* 129 */ 	}
/* 130 */ 	
/* 131 */ 	onDOMChange();
/* 132 */ }
/* 133 */ 
/* 134 */ function showHideFull(objContainer) {
/* 135 */ 	var strClass = objContainer.className;
/* 136 */ 	if(strClass.indexOf("collapsed") > -1) {
/* 137 */ 		strClass = strClass.replace("collapsed","expanded");
/* 138 */ 	} else {
/* 139 */ 		strClass = strClass.replace("expanded","collapsed");
/* 140 */ 	}
/* 141 */ 	objContainer.className = strClass;
/* 142 */ 	objContainer.blur();
/* 143 */ 	
/* 144 */ 	onDOMChange();
/* 145 */ }
/* 146 */ 
/* 147 */ function clearField(objField,strDefault) {
/* 148 */ // Clears the placeholder text in an input field if it matches the default string - fixes a bug in Android
/* 149 */ 	if((objField.value==strDefault) || (objField.value=="")) {
/* 150 */ 		objField.value="";

/* common.js */

/* 151 */ 	}
/* 152 */ }
/* 153 */ 
/* 154 */ // Android doesn't respond to onfocus="clearField(...)" until the 
/* 155 */ // input field loses focus
/* 156 */ function androidPlaceholderFix(searchbox) {
/* 157 */     // this forces the search box to display the empty string
/* 158 */     // instead of the place holder when the search box takes focus
/* 159 */     if (searchbox.value == "") {
/* 160 */         searchbox.value = "";
/* 161 */     }
/* 162 */ }
/* 163 */ 
/* 164 */ function getCookie(name) {
/* 165 */   var cookie = document.cookie;
/* 166 */   var result = "";
/* 167 */   var start = cookie.indexOf(name + "=");
/* 168 */   if (start > -1) {
/* 169 */     start += name.length + 1;
/* 170 */     var end = cookie.indexOf(";", start);
/* 171 */     if (end < 0) {
/* 172 */       end = cookie.length;
/* 173 */     }
/* 174 */     result = unescape(cookie.substring(start, end));
/* 175 */   }
/* 176 */   return result;
/* 177 */ }
/* 178 */ 
/* 179 */ function setCookie(name, value, expireseconds, path) {
/* 180 */   var exdate = new Date();
/* 181 */   exdate.setTime(exdate.getTime() + (expireseconds * 1000));
/* 182 */   var exdateclause = (expireseconds == 0) ? "" : "; expires=" + exdate.toGMTString();
/* 183 */   var pathclause = (path == null) ? "" : "; path=" + path;
/* 184 */   document.cookie = name + "=" + escape(value) + exdateclause + pathclause;
/* 185 */ }
/* 186 */ 
/* 187 */ function getCookieArrayValue(name) {
/* 188 */   var value = getCookie(name);
/* 189 */   if (value && value.length) {
/* 190 */     return value.split('@@');
/* 191 */   } else {
/* 192 */     return new Array();
/* 193 */   }
/* 194 */ }
/* 195 */ 
/* 196 */ function setCookieArrayValue(name, values, expireseconds, path) {
/* 197 */   var value = '';
/* 198 */   if (values && values.length) {
/* 199 */     value = values.join('@@');
/* 200 */   }

/* common.js */

/* 201 */   setCookie(name, value, expireseconds, path);
/* 202 */ }
/* 203 */ 
/* 204 */ function hasClass(ele,cls) {
/* 205 */     return ele.className.match(new RegExp('(\\s|^)'+cls+'(\\s|$)'));
/* 206 */ }
/* 207 */         
/* 208 */ function addClass(ele,cls) {
/* 209 */     if (!this.hasClass(ele,cls)) ele.className += " "+cls;
/* 210 */ }
/* 211 */ 
/* 212 */ function removeClass(ele,cls) {
/* 213 */     if (hasClass(ele,cls)) {
/* 214 */         var reg = new RegExp('(\\s|^)'+cls+'(\\s|$)');
/* 215 */         ele.className=ele.className.replace(reg,' ').strip();
/* 216 */     }
/* 217 */ }
/* 218 */         
/* 219 */ function toggleClass(ele, cls) {
/* 220 */     if (hasClass(ele, cls)) {
/* 221 */         removeClass(ele, cls);
/* 222 */     } else {
/* 223 */         addClass(ele, cls);
/* 224 */     }
/* 225 */ }
/* 226 */ 
/* 227 */ // Share-related functions
/* 228 */ function showShare() {
/* 229 */     if (!document.getElementById("sharesheet")) {
/* 230 */         return;
/* 231 */     }
/* 232 */ 	document.getElementById("sharesheet").style.display="block";
/* 233 */ 	var iframes = document.getElementsByTagName('iframe');
/* 234 */ 	for (var i=0; i<iframes.length; i++) {
/* 235 */ 	    iframes[i].style.visibility = 'hidden';
/* 236 */ 	    iframes[i].style.height = '0';
/* 237 */ 	}
/* 238 */ 	window.scrollTo(0,0);
/* 239 */ }
/* 240 */ function hideShare() {
/* 241 */     if (!document.getElementById("sharesheet")) {
/* 242 */         return;
/* 243 */     }
/* 244 */ 	document.getElementById("sharesheet").style.display="none";
/* 245 */ 	var iframes = document.getElementsByTagName('iframe');
/* 246 */ 	for (var i=0; i<iframes.length; i++) {
/* 247 */ 	    iframes[i].style.visibility = 'visible';
/* 248 */ 	    iframes[i].style.height = '';
/* 249 */ 	}
/* 250 */ }

/* common.js */

/* 251 */ 
/* 252 */ // Bookmarks
/* 253 */ function toggleBookmark(name, item, expireseconds, path, bookmarkId) {
/* 254 */   // facility for module to respond to bookmark state change
/* 255 */   if (typeof moduleBookmarkWillToggle != 'undefined') {
/* 256 */     $result = moduleBookmarkWillToggle(name, item, expireseconds, path);
/* 257 */     if ($result === false) { return; }
/* 258 */   }
/* 259 */ 
/* 260 */   if (!bookmarkId) {
/* 261 */     bookmarkId = "bookmark";
/* 262 */   }
/* 263 */   var bookmark = document.getElementById(bookmarkId);
/* 264 */   toggleClass(bookmark, "on");
/* 265 */   var items = getCookieArrayValue(name);
/* 266 */   var newItems = new Array();
/* 267 */   if (items.length == 0) {
/* 268 */     newItems[0] = item;
/* 269 */   } else {
/* 270 */     var found = false;
/* 271 */     for (var i = 0; i < items.length; i++) {
/* 272 */       if (items[i] == item) {
/* 273 */         found = true;
/* 274 */       } else {
/* 275 */         newItems.push(items[i]);
/* 276 */       }
/* 277 */     }
/* 278 */     if (!found) {
/* 279 */       newItems.push(item);
/* 280 */     }
/* 281 */   }
/* 282 */   setCookieArrayValue(name, newItems, expireseconds, path);
/* 283 */   
/* 284 */   // facility for module to respond to bookmark state change
/* 285 */   if (typeof moduleBookmarkToggled != 'undefined') {
/* 286 */     moduleBookmarkToggled(name, item, expireseconds, path);
/* 287 */   }
/* 288 */ }
/* 289 */ 
/* 290 */ // TODO this needs to handle encoded strings and parameter separators (&amp;)
/* 291 */ if (typeof makeAPICall === 'undefined' && typeof jQuery === 'undefined') {
/* 292 */   function makeAPICall(type, module, command, data, callback) {
/* 293 */     var urlParts = [];
/* 294 */     for (var param in data) {
/* 295 */       urlParts.push(param + "=" + data[param]);
/* 296 */     }
/* 297 */     url = URL_BASE + API_URL_PREFIX + '/' + module + '/' + command + '?' + urlParts.join('&');
/* 298 */     var handleError = function(errorObj) {}
/* 299 */ 
/* 300 */     var httpRequest = new XMLHttpRequest();

/* common.js */

/* 301 */     httpRequest.open("GET", url, true);
/* 302 */     httpRequest.onreadystatechange = function() {
/* 303 */       if (httpRequest.readyState == 4 && httpRequest.status == 200) {
/* 304 */         var obj;
/* 305 */         if (window.JSON) {
/* 306 */             obj = JSON.parse(httpRequest.responseText);
/* 307 */             // TODO: catch SyntaxError
/* 308 */         } else {
/* 309 */             obj = eval('(' + httpRequest.responseText + ')');
/* 310 */         }
/* 311 */         if (obj !== undefined) {
/* 312 */           if ("response" in obj) {
/* 313 */             callback(obj["response"]);
/* 314 */           }
/* 315 */ 
/* 316 */           if ("error" in obj && obj["error"] !== null) {
/* 317 */             handleError(obj["error"]);
/* 318 */           } else {
/* 319 */             handleError("response not found");
/* 320 */           }
/* 321 */         } else {
/* 322 */           handleError("failed to parse response");
/* 323 */         }
/* 324 */       }
/* 325 */     }
/* 326 */     httpRequest.send(null);
/* 327 */   }
/* 328 */ }
/* 329 */ 
/* 330 */ 
/* 331 */ 
/* 332 */ 
/* 333 */ 
/* 334 */ 
/* 335 */ 
/* 336 */ 
/* 337 */ 

;
/* compliant.js */

/* 1 */ function scrollToTop() {
/* 2 */ 	scrollTo(0,1); 
/* 3 */ }
/* 4 */ 
/* 5 */ function onDOMChange() {
/* 6 */   // Not needed for compliant
/* 7 */ }
/* 8 */ 

;
/* common-common-native.js */

/* 1   */ (function (window) {
/* 2   */     function kgoBridgeHandler(config) {
/* 3   */         if (typeof config == 'object') {
/* 4   */             for (var i in config) {
/* 5   */                 this.config[i] = config[i];
/* 6   */             }
/* 7   */         }
/* 8   */     }
/* 9   */     
/* 10  */     kgoBridgeHandler.prototype = {
/* 11  */         config: {
/* 12  */             events: false,  // desktop browser simulation mode
/* 13  */             base: "",
/* 14  */             url: "",
/* 15  */             ajaxArgs: "",
/* 16  */             pagePage: "",
/* 17  */             pageArgs: "",
/* 18  */             serverURL: "",
/* 19  */             timeout: 60,
/* 20  */             localizedStrings: {}
/* 21  */         },
/* 22  */         callbacks : {},
/* 23  */         callbackIdCounter : 0,
/* 24  */         
/* 25  */         // This code list is duplicated in iOS and Android code.  
/* 26  */         // Do not change existing codes!
/* 27  */         errorCodes : {
/* 28  */             KGOBridgeErrorAPINotSupported : 1,
/* 29  */             KGOBridgeErrorJSONConvertFailed : 2
/* 30  */         },
/* 31  */         
/* 32  */         // ====================================================================
/* 33  */         // Bridge API
/* 34  */         // ====================================================================
/* 35  */         
/* 36  */         //
/* 37  */         // Page load
/* 38  */         //
/* 39  */         
/* 40  */         initPage: function (params, statusCallback) {
/* 41  */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 42  */             
/* 43  */             this.nativeAPI("page", "init", params, statusCallback);
/* 44  */         },
/* 45  */         
/* 46  */         //
/* 47  */         // Errors
/* 48  */         //
/* 49  */         
/* 50  */         initPageError: function (httpStatus, title, message) {

/* common-common-native.js */

/* 51  */             switch (httpStatus) {
/* 52  */                 case 401:
/* 53  */                 case 407:
/* 54  */                     title = this.localizedString("ERROR_HTTP_UNAUTHORIZED_REQUEST_TITLE");
/* 55  */                     message = this.localizedString("ERROR_HTTP_UNAUTHORIZED_REQUEST_MESSAGE");
/* 56  */                     break;
/* 57  */                 case 408:
/* 58  */                     title = this.localizedString("ERROR_HTTP_CONNECTION_TIMEOUT_TITLE");
/* 59  */                     message = this.localizedString("ERROR_HTTP_CONNECTION_TIMEOUT_MESSAGE");
/* 60  */                     break;
/* 61  */                 case 404:
/* 62  */                 case 503:
/* 63  */                 default:
/* 64  */                     title = this.localizedString("ERROR_HTTP_CONNECTION_FAILED_TITLE");
/* 65  */                     message = this.localizedString("ERROR_HTTP_CONNECTION_FAILED_MESSAGE");
/* 66  */                     break;
/* 67  */             }
/* 68  */             
/* 69  */             this.handleError("pageinit", httpStatus, title, message);
/* 70  */         },
/* 71  */ 
/* 72  */         handleError: function (errorType, code, title, message) {
/* 73  */             if (typeof title   != "string") { title   = ""; }
/* 74  */             if (typeof message != "string") { message = ""; }
/* 75  */             
/* 76  */             this.nativeAPI("error", errorType, {
/* 77  */                 "code"    : code, 
/* 78  */                 "title"   : title, 
/* 79  */                 "message" : message
/* 80  */             });
/* 81  */         },
/* 82  */         
/* 83  */         //
/* 84  */         // Dialogs
/* 85  */         //
/* 86  */         
/* 87  */         alert: function (message, responseCallback /* optional */) {
/* 88  */             var ok = this.localizedString("BUTTON_OK");
/* 89  */ 
/* 90  */             this.alertDialog(message, null, ok, null, null, function (error, params) {
/* 91  */                 if (typeof responseCallback != "undefined" && responseCallback && error !== null) {
/* 92  */                     responseCallback();
/* 93  */                 }
/* 94  */             }, function (error, params) {
/* 95  */                 if (typeof responseCallback != "undefined" && responseCallback) {
/* 96  */                     responseCallback();
/* 97  */                 }
/* 98  */             });
/* 99  */         },
/* 100 */         

/* common-common-native.js */

/* 101 */         confirm: function (question, responseCallback) {
/* 102 */             var ok = this.localizedString("BUTTON_OK");
/* 103 */             var cancel = this.localizedString("BUTTON_CANCEL");
/* 104 */             
/* 105 */             this.alertDialog(message, null, ok, cancel, null, function (error, params) {
/* 106 */                 if (error !== null) {
/* 107 */                     responseCallback(false);
/* 108 */                 }
/* 109 */             }, function (error, params) {
/* 110 */                 // Return true when main button is pressed
/* 111 */                 responseCallback(error === null && params["button"] == "main");
/* 112 */             });
/* 113 */         },
/* 114 */         
/* 115 */         shareDialog: function (buttonConfig) {
/* 116 */             var buttonTitles = [];
/* 117 */             var actionURLs = [];
/* 118 */             if ("mail" in buttonConfig) {
/* 119 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_EMAIL"));
/* 120 */                 actionURLs.push(buttonConfig["mail"]);
/* 121 */             }
/* 122 */             if ("facebook" in buttonConfig) {
/* 123 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_FACEBOOK"));
/* 124 */                 actionURLs.push(buttonConfig["facebook"]);
/* 125 */             }
/* 126 */             if ("twitter" in buttonConfig) {
/* 127 */                 buttonTitles.push(this.localizedString("SHARE_OPTION_TWITTER"));
/* 128 */                 actionURLs.push(buttonConfig["twitter"]);
/* 129 */             }
/* 130 */             
/* 131 */             var title = this.localizedString("SHARE_THIS_ITEM");
/* 132 */             var cancel = this.localizedString("BUTTON_CANCEL");
/* 133 */             
/* 134 */             var that = this;
/* 135 */             this.actionDialog(title, cancel, null, buttonTitles, null, function(error, params) {
/* 136 */                 if ("button" in params && params["button"].indexOf('alternate') === 0) {
/* 137 */                     var index = +params["button"].substr(9);
/* 138 */                     if (index >= 0 && index < actionURLs.length) {
/* 139 */                         that.loadURL(actionURLs[index]);
/* 140 */                     }
/* 141 */                 }
/* 142 */             });
/* 143 */         },
/* 144 */         
/* 145 */         alertDialog: function (title, message, 
/* 146 */                                cancelButtonTitle, mainButtonTitle, alternateButtonTitle, 
/* 147 */                                statusCallback, buttonCallback) {
/* 148 */             // required params
/* 149 */             var params = {
/* 150 */                 "title" : title,

/* common-common-native.js */

/* 151 */                 "cancelButtonTitle" : cancelButtonTitle
/* 152 */             };
/* 153 */             
/* 154 */             // optional params
/* 155 */             if (typeof message == "string") {
/* 156 */                 params["message"] = message;
/* 157 */             }
/* 158 */             if (typeof mainButtonTitle == "string") {
/* 159 */                 params["mainButtonTitle"] = mainButtonTitle;
/* 160 */             }
/* 161 */             if (typeof alternateButtonTitle == "string") {
/* 162 */                 params["alternateButtonTitle"] = alternateButtonTitle;
/* 163 */             }
/* 164 */             
/* 165 */             // optional callbacks
/* 166 */             if (typeof statusCallback == "undefined") { statusCallback = null; }
/* 167 */             
/* 168 */             var additionalCallbacks = [];
/* 169 */             if (typeof buttonCallback != "undefined") {
/* 170 */                 additionalCallbacks.push({
/* 171 */                     "param"     : "buttonClickedCallback",
/* 172 */                     "callback"  : buttonCallback,
/* 173 */                     "repeating" : false
/* 174 */                 });
/* 175 */             }
/* 176 */             
/* 177 */             this.nativeAPI("dialog", "alert", params, statusCallback, additionalCallbacks);
/* 178 */         },
/* 179 */         
/* 180 */         actionDialog: function (title, 
/* 181 */                                 cancelButtonTitle, destructiveButtonTitle, alternateButtonTitles, 
/* 182 */                                 statusCallback, buttonCallback) {
/* 183 */             // required params
/* 184 */             var params = {
/* 185 */                 "title" : title,
/* 186 */                 "cancelButtonTitle" : cancelButtonTitle
/* 187 */             };
/* 188 */             
/* 189 */             // optional params
/* 190 */             if (typeof destructiveButtonTitle == "string") {
/* 191 */                 params["destructiveButtonTitle"] = destructiveButtonTitle;
/* 192 */             }
/* 193 */             if (typeof alternateButtonTitles != "undefined") {
/* 194 */                 for (var i = 0; i < alternateButtonTitles.length; i++) {
/* 195 */                     params["alternateButtonTitle"+i] = alternateButtonTitles[i];
/* 196 */                 }
/* 197 */             }
/* 198 */             
/* 199 */             // optional callbacks
/* 200 */             if (typeof statusCallback == "undefined") { statusCallback = null; }

/* common-common-native.js */

/* 201 */             
/* 202 */             var additionalCallbacks = [];
/* 203 */             if (typeof buttonCallback != "undefined") {
/* 204 */                 additionalCallbacks.push({
/* 205 */                     "param"     : "buttonClickedCallback",
/* 206 */                     "callback"  : buttonCallback,
/* 207 */                     "repeating" : false
/* 208 */                 });
/* 209 */             }
/* 210 */             
/* 211 */             this.nativeAPI("dialog", "action", params, statusCallback, additionalCallbacks);
/* 212 */         },
/* 213 */ 
/* 214 */         //
/* 215 */         // Events
/* 216 */         //
/* 217 */         
/* 218 */         addEventListener: function (eventType, eventHandlerCallback, statusCallback) {
/* 219 */             var params = {
/* 220 */                 "event" : eventType
/* 221 */             };
/* 222 */             
/* 223 */             this.nativeAPI("listener", "add", params, statusCallback, [{
/* 224 */                 "param"     : "eventHandlerCallback",
/* 225 */                 "callback"  : eventHandlerCallback,
/* 226 */                 "repeating" : true
/* 227 */             }]);
/* 228 */         },
/* 229 */         
/* 230 */         removeEventListener: function (eventType, eventHandlerCallback, statusCallback) {
/* 231 */             var params = {
/* 232 */                 "event" : eventType
/* 233 */             };
/* 234 */             
/* 235 */             this.nativeAPI("listener", "remove", params, statusCallback, [{
/* 236 */                 "param"     : "eventHandlerCallback",
/* 237 */                 "callback"  : eventHandlerCallback,
/* 238 */                 "repeating" : true,
/* 239 */                 "remove"    : true
/* 240 */             }]);
/* 241 */         },
/* 242 */         
/* 243 */         // ====================================================================
/* 244 */         // Low level implementation
/* 245 */         // ====================================================================
/* 246 */         
/* 247 */         nativeAPI: function (category, type, params, statusCallback, additionalCallbacks) {
/* 248 */             var url = "kgobridge://"+escape(category)+"/"+escape(type);
/* 249 */             var paramStrings = [];
/* 250 */             if (typeof params == "object") {

/* common-common-native.js */

/* 251 */                 for (var key in params) {
/* 252 */                     paramStrings.push(escape(key)+"="+escape(params[key]));
/* 253 */                 }
/* 254 */             }
/* 255 */             
/* 256 */             // status callback
/* 257 */             var that = this;
/* 258 */             var callbackId = this.callbackIdCounter++;
/* 259 */             this.callbacks[callbackId] = {
/* 260 */                 "callback" : function (error, params) {
/* 261 */                     if (error !== null && "code" in error) {
/* 262 */                         var code = error["code"];
/* 263 */                         var title = "title" in error ? error["title"] : "Unknown Title";
/* 264 */                         var message = "message" in error ? error["message"] : "Unknown message";
/* 265 */                         
/* 266 */                         for (codeKey in that.errorCodes) {
/* 267 */                             if (that.errorCodes[codeKey] == code) {
/* 268 */                                 code = codeKey;
/* 269 */                                 break;
/* 270 */                             }
/* 271 */                         }
/* 272 */                         that.log("kgoBridge api returned error "+code+" ("+title+" : "+message+")");
/* 273 */                     }
/* 274 */                     if (typeof statusCallback != "undefined" && statusCallback) {
/* 275 */                         statusCallback(error, params);
/* 276 */                     }
/* 277 */                     if (error !== null && typeof additionalCallbacks != "undefined") {
/* 278 */                         // Remove other callbacks on error
/* 279 */                         for (var i = 0; i < additionalCallbacks.length; i++) {
/* 280 */                             if (typeof additionalCallbacks[i]["remove"] == "undefined" || !additionalCallbacks[i]["remove"]) {
/* 281 */                                 var callbackId = that.callbackIdForCallback(additionalCallbacks[i]["callback"]);
/* 282 */                                 if (callbackId) {
/* 283 */                                     delete that.callbacks[callbackId];
/* 284 */                                 }
/* 285 */                             }
/* 286 */                         }
/* 287 */                     }
/* 288 */                 },
/* 289 */                 "repeating" : false
/* 290 */             };
/* 291 */             paramStrings.push("statusCallback="+callbackId);
/* 292 */             
/* 293 */             // additional callbacks
/* 294 */             if (typeof additionalCallbacks != "undefined") {
/* 295 */                 for (var i = 0; i < additionalCallbacks.length; i++) {
/* 296 */                     if (typeof additionalCallbacks[i]["remove"] == "undefined" || !additionalCallbacks[i]["remove"]) {
/* 297 */                         // Adding a callback
/* 298 */                         var callbackId = this.callbackIdCounter++;
/* 299 */                         this.callbacks[callbackId] = {
/* 300 */                             "callback"  : additionalCallbacks[i]["callback"],

/* common-common-native.js */

/* 301 */                             "repeating" : additionalCallbacks[i]["repeating"]
/* 302 */                         };
/* 303 */                         paramStrings.push(additionalCallbacks[i]["param"]+"="+callbackId);
/* 304 */                         
/* 305 */                     } else {
/* 306 */                         // Removing a callback
/* 307 */                         var callbackId = this.callbackIdForCallback(additionalCallbacks[i]["callback"]);
/* 308 */                         if (callbackId) {
/* 309 */                             paramStrings.push(additionalCallbacks[i]["param"]+"="+callbackId);
/* 310 */                             delete this.callbacks[callbackId];
/* 311 */                         }
/* 312 */                     }
/* 313 */                 }
/* 314 */             }
/* 315 */             
/* 316 */             if (paramStrings.length) {
/* 317 */                 url += "?"+paramStrings.join("&");
/* 318 */             }
/* 319 */             
/* 320 */             this.loadURL(url);
/* 321 */         },
/* 322 */         
/* 323 */         nativeAPICallback: function (callbackId, error, params) {
/* 324 */             if (callbackId in this.callbacks && this.callbacks[callbackId]) {
/* 325 */                 if (typeof params !== "object") {
/* 326 */                     params = {};
/* 327 */                 }
/* 328 */                 
/* 329 */                 // Callbacks frequently perform operations which will not work
/* 330 */                 // at the time the native app sends the callback (alert, log, etc)
/* 331 */                 // So delay the callback by 100ms to avoid these problems.
/* 332 */                 var that = this;
/* 333 */                 setTimeout(function () {
/* 334 */                     that.callbacks[callbackId]["callback"].call(that, error, params);
/* 335 */                     
/* 336 */                     if (!that.callbacks[callbackId]["repeating"]) {
/* 337 */                         delete that.callbacks[callbackId];
/* 338 */                     }
/* 339 */                 }, 100);
/* 340 */             }
/* 341 */         },
/* 342 */         
/* 343 */         callbackIdForCallback: function (callback) {
/* 344 */             for (var callbackId in this.callbacks) {
/* 345 */                 if (this.callbacks[callbackId]["callback"] === callback) {
/* 346 */                     return callbackId;
/* 347 */                 }
/* 348 */             }
/* 349 */             return null;
/* 350 */         },

/* common-common-native.js */

/* 351 */         
/* 352 */         loadURL: function (url) {
/* 353 */             var lcURL = url.toLowerCase();
/* 354 */             if (lcURL.indexOf("http://") == 0 || lcURL.indexOf("https://") == 0) {
/* 355 */                 // wrap external URLs so that we don't get confused by other iframes
/* 356 */                 url = "kgobridge://external/link?url="+encodeURIComponent(url);
/* 357 */             }
/* 358 */             
/* 359 */             if (this.config.events) {
/* 360 */                 var iframe = document.createElement("IFRAME");
/* 361 */                 iframe.setAttribute("src", url);
/* 362 */                 document.documentElement.appendChild(iframe);
/* 363 */                 iframe.parentNode.removeChild(iframe);
/* 364 */                 iframe = null;
/* 365 */             } else {
/* 366 */                 this.log("kgoBridge would have called "+url);
/* 367 */             }
/* 368 */         },
/* 369 */         
/* 370 */         localizedString: function (key) {
/* 371 */             if (key in this.config.localizedStrings) {
/* 372 */                 return this.config.localizedStrings[key];
/* 373 */             } else {
/* 374 */                 return key;
/* 375 */             }
/* 376 */         },
/* 377 */         
/* 378 */         ajaxLoad: function () {
/* 379 */             var pageURL = this.config.url+this.config.pagePath+"?"+this.config.ajaxArgs;
/* 380 */             if (this.config.pageArgs.length) {
/* 381 */                 pageURL += "&"+this.config.pageArgs;
/* 382 */             }
/* 383 */             var timeout = this.config.timeout * 1000;
/* 384 */             
/* 385 */             var httpRequest = new XMLHttpRequest();
/* 386 */             httpRequest.open("GET", pageURL, true);
/* 387 */             
/* 388 */             var that = this;
/* 389 */             
/* 390 */             var requestTimer = setTimeout(function() {
/* 391 */                 // some browsers set readyState to 4 on abort so remove handler first
/* 392 */                 httpRequest.onreadystatechange = function() { };
/* 393 */                 httpRequest.abort();
/* 394 */                 
/* 395 */                 that.initPageError(408); // http request timeout status code
/* 396 */             }, timeout);
/* 397 */             
/* 398 */             httpRequest.onreadystatechange = function() {
/* 399 */                 // return if still in progress
/* 400 */                 if (httpRequest.readyState != 4) { return; }

/* common-common-native.js */

/* 401 */                 
/* 402 */                 // Got answer, don't abort
/* 403 */                 clearTimeout(requestTimer);
/* 404 */                 
/* 405 */                 if (httpRequest.status == 200) {
/* 406 */                     // Success
/* 407 */                     var container = document.getElementById("container");
/* 408 */                     container.innerHTML = httpRequest.responseText;
/* 409 */                     
/* 410 */                     // Grab script tags and appendChild them so they get evaluated
/* 411 */                     var scripts = container.getElementsByTagName("script");
/* 412 */                     var count = scripts.length; // scripts.length will change as we add elements
/* 413 */                     
/* 414 */                     for (var i = 0; i < count; i++) {
/* 415 */                         var script = document.createElement("script");
/* 416 */                         script.type = "text/javascript";
/* 417 */                         script.text = scripts[i].text;
/* 418 */                         container.appendChild(script);
/* 419 */                     }
/* 420 */                     
/* 421 */                     if (typeof kgoBridgeOnAjaxLoad != 'undefined') {
/* 422 */                         kgoBridgeOnAjaxLoad();
/* 423 */                     } else {
/* 424 */                         that.log("Warning! kgoBridgeOnAjaxLoad is not defined by the page content");
/* 425 */                     }
/* 426 */                     
/* 427 */                 } else {
/* 428 */                     // Error
/* 429 */                     that.initPageError(httpRequest.status);
/* 430 */                 }
/* 431 */             }
/* 432 */             
/* 433 */             httpRequest.send(null);
/* 434 */         },
/* 435 */         
/* 436 */         bridgeToAjaxLink: function (href) {
/* 437 */             // must be able to pass through non-kgobridge links
/* 438 */             var bridgePrefix = "kgobridge://link/";
/* 439 */             var oldhref= href;
/* 440 */             if (href.indexOf(bridgePrefix) == 0) {
/* 441 */                 href = this.config.url+"/"+href.substr(bridgePrefix.length);
/* 442 */                 
/* 443 */                 var anchor = '';
/* 444 */                 var anchorPos = href.indexOf("#");
/* 445 */                 if (anchorPos > 0) {
/* 446 */                     anchor = href.substr(anchorPos);
/* 447 */                     href = href.substr(0, anchorPos);
/* 448 */                 }
/* 449 */                 href = href+(href.indexOf("?") > 0 ? "&" : "?")+this.config.ajaxArgs+anchor;
/* 450 */             }

/* common-common-native.js */

/* 451 */             return href;
/* 452 */         },
/* 453 */         
/* 454 */         log: function (message) {
/* 455 */             if (this.config.events) {
/* 456 */                 this.loadURL("kgobridge://console/log?message="+encodeURIComponent(message));
/* 457 */                 
/* 458 */             } else if (typeof console != "undefined" && typeof console.log != "undefined") {
/* 459 */                 console.log("KGO_LOG: "+message);
/* 460 */             }
/* 461 */         }
/* 462 */     };
/* 463 */     
/* 464 */     window.kgoBridgeHandler = kgoBridgeHandler;
/* 465 */ })(window);
/* 466 */ 

;
/* common.js */

/* 1  */ // Initalize the ellipsis event handlers
/* 2  */ var newsEllipsizer;
/* 3  */ function setupNewsListing() {
/* 4  */     newsEllipsizer = new ellipsizer();
/* 5  */     
/* 6  */     // cap at 100 divs to avoid overloading phone
/* 7  */     for (var i = 0; i < 100; i++) {
/* 8  */         var elem = document.getElementById('ellipsis_'+i);
/* 9  */         if (!elem) { break; }
/* 10 */         newsEllipsizer.addElement(elem);
/* 11 */     }
/* 12 */ }
/* 13 */ 

;
/* index-common.js */

/* 1  */ function loadSection(select) {
/* 2  */     window.location = "kgobridge://link/test/index?section=" + select.value;
/* 3  */ }
/* 4  */ 
/* 5  */ function toggleSearch() {
/* 6  */     var categorySwitcher = document.getElementById("category-switcher");
/* 7  */     
/* 8  */     if (categorySwitcher.className == "search-mode") {
/* 9  */         categorySwitcher.className = "category-mode";
/* 10 */     } else {
/* 11 */         categorySwitcher.className = "search-mode";
/* 12 */         document.getElementById("search_terms").focus();
/* 13 */     }
/* 14 */     return false;
/* 15 */ }
/* 16 */ 
/* 17 */ function submitenter(myfield, e) {
/* 18 */     var keycode;
/* 19 */     if (window.event) {
/* 20 */         keycode = window.event.keyCode;
/* 21 */         
/* 22 */     } else if (e) {
/* 23 */         keycode = e.keyCode;        
/* 24 */         
/* 25 */     } else {
/* 26 */         return true;
/* 27 */     }
/* 28 */ 
/* 29 */     if (keycode == 13) {
/* 30 */        myfield.form.submit();
/* 31 */        return false;
/* 32 */        
/* 33 */     } else {
/* 34 */         return true;        
/* 35 */     }
/* 36 */ }
/* 37 */ 
